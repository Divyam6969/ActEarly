package com.mycompany.actearly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
