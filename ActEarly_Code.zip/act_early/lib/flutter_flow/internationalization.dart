import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'fr', 'es', 'de', 'zh_Hans', 'hi'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? frText = '',
    String? esText = '',
    String? deText = '',
    String? zh_HansText = '',
    String? hiText = '',
  }) =>
      [enText, frText, esText, deText, zh_HansText, hiText][languageIndex] ??
      '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // LogIn_page
  {
    'jqked1o0': {
      'en': 'ActEarly',
      'de': 'Früh handeln',
      'es': 'Actúa temprano',
      'fr': 'Agir tôt',
      'hi': 'एक्टअर्ली',
      'zh_Hans': '尽早行动',
    },
    'n04ra9hp': {
      'en': 'Sign In',
      'de': 'Anmelden',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter',
      'hi': 'दाखिल करना',
      'zh_Hans': '登入',
    },
    'c6e71nwc': {
      'en': 'Let\'s get started by filling out the form below.',
      'de': 'Beginnen wir, indem Sie das folgende Formular ausfüllen.',
      'es': 'Comencemos llenando el formulario a continuación.',
      'fr': 'Commençons par remplir le formulaire ci-dessous.',
      'hi': 'आइये नीचे दिया गया फॉर्म भरकर शुरुआत करें।',
      'zh_Hans': '让我们从填写下面的表格开始。',
    },
    'fhgmxsy5': {
      'en': 'Email',
      'de': 'E-Mail',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
      'hi': 'ईमेल',
      'zh_Hans': '电子邮件',
    },
    'pvb3x11e': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'hi': 'पासवर्ड',
      'zh_Hans': '密码',
    },
    '85n60s5l': {
      'en': 'Sign In',
      'de': 'Anmelden',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter',
      'hi': 'दाखिल करना',
      'zh_Hans': '登入',
    },
    '23vs11f0': {
      'en': 'Or sign up with',
      'de': 'Oder registrieren Sie sich mit',
      'es': 'O regístrate con',
      'fr': 'Ou inscrivez-vous avec',
      'hi': 'या साइन अप करें',
      'zh_Hans': '或注册',
    },
    '03d9t8rh': {
      'en': 'Continue with Google',
      'de': 'Weiter mit Google',
      'es': 'Continuar con Google',
      'fr': 'Continuer avec Google',
      'hi': 'Google के साथ जारी रखें',
      'zh_Hans': '继续使用 Google',
    },
    'xknjbdt1': {
      'en': 'Continue with Apple',
      'de': 'Weiter mit Apple',
      'es': 'Continuar con Apple',
      'fr': 'Continuer avec Apple',
      'hi': 'एप्पल के साथ जारी रखें',
      'zh_Hans': '继续使用 Apple',
    },
    '56whr1fv': {
      'en': 'Forgot your password',
      'de': 'Passwort vergessen',
      'es': 'Olvidaste tu contraseña',
      'fr': 'Mot de passe oublié',
      'hi': 'अपना कूट शब्द भूल गए',
      'zh_Hans': '忘记密码了吗',
    },
    '4goeonpy': {
      'en': 'Sign Up',
      'de': 'Melden Sie sich an',
      'es': 'Inscribirse',
      'fr': 'S\'inscrire',
      'hi': 'साइन अप करें',
      'zh_Hans': '报名',
    },
    '1o2dke0x': {
      'en':
          '\"Watch Your Child\'s Growth Unfold: Track Every Milestone, Big and Small!\"',
      'de':
          '„Beobachten Sie die Entwicklung Ihres Kindes: Verfolgen Sie jeden Meilenstein, ob groß oder klein!“',
      'es':
          '\"Observe cómo crece su hijo: ¡siga cada hito, grande o pequeño!\"',
      'fr':
          '« Observez la croissance de votre enfant : suivez chaque étape, grande ou petite ! »',
      'hi':
          '\"अपने बच्चे के विकास को देखें: हर छोटी-बड़ी उपलब्धि पर नज़र रखें!\"',
      'zh_Hans': '“观察孩子的成长：追踪每个里程碑，无论大小！”',
    },
    'bm8eji28': {
      'en': 'Name',
      'de': 'Name',
      'es': 'Nombre',
      'fr': 'Nom',
      'hi': 'नाम',
      'zh_Hans': '姓名',
    },
    'e2wvy2xy': {
      'en': 'Email',
      'de': 'E-Mail',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
      'hi': 'ईमेल',
      'zh_Hans': '电子邮件',
    },
    '81tmgugc': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'hi': 'पासवर्ड',
      'zh_Hans': '密码',
    },
    '02uv2o40': {
      'en': 'Confirm Password',
      'de': 'Passwort bestätigen',
      'es': 'confirmar Contraseña',
      'fr': 'Confirmez le mot de passe',
      'hi': 'पासवर्ड की पुष्टि कीजिये',
      'zh_Hans': '确认密码',
    },
    '3makzpby': {
      'en': 'Create Account',
      'de': 'Benutzerkonto erstellen',
      'es': 'Crear una cuenta',
      'fr': 'Créer un compte',
      'hi': 'खाता बनाएं',
      'zh_Hans': '创建账户',
    },
    's0gsuz04': {
      'en': 'Or sign up with',
      'de': 'Oder registrieren Sie sich mit',
      'es': 'O regístrate con',
      'fr': 'Ou inscrivez-vous avec',
      'hi': 'या साइन अप करें',
      'zh_Hans': '或注册',
    },
    '6kxks33l': {
      'en': 'Continue with Google',
      'de': 'Weiter mit Google',
      'es': 'Continuar con Google',
      'fr': 'Continuer avec Google',
      'hi': 'Google के साथ जारी रखें',
      'zh_Hans': '继续使用 Google',
    },
    'f1415oux': {
      'en': 'Continue with Apple',
      'de': 'Weiter mit Apple',
      'es': 'Continuar con Apple',
      'fr': 'Continuer avec Apple',
      'hi': 'एप्पल के साथ जारी रखें',
      'zh_Hans': '继续使用 Apple',
    },
    '1csvfbjd': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // HomePage
  {
    '5bbjuaoe': {
      'en':
          '\nWelcome to ActEarly! Children develop skills across various areas. Check your child\'s developmental milestones by age using the dropdown below! (Psst... the carousel below is reversible too)',
      'de':
          'Willkommen bei ActEarly! Kinder entwickeln Fähigkeiten in verschiedenen Bereichen. Überprüfen Sie die Entwicklungsmeilensteine Ihres Kindes nach Alter mithilfe der Dropdown-Liste unten! (Psst... das Karussell unten ist auch umkehrbar)',
      'es':
          '¡Bienvenidos a ActEarly! Los niños desarrollan habilidades en diversas áreas. ¡Consulte los hitos del desarrollo de su hijo por edad utilizando el menú desplegable a continuación! (Psst... el carrusel a continuación también es reversible)',
      'fr':
          'Bienvenue sur ActEarly ! Les enfants développent des compétences dans divers domaines. Vérifiez les étapes de développement de votre enfant par âge à l\'aide du menu déroulant ci-dessous ! (Psst... le carrousel ci-dessous est également réversible)',
      'hi':
          'एक्टअर्ली में आपका स्वागत है! बच्चे विभिन्न क्षेत्रों में कौशल विकसित करते हैं। नीचे दिए गए ड्रॉपडाउन का उपयोग करके उम्र के अनुसार अपने बच्चे के विकासात्मक मील के पत्थर देखें! (Psst... नीचे दिया गया कैरोसेल भी उलटा हो सकता है)',
      'zh_Hans':
          '欢迎来到 ActEarly！孩子们在各个领域发展技能。使用下面的下拉菜单按年龄查看您孩子的发展里程碑！（嘘...下面的旋转木马也是可逆的）',
    },
    't2knk3md': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '30jrof4l': {
      'en': 'at the end of 3 months',
      'de': 'nach 3 Monaten',
      'es': 'al final de 3 meses',
      'fr': 'au bout de 3 mois',
      'hi': '3 महीने के अंत में',
      'zh_Hans': '3个月后',
    },
    '9zcr3brb': {
      'en': 'at the end of 8 months',
      'de': 'nach 8 Monaten',
      'es': 'Al final de los 8 meses',
      'fr': 'au bout de 8 mois',
      'hi': '8 महीने के अंत में',
      'zh_Hans': '8个月后',
    },
    'lnt1g5uq': {
      'en': 'between 12 and 14 months',
      'de': 'zwischen 12 und 14 Monaten',
      'es': 'Entre 12 y 14 meses',
      'fr': 'entre 12 et 14 mois',
      'hi': '12 से 14 महीने के बीच',
      'zh_Hans': '12至14个月之间',
    },
    'vzp7o6nf': {
      'en': 'at the end of 1.5 years',
      'de': 'nach 1,5 Jahren',
      'es': 'al cabo de 1,5 años',
      'fr': 'au bout de 1,5 an',
      'hi': '1.5 वर्ष के अंत में',
      'zh_Hans': '一年半后',
    },
    '532e4m9c': {
      'en': 'at the end of 2 years',
      'de': 'nach 2 Jahren',
      'es': 'al cabo de 2 años',
      'fr': 'au bout de 2 ans',
      'hi': '2 वर्ष के अंत में',
      'zh_Hans': '两年后',
    },
    'ndk7oylt': {
      'en': 'at the end of 3 years',
      'de': 'nach 3 Jahren',
      'es': 'Al cabo de 3 años',
      'fr': 'au bout de 3 ans',
      'hi': '3 वर्ष के अंत में',
      'zh_Hans': '三年后',
    },
    'gqd7vl3k': {
      'en': 'at the end of 4 years',
      'de': 'am Ende von 4 Jahren',
      'es': 'Al cabo de 4 años',
      'fr': 'au bout de 4 ans',
      'hi': '4 वर्ष के अंत में',
      'zh_Hans': '四年后',
    },
    'u4a3ngh0': {
      'en': 'Please select the child age',
      'de': 'Bitte wählen Sie das Alter des Kindes aus',
      'es': 'Por favor seleccione la edad del niño',
      'fr': 'Veuillez sélectionner l\'âge de l\'enfant',
      'hi': 'कृपया बच्चे की आयु चुनें',
      'zh_Hans': '请选择儿童年龄',
    },
    'lkt5mviz': {
      'en': 'Search for an item...',
      'de': 'Nach einem Artikel suchen...',
      'es': 'Buscar un artículo...',
      'fr': 'Rechercher un article...',
      'hi': 'किसी आइटम की खोज करें...',
      'zh_Hans': '搜索商品...',
    },
    '3t7sf38w': {
      'en': 'Gross Motor',
      'de': 'Grobmotorik',
      'es': 'Motricidad gruesa',
      'fr': 'Motricité globale',
      'hi': 'सकल मोटर',
      'zh_Hans': '粗大运动',
    },
    'm1voq1co': {
      'en':
          'These are movements using the body’s large muscles and include sitting, standing, walking, running, keeping balance, and changing positions.',
      'de':
          'Dabei handelt es sich um Bewegungen, bei denen die großen Muskeln des Körpers zum Einsatz kommen. Dazu zählen Sitzen, Stehen, Gehen, Laufen, Gleichgewicht halten und Positionswechsel.',
      'es':
          'Estos son movimientos que utilizan los músculos grandes del cuerpo e incluyen sentarse, pararse, caminar, correr, mantener el equilibrio y cambiar de posición.',
      'fr':
          'Il s’agit de mouvements faisant appel aux gros muscles du corps et comprenant la position assise, la position debout, la marche, la course, le maintien de l’équilibre et le changement de position.',
      'hi':
          'ये शरीर की बड़ी मांसपेशियों का उपयोग करके की जाने वाली गतिविधियाँ हैं और इसमें बैठना, खड़े होना, चलना, दौड़ना, संतुलन बनाए रखना और स्थिति बदलना शामिल है।',
      'zh_Hans': '这些动作使用身体的大块肌肉，包括坐、站、走、跑、保持平衡和改变姿势。',
    },
    'eyi8qjnb': {
      'en': 'Fine Motor ',
      'de': 'Feinmotorik',
      'es': 'Motricidad fina',
      'fr': 'Motricité fine',
      'hi': 'फ़ाइन मोटर',
      'zh_Hans': '精细动作',
    },
    'lo0mlbdi': {
      'en':
          'These skills use the small muscles in the hands and fingers. Fine motor skills include using hands to eat, draw, dress, play, and write. They develop over time and also involve hand-eye coordination.',
      'de':
          'Bei diesen Fähigkeiten werden die kleinen Muskeln in Händen und Fingern beansprucht. Zu den feinmotorischen Fähigkeiten gehört das Essen, Zeichnen, Anziehen, Spielen und Schreiben mit den Händen. Sie entwickeln sich mit der Zeit und umfassen auch die Hand-Augen-Koordination.',
      'es':
          'Estas habilidades utilizan los músculos pequeños de las manos y los dedos. Las habilidades motoras finas incluyen el uso de las manos para comer, dibujar, vestirse, jugar y escribir. Se desarrollan con el tiempo y también implican la coordinación mano-ojo.',
      'fr':
          'Ces compétences font appel aux petits muscles des mains et des doigts. La motricité fine consiste à utiliser les mains pour manger, dessiner, s\'habiller, jouer et écrire. Elles se développent au fil du temps et impliquent également la coordination œil-main.',
      'hi':
          'ये कौशल हाथों और उंगलियों की छोटी मांसपेशियों का उपयोग करते हैं। सूक्ष्म मोटर कौशल में खाने, चित्र बनाने, कपड़े पहनने, खेलने और लिखने के लिए हाथों का उपयोग करना शामिल है। वे समय के साथ विकसित होते हैं और इसमें हाथ-आंख का समन्वय भी शामिल होता है।',
      'zh_Hans':
          '这些技能使用手和手指的小肌肉。精细动作技能包括用手吃饭、画画、穿衣、玩耍和写字。这些技能需要随着时间的推移而发展，也涉及手眼协调能力。',
    },
    '45b5luvc': {
      'en': 'Language/Social',
      'de': 'Sprache/Soziales',
      'es': 'Lenguaje/Social',
      'fr': 'Langue/Social',
      'hi': 'भाषा/सामाजिक',
      'zh_Hans': '语言/社交',
    },
    'gif5l3r8': {
      'en':
          'Language: Speaking, using body language and gestures, and understanding what others say.\nSocial: Connecting and having relationships with others, cooperating, and responding to others\' feelings.',
      'de':
          'Sprache: Sprechen, Körpersprache und Gesten verwenden und verstehen, was andere sagen.\nSozial: Kontakte knüpfen und Beziehungen zu anderen aufbauen, zusammenarbeiten und auf die Gefühle anderer reagieren.',
      'es':
          'Lenguaje: Hablar, usar el lenguaje corporal y los gestos, y comprender lo que dicen los demás.\nSocial: Conectarse y tener relaciones con los demás, cooperar y responder a los sentimientos de los demás.',
      'fr':
          'Langage : parler, utiliser le langage corporel et les gestes, et comprendre ce que les autres disent.\nSocial : établir des liens et entretenir des relations avec les autres, coopérer et répondre aux sentiments des autres.',
      'hi':
          'भाषा: बोलना, शारीरिक भाषा और हाव-भाव का उपयोग करना, तथा दूसरों की बातों को समझना।\nसामाजिक: दूसरों से जुड़ना और उनके साथ संबंध बनाना, सहयोग करना, तथा दूसरों की भावनाओं पर प्रतिक्रिया करना।',
      'zh_Hans': '语言：说话、使用肢体语言和手势以及理解他人所说的话。\n社交：与他人建立联系和关系、合作以及回应他人的感受。',
    },
    'tas1n45x': {
      'en': 'Cognitive',
      'de': 'Kognitiv',
      'es': 'Cognitivo',
      'fr': 'Cognitif',
      'hi': 'संज्ञानात्मक',
      'zh_Hans': '认知的',
    },
    'probdyb1': {
      'en':
          'These are thinking skills—learning, understanding, problem-solving, reasoning, and remembering.',
      'de':
          'Dabei handelt es sich um Denkfähigkeiten – Lernen, Verstehen, Problemlösen, Argumentieren und Erinnern.',
      'es':
          'Éstas son habilidades de pensamiento: aprender, comprender, resolver problemas, razonar y recordar.',
      'fr':
          'Il s’agit de compétences de réflexion : apprendre, comprendre, résoudre des problèmes, raisonner et mémoriser.',
      'hi':
          'ये चिंतन कौशल हैं - सीखना, समझना, समस्या समाधान, तर्क करना और याद रखना।',
      'zh_Hans': '这些是思维技能——学习、理解、解决问题、推理和记忆。',
    },
    'wvrlhpq6': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // ManageChildren
  {
    'uz73pytw': {
      'en': 'Cloud Storage :',
      'de': 'Cloud-Speicher:',
      'es': 'Almacenamiento en la nube:',
      'fr': 'Stockage en nuage :',
      'hi': 'घन संग्रहण :',
      'zh_Hans': '云存储：',
    },
    'dozw65u6': {
      'en': 'Local Storage :',
      'de': 'Lokaler Speicher:',
      'es': 'Almacenamiento local:',
      'fr': 'Stockage local :',
      'hi': 'स्थानीय भंडारण :',
      'zh_Hans': '本地存储：',
    },
    'gws9v75f': {
      'en': '9 months',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'je4g04k7': {
      'en':
          'If you want to switch from cloud storage to local storage, you can do so from the \'My Account\' page (the rightmost option on the navbar) -> \'Switch Data Storage.',
      'de':
          'Wenn Sie vom Cloud-Speicher zum lokalen Speicher wechseln möchten, können Sie dies auf der Seite „Mein Konto“ (die Option ganz rechts in der Navigationsleiste) -> „Datenspeicher wechseln“ tun.',
      'es':
          'Si desea cambiar del almacenamiento en la nube al almacenamiento local, puede hacerlo desde la página \"Mi cuenta\" (la opción más a la derecha en la barra de navegación) -> \"Cambiar almacenamiento de datos\".',
      'fr':
          'Si vous souhaitez passer du stockage cloud au stockage local, vous pouvez le faire à partir de la page « Mon compte » (l\'option la plus à droite de la barre de navigation) -> « Changer de stockage de données ».',
      'hi':
          'यदि आप क्लाउड स्टोरेज से स्थानीय स्टोरेज पर स्विच करना चाहते हैं, तो आप \'मेरा खाता\' पृष्ठ (नेविगेशन बार पर सबसे दाहिना विकल्प) -> \'डेटा स्टोरेज स्विच करें\' से ऐसा कर सकते हैं।',
      'zh_Hans': '如果您想从云存储切换到本地存储，您可以从“我的帐户”页面（导航栏最右边的选项）->“切换数据存储”进行切换。',
    },
    'ghw0s0b0': {
      'en': 'Manage Children',
      'de': 'Untergeordnete Elemente verwalten',
      'es': 'Administrar niños',
      'fr': 'Gérer les enfants',
      'hi': 'बच्चों का प्रबंधन करें',
      'zh_Hans': '管理儿童',
    },
    'irunjz96': {
      'en': 'ManageChildren',
      'de': 'Kinder verwalten',
      'es': 'Administrar niños',
      'fr': 'Gérer les enfants',
      'hi': 'बच्चों का प्रबंधन करें',
      'zh_Hans': '管理儿童',
    },
  },
  // AddChildren
  {
    'oh8qox2e': {
      'en': 'Add Child',
      'de': 'Kind hinzufügen',
      'es': 'Agregar niño',
      'fr': 'Ajouter un enfant',
      'hi': 'बच्चा जोड़ें',
      'zh_Hans': '添加子项',
    },
    '2nqdrpaw': {
      'en': 'Child Already Registered? (No/Yes)',
      'de': 'Kind bereits registriert? (Nein/Ja)',
      'es': '¿El niño ya está registrado? (No/Sí)',
      'fr': 'Enfant déjà inscrit ? (Non/Oui)',
      'hi': 'क्या बच्चा पहले से पंजीकृत है? (नहीं/हाँ)',
      'zh_Hans': '孩子已经注册了吗？（否/是）',
    },
    'o9wnrnhk': {
      'en':
          'ActEarly ID is a unique ID given to your child at the time of registration',
      'de':
          'ActEarly ID ist eine einzigartige ID, die Ihr Kind bei der Registrierung erhält',
      'es':
          'ActEarly ID es una identificación única que se le entrega a su hijo en el momento de la inscripción.',
      'fr':
          'L\'identifiant ActEarly est un identifiant unique attribué à votre enfant au moment de l\'inscription',
      'hi':
          'एक्टअर्ली आईडी एक विशिष्ट आईडी है जो पंजीकरण के समय आपके बच्चे को दी जाती है',
      'zh_Hans': 'ActEarly ID 是您的孩子在注册时获得的唯一 ID',
    },
    '90wpc54t': {
      'en': 'Enter the ActEarly ID',
      'de': 'Geben Sie die ActEarly-ID ein',
      'es': 'Ingresa el ID de ActEarly',
      'fr': 'Entrez l\'identifiant ActEarly',
      'hi': 'ActEarly आईडी दर्ज करें',
      'zh_Hans': '输入 ActEarly ID',
    },
    '2fv0ftul': {
      'en': 'What is your relation to this child (Mom/Dad etc)',
      'de':
          'In welcher Beziehung stehen Sie zu diesem Kind (Mutter/Vater usw.)',
      'es': '¿Cuál es su relación con este niño (mamá, papá, etc.)?',
      'fr': 'Quel est votre lien de parenté avec cet enfant (maman/papa etc)',
      'hi': 'इस बच्चे से आपका क्या रिश्ता है (माँ/पिता आदि)',
      'zh_Hans': '您和这个孩子是什么关系（妈妈/爸爸等）',
    },
    'wfg7qzv7': {
      'en': 'Submit',
      'de': 'Einreichen',
      'es': 'Entregar',
      'fr': 'Soumettre',
      'hi': 'जमा करना',
      'zh_Hans': '提交',
    },
    'kzd7uobc': {
      'en':
          ' Please share your little one\'s details and if the Child is already registered by someone else enter tick the above option ',
      'de':
          'Bitte teilen Sie die Daten Ihres Kindes mit. Wenn das Kind bereits von jemand anderem registriert wurde, aktivieren Sie die obige Option.',
      'es':
          'Por favor, comparta los datos de su pequeño y si el niño ya está registrado por otra persona, marque la opción anterior.',
      'fr':
          'Veuillez partager les coordonnées de votre enfant et si l\'enfant est déjà enregistré par quelqu\'un d\'autre, cochez l\'option ci-dessus',
      'hi':
          'कृपया अपने बच्चे का विवरण साझा करें और यदि बच्चा पहले से ही किसी और द्वारा पंजीकृत है तो उपरोक्त विकल्प पर टिक करें',
      'zh_Hans': '请分享您的孩子的详细信息，如果孩子已被其他人注册，请勾选上面的选项',
    },
    '32e9e7hf': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'a2b2nxaf': {
      'en': 'Enter your Child Name',
      'de': 'Geben Sie den Namen Ihres Kindes ein',
      'es': 'Ingrese el nombre de su hijo',
      'fr': 'Entrez le nom de votre enfant',
      'hi': 'अपने बच्चे का नाम दर्ज करें',
      'zh_Hans': '输入您的孩子的名字',
    },
    'g1h6kxgc': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'j5qpb06a': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'hj982eqr': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'cxq7ow8a': {
      'en': 'Enter your relation (Eg Mom/Dad)',
      'de': 'Geben Sie Ihre Beziehung ein (z. B. Mama/Papa)',
      'es': 'Ingresa tu relación (por ejemplo, mamá/papá)',
      'fr': 'Entrez votre relation (par exemple maman/papa)',
      'hi': 'अपना रिश्ता दर्ज करें (जैसे माँ/पिताजी)',
      'zh_Hans': '输入您的关系（例如妈妈/爸爸）',
    },
    'xu5v8ct2': {
      'en': 'Was your child born prematurely?',
      'de': 'Ist Ihr Kind zu früh geboren worden?',
      'es': '¿Su hijo nació prematuramente?',
      'fr': 'Votre enfant est né prématurément ?',
      'hi': 'क्या आपका बच्चा समय से पहले पैदा हुआ था?',
      'zh_Hans': '您的孩子是早产吗？',
    },
    'gq2tj2xm': {
      'en': 'Male',
      'de': 'Männlich',
      'es': 'Masculino',
      'fr': 'Mâle',
      'hi': 'पुरुष',
      'zh_Hans': '男性',
    },
    'z5onp58s': {
      'en': 'Female',
      'de': 'Weiblich',
      'es': 'Femenino',
      'fr': 'Femelle',
      'hi': 'महिला',
      'zh_Hans': '女性',
    },
    'i33qrulg': {
      'en': 'Select your child gender',
      'de': 'Wählen Sie das Geschlecht Ihres Kindes aus',
      'es': 'Seleccione el género de su hijo',
      'fr': 'Sélectionnez le sexe de votre enfant',
      'hi': 'अपने बच्चे का लिंग चुनें',
      'zh_Hans': '选择您的孩子性别',
    },
    'vgu2ken7': {
      'en': 'Search for an item...',
      'de': 'Nach einem Artikel suchen...',
      'es': 'Buscar un artículo...',
      'fr': 'Rechercher un article...',
      'hi': 'किसी आइटम की खोज करें...',
      'zh_Hans': '搜索商品...',
    },
    'boj8vtiv': {
      'en': 'Store data in the cloud?',
      'de': 'Daten in der Cloud speichern?',
      'es': '¿Almacenar datos en la nube?',
      'fr': 'Stocker des données dans le cloud ?',
      'hi': 'क्लाउड में डेटा स्टोर करें?',
      'zh_Hans': '将数据存储在云中？',
    },
    '3lhvi4yd': {
      'en':
          'Deselecting this option means you won\'t be able to grant shared access for tracking your child\'s developmental milestones, and you will not receive an ActEarly ID for shared care; instead, child data will be stored locally on your device',
      'de':
          'Wenn Sie diese Option deaktivieren, können Sie keinen gemeinsamen Zugriff für die Verfolgung der Entwicklungsmeilensteine Ihres Kindes gewähren und Sie erhalten keine ActEarly-ID für die gemeinsame Betreuung. Stattdessen werden die Daten des Kindes lokal auf Ihrem Gerät gespeichert.',
      'es':
          'Si deselecciona esta opción, no podrá otorgar acceso compartido para realizar un seguimiento de los hitos del desarrollo de su hijo y no recibirá una identificación de ActEarly para el cuidado compartido; en cambio, los datos del niño se almacenarán localmente en su dispositivo.',
      'fr':
          'Si vous désélectionnez cette option, vous ne pourrez pas accorder d\'accès partagé pour suivre les étapes de développement de votre enfant et vous ne recevrez pas d\'identifiant ActEarly pour les soins partagés ; à la place, les données de l\'enfant seront stockées localement sur votre appareil',
      'hi':
          'इस विकल्प को अचयनित करने का अर्थ है कि आप अपने बच्चे के विकासात्मक मील के पत्थरों पर नज़र रखने के लिए साझा पहुँच प्रदान नहीं कर पाएँगे, और आपको साझा देखभाल के लिए ActEarly ID प्राप्त नहीं होगी; इसके बजाय, बच्चे का डेटा आपके डिवाइस पर स्थानीय रूप से संग्रहीत किया जाएगा',
      'zh_Hans':
          '取消选择此选项意味着您将无法授予跟踪孩子发育里程碑的共享访问权限，并且您将不会收到用于共享护理的 ActEarly ID；相反，儿童数据将存储在您的本地设备上',
    },
    'ed5dpidi': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '3kbblag3': {
      'en': 'Enter Act Early ID',
      'de': 'Geben Sie die Act Early-ID ein',
      'es': 'Ingresar ID de Actuar temprano',
      'fr': 'Entrez l\'identifiant Act Early',
      'hi': 'एक्ट अर्ली आईडी दर्ज करें',
      'zh_Hans': '输入 Act Early ID',
    },
    '84oi1vfa': {
      'en': 'OR ',
      'de': 'ODER',
      'es': 'O',
      'fr': 'OU',
      'hi': 'या',
      'zh_Hans': '或者',
    },
    '8v6qtu54': {
      'en': 'Generate ActEarly ID',
      'de': 'ActEarly-ID generieren',
      'es': 'Generar ID de ActEarly',
      'fr': 'Générer un identifiant ActEarly',
      'hi': 'ActEarly आईडी जनरेट करें',
      'zh_Hans': '生成 ActEarly ID',
    },
    'kwwc8hkm': {
      'en': 'Submit',
      'de': 'Einreichen',
      'es': 'Entregar',
      'fr': 'Soumettre',
      'hi': 'जमा करना',
      'zh_Hans': '提交',
    },
    'dhwij79e': {
      'en': 'Add Children',
      'de': 'Untergeordnete Elemente hinzufügen',
      'es': 'Agregar niños',
      'fr': 'Ajouter des enfants',
      'hi': 'बच्चे जोड़ें',
      'zh_Hans': '添加子项',
    },
  },
  // Settings
  {
    'mtnes8rc': {
      'en': 'Your Account',
      'de': 'Ihr Konto',
      'es': 'Su cuenta',
      'fr': 'Votre compte',
      'hi': 'आपका खाता',
      'zh_Hans': '您的帐户',
    },
    'fhid6na7': {
      'en': 'Switch to Dark Mode',
      'de': 'Wechseln Sie in den Dunkelmodus',
      'es': 'Cambiar al modo oscuro',
      'fr': 'Passer en mode sombre',
      'hi': 'डार्क मोड पर स्विच करें',
      'zh_Hans': '切换到暗模式',
    },
    'w6nbhmk0': {
      'en': 'Switch to Light Mode',
      'de': 'In den Lichtmodus wechseln',
      'es': 'Cambiar al modo claro',
      'fr': 'Passer en mode clair',
      'hi': 'लाइट मोड पर स्विच करें',
      'zh_Hans': '切换到灯光模式',
    },
    'xnyjbqlg': {
      'en': 'Account Settings',
      'de': 'Kontoeinstellungen',
      'es': 'Configuraciones de la cuenta',
      'fr': 'Paramètres du compte',
      'hi': 'अकाउंट सेटिंग',
      'zh_Hans': '帐户设置',
    },
    'refjwgkc': {
      'en': 'Change Password',
      'de': 'Kennwort ändern',
      'es': 'Cambiar la contraseña',
      'fr': 'Changer le mot de passe',
      'hi': 'पासवर्ड बदलें',
      'zh_Hans': '更改密码',
    },
    'vgmj58qs': {
      'en': 'Switch Data Storage',
      'de': 'Datenspeicher wechseln',
      'es': 'Cambiar almacenamiento de datos',
      'fr': 'Changer le stockage des données',
      'hi': 'डेटा संग्रहण स्विच करें',
      'zh_Hans': '切换数据存储',
    },
    'sjwkdgkh': {
      'en': 'Log Out',
      'de': 'Ausloggen',
      'es': 'Finalizar la sesión',
      'fr': 'Se déconnecter',
      'hi': 'लॉग आउट',
      'zh_Hans': '登出',
    },
    '0j3tu8n8': {
      'en': '__',
      'de': '__',
      'es': '__',
      'fr': '__',
      'hi': '__',
      'zh_Hans': '__',
    },
  },
  // ForgotPassword
  {
    'tx1zwj11': {
      'en': 'Back',
      'de': 'Zurück',
      'es': 'Atrás',
      'fr': 'Dos',
      'hi': 'पीछे',
      'zh_Hans': '后退',
    },
    'y0ou4oex': {
      'en': 'Forgot Password',
      'de': 'Passwort vergessen',
      'es': 'Has olvidado tu contraseña',
      'fr': 'Mot de passe oublié',
      'hi': 'पासवर्ड भूल गए',
      'zh_Hans': '忘记密码',
    },
    'labjsuct': {
      'en':
          'We will send you an email with a link to set your password, please enter the email associated with your account below.',
      'de':
          'Wir senden Ihnen eine E-Mail mit einem Link zum Festlegen Ihres Passworts. Bitte geben Sie unten die mit Ihrem Konto verknüpfte E-Mail-Adresse ein.',
      'es':
          'Le enviaremos un correo electrónico con un enlace para establecer su contraseña, ingrese el correo electrónico asociado a su cuenta a continuación.',
      'fr':
          'Nous vous enverrons un e-mail avec un lien pour définir votre mot de passe, veuillez saisir l\'e-mail associé à votre compte ci-dessous.',
      'hi':
          'हम आपको अपना पासवर्ड सेट करने के लिए एक लिंक के साथ एक ईमेल भेजेंगे, कृपया नीचे अपने खाते से संबद्ध ईमेल दर्ज करें।',
      'zh_Hans': '我们将向您发送一封电子邮件，其中包含设置密码的链接，请在下面输入与您的帐户关联的电子邮件。',
    },
    'ho921wjy': {
      'en': 'Your email address...',
      'de': 'Ihre E-Mail-Adresse...',
      'es': 'Su dirección de correo electrónico...',
      'fr': 'Votre adresse e-mail...',
      'hi': 'आपका ईमेल पता...',
      'zh_Hans': '您的电子邮件地址...',
    },
    'lgo45phy': {
      'en': 'Enter your email...',
      'de': 'Geben Sie Ihre E-Mail-Adresse ein.',
      'es': 'Introduce tu correo electrónico...',
      'fr': 'Entrez votre email...',
      'hi': 'अपना ईमेल दर्ज करें...',
      'zh_Hans': '输入您的电子邮件...',
    },
    'n2jx5hpi': {
      'en': 'Send Link',
      'de': 'Link senden',
      'es': 'Enviar enlace',
      'fr': 'Envoyer le lien',
      'hi': 'लिंक भेजें',
      'zh_Hans': '发送链接',
    },
    '8shqcew6': {
      'en': 'Back',
      'de': 'Zurück',
      'es': 'Atrás',
      'fr': 'Dos',
      'hi': 'पीछे',
      'zh_Hans': '后退',
    },
    '7ljl3ecw': {
      'en': 'Settings',
      'de': 'Einstellungen',
      'es': 'Ajustes',
      'fr': 'Paramètres',
      'hi': 'सेटिंग्स',
      'zh_Hans': '设置',
    },
  },
  // chat_ai_Screen
  {
    'lodyex2h': {
      'en': 'ActEarly AI',
      'de': 'ActEarly KI',
      'es': 'IA ActEarly',
      'fr': 'IA d\'ActEarly',
      'hi': 'एक्टअर्ली एआई',
      'zh_Hans': 'ActEarly AI',
    },
    'fekbx5k8': {
      'en': 'Copy response',
      'de': 'Antwort kopieren',
      'es': 'Copiar respuesta',
      'fr': 'Copier la réponse',
      'hi': 'प्रतिक्रिया कॉपी करें',
      'zh_Hans': '复制回复',
    },
    '7o9qkn3s': {
      'en': 'Type something...',
      'de': 'Geben Sie etwas ein ...',
      'es': 'Escribe algo...',
      'fr': 'Tapez quelque chose...',
      'hi': 'कुछ लिखें...',
      'zh_Hans': '输入一些内容...',
    },
    '6iu1blca': {
      'en': 'Chat',
      'de': 'Chat',
      'es': 'Charlar',
      'fr': 'Chat',
      'hi': 'बात करना',
      'zh_Hans': '聊天',
    },
  },
  // ChildViewPage
  {
    'lk4dstxs': {
      'en': 'Social',
      'de': 'Sozial',
      'es': 'Social',
      'fr': 'Sociale',
      'hi': 'सामाजिक',
      'zh_Hans': '社会的',
    },
    'a76np5in': {
      'en': 'Gross Motor',
      'de': 'Grobmotorik',
      'es': 'Motricidad gruesa',
      'fr': 'Motricité globale',
      'hi': 'सकल मोटर',
      'zh_Hans': '粗大运动',
    },
    'mhfja9pg': {
      'en': 'Fine Motor',
      'de': 'Feinmotorik',
      'es': 'Motricidad fina',
      'fr': 'Motricité fine',
      'hi': 'फ़ाइन मोटर',
      'zh_Hans': '精细动作',
    },
    'n7fwmvgo': {
      'en': 'Cognitive',
      'de': 'Kognitiv',
      'es': 'Cognitivo',
      'fr': 'Cognitif',
      'hi': 'संज्ञानात्मक',
      'zh_Hans': '认知的',
    },
    'mreuzu4a': {
      'en': 'ActEarly ID',
      'de': 'ActEarly-ID – Die ActEarly-ID',
      'es': 'Identificación de ActEarly',
      'fr': 'Identification ActEarly',
      'hi': 'एक्टअर्ली आईडी',
      'zh_Hans': 'ActEarly ID',
    },
    'y6y8qpgh': {
      'en': 'Your Child Milestones',
      'de': 'Meilensteine Ihres Kindes',
      'es': 'Los hitos de su hijo',
      'fr': 'Les étapes clés de la vie de votre enfant',
      'hi': 'आपके बच्चे की उपलब्धियाँ',
      'zh_Hans': '您的孩子成长里程碑',
    },
    'v3uum83t': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // SocialQuestionPage
  {
    '5j1jna4q': {
      'en': 'Social',
      'de': 'Sozial',
      'es': 'Social',
      'fr': 'Sociale',
      'hi': 'सामाजिक',
      'zh_Hans': '社会的',
    },
    '9gi8goqz': {
      'en': '[More Info]',
      'de': '[Weitere Informationen]',
      'es': '[Más información]',
      'fr': '[Plus d\'infos]',
      'hi': '[और जानकारी]',
      'zh_Hans': '[更多信息]',
    },
    '1ghye8os': {
      'en': 'Yes',
      'de': 'Ja',
      'es': 'Sí',
      'fr': 'Oui',
      'hi': 'हाँ',
      'zh_Hans': '是的',
    },
    'vup9ih0q': {
      'en': 'Maybe',
      'de': 'Vielleicht',
      'es': 'Tal vez',
      'fr': 'Peut être',
      'hi': 'शायद',
      'zh_Hans': '或许',
    },
    '424n2cdj': {
      'en': 'No',
      'de': 'NEIN',
      'es': 'No',
      'fr': 'Non',
      'hi': 'नहीं',
      'zh_Hans': '不',
    },
    '0430vuc6': {
      'en': 'Save Answers',
      'de': 'Antworten speichern',
      'es': 'Guardar respuestas',
      'fr': 'Enregistrer les réponses',
      'hi': 'उत्तर सहेजें',
      'zh_Hans': '保存答案',
    },
    'iv7tiq6w': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // EditChildren
  {
    '7t6r8gyg': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'e5c9bnmv': {
      'en': 'Enter your Child Name',
      'de': 'Geben Sie den Namen Ihres Kindes ein',
      'es': 'Ingrese el nombre de su hijo',
      'fr': 'Entrez le nom de votre enfant',
      'hi': 'अपने बच्चे का नाम दर्ज करें',
      'zh_Hans': '输入您的孩子的名字',
    },
    'o94k6vxz': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'mlezcbp8': {
      'en': 'Enter your relation (Eg Mom/Dad)',
      'de': 'Geben Sie Ihre Beziehung ein (z. B. Mama/Papa)',
      'es': 'Ingresa tu relación (por ejemplo, mamá/papá)',
      'fr': 'Entrez votre relation (par exemple maman/papa)',
      'hi': 'अपना रिश्ता दर्ज करें (जैसे माँ/पिताजी)',
      'zh_Hans': '输入您的关系（例如妈妈/爸爸）',
    },
    'm1xe03xm': {
      'en': 'Was your child born prematurely?',
      'de': 'Ist Ihr Kind zu früh geboren worden?',
      'es': '¿Su hijo nació prematuramente?',
      'fr': 'Votre enfant est né prématurément ?',
      'hi': 'क्या आपका बच्चा समय से पहले पैदा हुआ था?',
      'zh_Hans': '您的孩子是早产吗？',
    },
    '07y6vz2v': {
      'en': 'Male',
      'de': 'Männlich',
      'es': 'Masculino',
      'fr': 'Mâle',
      'hi': 'पुरुष',
      'zh_Hans': '男性',
    },
    'xdjznm6z': {
      'en': 'Female',
      'de': 'Weiblich',
      'es': 'Femenino',
      'fr': 'Femelle',
      'hi': 'महिला',
      'zh_Hans': '女性',
    },
    '31td3krh': {
      'en': 'Select your child gender',
      'de': 'Wählen Sie das Geschlecht Ihres Kindes aus',
      'es': 'Seleccione el género de su hijo',
      'fr': 'Sélectionnez le sexe de votre enfant',
      'hi': 'अपने बच्चे का लिंग चुनें',
      'zh_Hans': '选择您的孩子性别',
    },
    'xl6eadu4': {
      'en': 'Search for an item...',
      'de': 'Nach einem Artikel suchen...',
      'es': 'Buscar un artículo...',
      'fr': 'Rechercher un article...',
      'hi': 'किसी आइटम की खोज करें...',
      'zh_Hans': '搜索商品...',
    },
    'gcvuuepj': {
      'en': 'Save Changes',
      'de': 'Änderungen speichern',
      'es': 'Guardar cambios',
      'fr': 'Enregistrer les modifications',
      'hi': 'परिवर्तनों को सुरक्षित करें',
      'zh_Hans': '保存更改',
    },
    'y287kv8c': {
      'en': 'Edit Child Details',
      'de': 'Untergeordnete Details bearbeiten',
      'es': 'Editar detalles del niño',
      'fr': 'Modifier les détails de l\'enfant',
      'hi': 'बच्चे का विवरण संपादित करें',
      'zh_Hans': '编辑儿童详情',
    },
    's0texe3r': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // GrossMotorQuestionPage
  {
    'f1ja03ux': {
      'en': 'Gross Motor',
      'de': 'Grobmotorik',
      'es': 'Motricidad gruesa',
      'fr': 'Motricité globale',
      'hi': 'सकल मोटर',
      'zh_Hans': '粗大运动',
    },
    'qxwqih1u': {
      'en': '[More Info]',
      'de': '[Weitere Informationen]',
      'es': '[Más información]',
      'fr': '[Plus d\'infos]',
      'hi': '[और जानकारी]',
      'zh_Hans': '[更多信息]',
    },
    'j6bardas': {
      'en': 'Yes ',
      'de': 'Ja',
      'es': 'Sí',
      'fr': 'Oui',
      'hi': 'हाँ',
      'zh_Hans': '是的',
    },
    'aw5rtxxd': {
      'en': 'Maybe',
      'de': 'Vielleicht',
      'es': 'Tal vez',
      'fr': 'Peut être',
      'hi': 'शायद',
      'zh_Hans': '或许',
    },
    '4vl0xsy3': {
      'en': 'No',
      'de': 'NEIN',
      'es': 'No',
      'fr': 'Non',
      'hi': 'नहीं',
      'zh_Hans': '不',
    },
    '765fgtei': {
      'en': 'Save Answers',
      'de': 'Antworten speichern',
      'es': 'Guardar respuestas',
      'fr': 'Enregistrer les réponses',
      'hi': 'उत्तर सहेजें',
      'zh_Hans': '保存答案',
    },
    '9crewi5g': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // FineMotorQuestionPage
  {
    'zw3i4wgy': {
      'en': 'Fine Motor',
      'de': 'Feinmotorik',
      'es': 'Motricidad fina',
      'fr': 'Motricité fine',
      'hi': 'फ़ाइन मोटर',
      'zh_Hans': '精细动作',
    },
    'lkhhfcca': {
      'en': '[More Info]',
      'de': '[Weitere Informationen]',
      'es': '[Más información]',
      'fr': '[Plus d\'infos]',
      'hi': '[और जानकारी]',
      'zh_Hans': '[更多信息]',
    },
    'f1v5mcj3': {
      'en': 'Yes ',
      'de': 'Ja',
      'es': 'Sí',
      'fr': 'Oui',
      'hi': 'हाँ',
      'zh_Hans': '是的',
    },
    'quknb04k': {
      'en': 'Maybe',
      'de': 'Vielleicht',
      'es': 'Tal vez',
      'fr': 'Peut être',
      'hi': 'शायद',
      'zh_Hans': '或许',
    },
    '9shwubaa': {
      'en': 'No',
      'de': 'NEIN',
      'es': 'No',
      'fr': 'Non',
      'hi': 'नहीं',
      'zh_Hans': '不',
    },
    '3vn7hf7p': {
      'en': 'Save Answers',
      'de': 'Antworten speichern',
      'es': 'Guardar respuestas',
      'fr': 'Enregistrer les réponses',
      'hi': 'उत्तर सहेजें',
      'zh_Hans': '保存答案',
    },
    'lek6fuck': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // CognitiveQuestionPage
  {
    '3k6i2nlf': {
      'en': 'Cognitive',
      'de': 'Kognitiv',
      'es': 'Cognitivo',
      'fr': 'Cognitif',
      'hi': 'संज्ञानात्मक',
      'zh_Hans': '认知的',
    },
    'v40d57xd': {
      'en': '[More Info]',
      'de': '[Weitere Informationen]',
      'es': '[Más información]',
      'fr': '[Plus d\'infos]',
      'hi': '[और जानकारी]',
      'zh_Hans': '[更多信息]',
    },
    'hejjjb4r': {
      'en': 'Yes',
      'de': 'Ja',
      'es': 'Sí',
      'fr': 'Oui',
      'hi': 'हाँ',
      'zh_Hans': '是的',
    },
    'mdjuazqw': {
      'en': 'Maybe',
      'de': 'Vielleicht',
      'es': 'Tal vez',
      'fr': 'Peut être',
      'hi': 'शायद',
      'zh_Hans': '或许',
    },
    'rcmn9jgt': {
      'en': 'No',
      'de': 'NEIN',
      'es': 'No',
      'fr': 'Non',
      'hi': 'नहीं',
      'zh_Hans': '不',
    },
    'hj9o03oh': {
      'en': 'Save Answers',
      'de': 'Antworten speichern',
      'es': 'Guardar respuestas',
      'fr': 'Enregistrer les réponses',
      'hi': 'उत्तर सहेजें',
      'zh_Hans': '保存答案',
    },
    'dtiit49e': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // confirmAddChildPage
  {
    'lfzw8djd': {
      'en': 'Add Child?',
      'de': 'Kind hinzufügen?',
      'es': '¿Añadir niño?',
      'fr': 'Ajouter un enfant ?',
      'hi': 'बच्चे को जोड़ें?',
      'zh_Hans': '添加孩子？',
    },
    'fp8dbc05': {
      'en': 'Yes',
      'de': 'Ja',
      'es': 'Sí',
      'fr': 'Oui',
      'hi': 'हाँ',
      'zh_Hans': '是的',
    },
    'dud2ouav': {
      'en': 'No',
      'de': 'NEIN',
      'es': 'No',
      'fr': 'Non',
      'hi': 'नहीं',
      'zh_Hans': '不',
    },
    '3p5pg7ag': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // SwitchStoragePage
  {
    'mtzdoic4': {
      'en': 'Switch Data Storage',
      'de': 'Datenspeicher wechseln',
      'es': 'Cambiar almacenamiento de datos',
      'fr': 'Changer le stockage des données',
      'hi': 'डेटा संग्रहण स्विच करें',
      'zh_Hans': '切换数据存储',
    },
    'qtxjtsos': {
      'en': 'Children\'s data in Cloud Storage :',
      'de': 'Kinderdaten im Cloud-Speicher:',
      'es': 'Datos de niños en almacenamiento en la nube:',
      'fr': 'Données des enfants dans le stockage cloud :',
      'hi': 'क्लाउड स्टोरेज में बच्चों का डेटा :',
      'zh_Hans': '儿童在云端存储中的数据：',
    },
    '8q6thisw': {
      'en': 'Transfer',
      'de': 'Überweisen',
      'es': 'Transferir',
      'fr': 'Transfert',
      'hi': 'स्थानांतरण',
      'zh_Hans': '转移',
    },
    '4dmc9caj': {
      'en': 'Children\'s data in Local Storage :',
      'de': 'Daten von Kindern im lokalen Speicher:',
      'es': 'Datos de niños en almacenamiento local:',
      'fr': 'Données des enfants dans le stockage local :',
      'hi': 'स्थानीय संग्रहण में बच्चों का डेटा :',
      'zh_Hans': '本地存储中的儿童数据：',
    },
    '3rod8p9q': {
      'en': 'Transfer',
      'de': 'Überweisen',
      'es': 'Transferir',
      'fr': 'Transfert',
      'hi': 'स्थानांतरण',
      'zh_Hans': '转移',
    },
    'kjoagm4l': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // TermsAndConditions
  {
    'xwormggw': {
      'en': 'Terms and Conditions of Use\n for the \"ActEarly\" Application',
      'de': 'Nutzungsbedingungen\nfür die Anwendung „ActEarly“',
      'es': 'Términos y condiciones de uso\nde la aplicación \"ActEarly\"',
      'fr':
          'Conditions générales d\'utilisation\nde l\'application « ActEarly »',
      'hi': '\"एक्टअर्ली\" एप्लीकेशन के लिए उपयोग की शर्तें और नियम',
      'zh_Hans': '“ActEarly” 应用程序的使用条款和条件',
    },
    'x0bhu7oa': {
      'en':
          ' Welcome to ActEarly, an application that allows you to monitor the social, physical, and psychological progress of your baby from their early months up to 5 years of age. Before using this application, please read and understand the following Terms and Conditions, as they constitute a legal agreement between you (the \"User\") and ActEarly.\n\n- Acceptance of Terms: By using the ActEarly application, the User automatically and unconditionally accepts these Terms and Conditions. If the User does not agree with any aspect of these Terms, please refrain from using the application.\n- Purpose of the Application: ActEarly is a tool intended solely to enable users to track and monitor their baby\'s development and progress, including social, physical, and psychological aspects. The information provided by the application is based on user input and should not be considered professional medical diagnosis or advice.\n- Responsible Use: The User agrees to use the application responsibly and not to misuse, manipulate, or falsify any information entered into the application. The User also agrees not to use the application for any unlawful or harmful activities.',
      'de':
          'Willkommen bei ActEarly, einer Anwendung, mit der Sie die sozialen, physischen und psychischen Fortschritte Ihres Babys von den ersten Lebensmonaten bis zum Alter von 5 Jahren überwachen können. Bitte lesen und verstehen Sie die folgenden Geschäftsbedingungen, bevor Sie diese Anwendung verwenden, da sie eine rechtliche Vereinbarung zwischen Ihnen (dem „Benutzer“) und ActEarly darstellen.\n\n- Annahme der Bedingungen: Durch die Verwendung der ActEarly-Anwendung akzeptiert der Benutzer diese Geschäftsbedingungen automatisch und bedingungslos. Wenn der Benutzer mit irgendeinem Aspekt dieser Bedingungen nicht einverstanden ist, verwenden Sie die Anwendung bitte nicht.\n- Zweck der Anwendung: ActEarly ist ein Tool, das ausschließlich dazu dient, Benutzern die Verfolgung und Überwachung der Entwicklung und des Fortschritts ihres Babys zu ermöglichen, einschließlich sozialer, physischer und psychischer Aspekte. Die von der Anwendung bereitgestellten Informationen basieren auf Benutzereingaben und sollten nicht als professionelle medizinische Diagnose oder Beratung betrachtet werden.\n- Verantwortungsvolle Verwendung: Der Benutzer erklärt sich damit einverstanden, die Anwendung verantwortungsvoll zu verwenden und keine in die Anwendung eingegebenen Informationen zu missbrauchen, zu manipulieren oder zu verfälschen. Der Benutzer erklärt sich außerdem damit einverstanden, die Anwendung nicht für rechtswidrige oder schädliche Aktivitäten zu verwenden.',
      'es':
          'Bienvenido a ActEarly, una aplicación que te permite monitorear el progreso social, físico y psicológico de tu bebé desde sus primeros meses hasta los 5 años de edad. Antes de utilizar esta aplicación, lee y comprende los siguientes Términos y Condiciones, ya que constituyen un acuerdo legal entre tú (el \"Usuario\") y ActEarly.\n\n- Aceptación de Términos: Al utilizar la aplicación ActEarly, el Usuario acepta de manera automática e incondicional estos Términos y Condiciones. Si el Usuario no está de acuerdo con algún aspecto de estos Términos, absténgase de utilizar la aplicación.\n- Finalidad de la Aplicación: ActEarly es una herramienta destinada únicamente a permitir a los usuarios realizar un seguimiento y monitoreo del desarrollo y progreso de su bebé, incluidos los aspectos sociales, físicos y psicológicos. La información proporcionada por la aplicación se basa en la información proporcionada por el usuario y no debe considerarse un diagnóstico o consejo médico profesional.\n- Uso Responsable: El Usuario se compromete a utilizar la aplicación de manera responsable y a no hacer un mal uso, manipular o falsificar ninguna información ingresada en la aplicación. El Usuario también se compromete a no utilizar la aplicación para ninguna actividad ilegal o dañina.',
      'fr':
          'Bienvenue sur ActEarly, une application qui vous permet de suivre les progrès sociaux, physiques et psychologiques de votre bébé depuis ses premiers mois jusqu\'à ses 5 ans. Avant d\'utiliser cette application, veuillez lire et comprendre les Conditions générales suivantes, car elles constituent un accord juridique entre vous (l\'« Utilisateur ») et ActEarly.\n\n- Acceptation des conditions : En utilisant l\'application ActEarly, l\'utilisateur accepte automatiquement et sans condition ces Conditions générales. Si l\'utilisateur n\'est pas d\'accord avec un aspect quelconque de ces Conditions, veuillez vous abstenir d\'utiliser l\'application.\n- Objectif de l\'application : ActEarly est un outil destiné uniquement à permettre aux utilisateurs de suivre et de surveiller le développement et les progrès de leur bébé, y compris les aspects sociaux, physiques et psychologiques. Les informations fournies par l\'application sont basées sur les informations saisies par l\'utilisateur et ne doivent pas être considérées comme un diagnostic ou un conseil médical professionnel.\n- Utilisation responsable : L\'utilisateur s\'engage à utiliser l\'application de manière responsable et à ne pas abuser, manipuler ou falsifier les informations saisies dans l\'application. L\'Utilisateur s\'engage également à ne pas utiliser l\'application pour des activités illégales ou nuisibles.',
      'hi':
          'ActEarly में आपका स्वागत है, यह एक ऐसा एप्लिकेशन है जो आपको अपने बच्चे के शुरुआती महीनों से लेकर 5 साल की उम्र तक की सामाजिक, शारीरिक और मनोवैज्ञानिक प्रगति पर नज़र रखने की अनुमति देता है। इस एप्लिकेशन का उपयोग करने से पहले, कृपया निम्नलिखित नियम और शर्तों को पढ़ें और समझें, क्योंकि वे आपके (\"उपयोगकर्ता\") और ActEarly के बीच एक कानूनी समझौता बनाते हैं।\n\n- नियमों की स्वीकृति: ActEarly एप्लिकेशन का उपयोग करके, उपयोगकर्ता स्वचालित रूप से और बिना शर्त इन नियमों और शर्तों को स्वीकार करता है। यदि उपयोगकर्ता इन नियमों के किसी भी पहलू से सहमत नहीं है, तो कृपया एप्लिकेशन का उपयोग करने से बचें।\n- एप्लिकेशन का उद्देश्य: ActEarly एक ऐसा उपकरण है जिसका उद्देश्य केवल उपयोगकर्ताओं को अपने बच्चे के विकास और प्रगति को ट्रैक करने और निगरानी करने में सक्षम बनाना है, जिसमें सामाजिक, शारीरिक और मनोवैज्ञानिक पहलू शामिल हैं। एप्लिकेशन द्वारा प्रदान की गई जानकारी उपयोगकर्ता इनपुट पर आधारित है और इसे पेशेवर चिकित्सा निदान या सलाह नहीं माना जाना चाहिए।\n- जिम्मेदार उपयोग: उपयोगकर्ता एप्लिकेशन का जिम्मेदारी से उपयोग करने और एप्लिकेशन में दर्ज की गई किसी भी जानकारी का दुरुपयोग, हेरफेर या मिथ्याकरण नहीं करने के लिए सहमत है। उपयोगकर्ता किसी भी गैरकानूनी या हानिकारक गतिविधियों के लिए एप्लिकेशन का उपयोग नहीं करने के लिए भी सहमत है।',
      'zh_Hans':
          '欢迎使用 ActEarly，这是一款可让您监控宝宝从出生后几个月到 5 岁期间的社交、身体和心理发展的应用程序。在使用此应用程序之前，请阅读并理解以下条款和条件，因为它们构成您（“用户”）和 ActEarly 之间的法律协议。\n\n- 接受条款：通过使用 ActEarly 应用程序，用户自动且无条件地接受这些条款和条件。如果用户不同意这些条款的任何方面，请不要使用该应用程序。\n- 应用程序的目的：ActEarly 是一种工具，仅用于使用户能够跟踪和监控宝宝的发展和进步，包括社交、身体和心理方面。应用程序提供的信息基于用户输入，不应被视为专业医疗诊断或建议。\n- 负责任的使用：用户同意负责任地使用该应用程序，并且不会滥用、操纵或伪造输入到应用程序中的任何信息。用户还同意不将该应用程序用于任何非法或有害活动。',
    },
    'i5youf0w': {
      'en': 'Accept',
      'de': 'Akzeptieren',
      'es': 'Aceptar',
      'fr': 'Accepter',
      'hi': 'स्वीकार करना',
      'zh_Hans': '接受',
    },
    'nc06uvgn': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
  },
  // chat_ai_ScreenGemini
  {
    'zq04bbc2': {
      'en': 'ActEarly AI',
      'de': 'ActEarly KI',
      'es': 'IA ActEarly',
      'fr': 'IA d\'ActEarly',
      'hi': 'एक्टअर्ली एआई',
      'zh_Hans': 'ActEarly AI',
    },
    '7xbfebpq': {
      'en': 'Copy response',
      'de': 'Antwort kopieren',
      'es': 'Copiar respuesta',
      'fr': 'Copier la réponse',
      'hi': 'प्रतिक्रिया कॉपी करें',
      'zh_Hans': '复制回复',
    },
    '57ldrchm': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'jdqoefcv': {
      'en': 'Type something....',
      'de': 'Geben Sie etwas ein....',
      'es': 'Escribe algo....',
      'fr': 'Tapez quelque chose....',
      'hi': 'कुछ लिखें....',
      'zh_Hans': '输入一些内容....',
    },
    '8kjbg0ar': {
      'en': 'Chat',
      'de': 'Chat',
      'es': 'Charlar',
      'fr': 'Chat',
      'hi': 'बात करना',
      'zh_Hans': '聊天',
    },
  },
  // forMainPage
  {
    'qv28tx0a': {
      'en': 'Hello,',
      'de': 'Hallo,',
      'es': 'Hola,',
      'fr': 'Bonjour,',
      'hi': 'नमस्ते,',
      'zh_Hans': '你好，',
    },
    '8zy516sj': {
      'en':
          'Track Your Child\'s Growth: The Ultimate Child Development Tracker App',
      'de':
          'Verfolgen Sie das Wachstum Ihres Kindes: Die ultimative App zur Nachverfolgung der kindlichen Entwicklung',
      'es':
          'Siga el crecimiento de su hijo: la aplicación definitiva para el seguimiento del desarrollo infantil',
      'fr':
          'Suivez la croissance de votre enfant : l\'application ultime de suivi du développement de l\'enfant',
      'hi': 'अपने बच्चे के विकास पर नज़र रखें: सर्वश्रेष्ठ बाल विकास ट्रैकर ऐप',
      'zh_Hans': '追踪孩子的成长：终极儿童发育追踪应用程序',
    },
  },
  // emptyList
  {
    'xt138ogq': {
      'en': 'ActEarly AI',
      'de': 'ActEarly KI',
      'es': 'IA ActEarly',
      'fr': 'IA d\'ActEarly',
      'hi': 'एक्टअर्ली एआई',
      'zh_Hans': 'ActEarly AI',
    },
    'sze8aihv': {
      'en':
          'The following chatbot will be from sources such as the American Academy of Pediatrics (AAP), Centers for Disease Control and Prevention (CDC), World Health Organization (WHO), Zero to Three, HealthyChildren.org, National Institute of Child Health and Human Development (NICHD), Harvard Center on the Developing Child, and the American Psychological Association (APA).',
      'de':
          'Der folgende Chatbot stammt aus Quellen wie der American Academy of Pediatrics (AAP), den Centers for Disease Control and Prevention (CDC), der Weltgesundheitsorganisation (WHO), Zero to Three, HealthyChildren.org, dem National Institute of Child Health and Human Development (NICHD), dem Harvard Center on the Developing Child und der American Psychological Association (APA).',
      'es':
          'El siguiente chatbot provendrá de fuentes como la Academia Estadounidense de Pediatría (AAP), los Centros para el Control y la Prevención de Enfermedades (CDC), la Organización Mundial de la Salud (OMS), Zero to Three, HealthyChildren.org, el Instituto Nacional de Salud Infantil y Desarrollo Humano (NICHD), el Centro de Harvard sobre el Niño en Desarrollo y la Asociación Estadounidense de Psicología (APA).',
      'fr':
          'Le chatbot suivant proviendra de sources telles que l\'American Academy of Pediatrics (AAP), les Centers for Disease Control and Prevention (CDC), l\'Organisation mondiale de la santé (OMS), Zero to Three, HealthyChildren.org, le National Institute of Child Health and Human Development (NICHD), le Harvard Center on the Developing Child et l\'American Psychological Association (APA).',
      'hi':
          'निम्नलिखित चैटबॉट अमेरिकन एकेडमी ऑफ पीडियाट्रिक्स (एएपी), रोग नियंत्रण एवं रोकथाम केंद्र (सीडीसी), विश्व स्वास्थ्य संगठन (डब्ल्यूएचओ), जीरो टू थ्री, हेल्दीचाइल्ड्रेन.ओआरजी, राष्ट्रीय बाल स्वास्थ्य एवं मानव विकास संस्थान (एनआईसीएचडी), हार्वर्ड सेंटर ऑन द डेवलपिंग चाइल्ड और अमेरिकन साइकोलॉजिकल एसोसिएशन (एपीए) जैसे स्रोतों से होंगे।',
      'zh_Hans':
          '以下聊天机器人将来自美国儿科学会 (AAP)、疾病控制和预防中心 (CDC)、世界卫生组织 (WHO)、Zero to Three、HealthyChildren.org、国家儿童健康与人类发展研究所 (NICHD)、哈佛儿童发展中心和美国心理学会 (APA) 等来源。',
    },
  },
  // aiChat_Component
  {
    'xt2ydlp6': {
      'en': 'Copy response',
      'de': 'Antwort kopieren',
      'es': 'Copiar respuesta',
      'fr': 'Copier la réponse',
      'hi': 'प्रतिक्रिया कॉपी करें',
      'zh_Hans': '复制回复',
    },
    'trrvc1uy': {
      'en': 'Type something...',
      'de': 'Geben Sie etwas ein ...',
      'es': 'Escribe algo...',
      'fr': 'Tapez quelque chose...',
      'hi': 'कुछ लिखें...',
      'zh_Hans': '输入一些内容...',
    },
  },
  // emptyChildrenComponent
  {
    'ho7p7wfm': {
      'en': 'No Children Added',
      'de': 'Keine Kinder hinzugefügt',
      'es': 'No se agregaron niños',
      'fr': 'Aucun enfant ajouté',
      'hi': 'कोई बच्चा नहीं जोड़ा गया',
      'zh_Hans': '没有添加任何子项',
    },
    '4hduozof': {
      'en':
          'Add your children\'s profile now to track your child development milestones.',
      'de':
          'Fügen Sie jetzt das Profil Ihrer Kinder hinzu, um die Meilensteine der Entwicklung Ihres Kindes zu verfolgen.',
      'es':
          'Agregue el perfil de sus hijos ahora para realizar un seguimiento de los hitos del desarrollo de su hijo.',
      'fr':
          'Ajoutez maintenant le profil de vos enfants pour suivre les étapes de développement de votre enfant.',
      'hi':
          'अपने बच्चे के विकास की उपलब्धियों पर नज़र रखने के लिए अभी अपने बच्चे की प्रोफ़ाइल जोड़ें।',
      'zh_Hans': '立即添加您孩子的个人资料，以跟踪您孩子的成长里程碑。',
    },
  },
  // Miscellaneous
  {
    'cig9od9t': {
      'en': 'Home',
      'de': 'Heim',
      'es': 'Hogar',
      'fr': 'Maison',
      'hi': 'घर',
      'zh_Hans': '家',
    },
    '95jfbqz4': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '1y8v96nl': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'jp88vt9v': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'pqb4xxto': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '9x8dbg22': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'whgalnse': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'ima3arf3': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'zku7kywh': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'rvhlzly6': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '0ggqem1a': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '3l6bz0sr': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'ngtpakq7': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'ue5gpwk8': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'gub9ywx7': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '9zv0defr': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'rtex76oo': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'h2hsv2ct': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '23xzvjaz': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'y8br33tw': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'eb4fn8kf': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'or5s5g16': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'rbeqmz5f': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    's580dj2i': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '8a70pdic': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'yb9ke01w': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    'o918e4h7': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
    '83g2tnxe': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'hi': '',
      'zh_Hans': '',
    },
  },
].reduce((a, b) => a..addAll(b));
