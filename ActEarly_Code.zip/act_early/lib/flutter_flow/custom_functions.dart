import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

dynamic saveChatHistory(
  dynamic chatHistory,
  dynamic newChat,
) {
  // If chatHistory isn't a list, make it a list and then add newChat
  if (chatHistory is List) {
    chatHistory.add(newChat);
    return chatHistory;
  } else {
    return [newChat];
  }
}

dynamic convertToJSON(String prompt) {
  // take the prompt and return a JSON with form [{"role": "user", "content": prompt}]
  return json.decode('{"role": "user", "content": "$prompt"}');
}

String? grossMotor(String? input) {
  String? result;

  if (input == "at the end of 3 months") {
    result =
        "At the end of 3 months babies can:\n- Roll from front to back\n- Control head and neck movement when sitting\n- Raise head and chest when lying on stomach\n- Stretch out and kick legs\n- Push down with legs on firm surface";
  } else if (input == "at the end of 8 months") {
    result =
        "At the end of 8 months babies can:\n- Roll both ways (front to back, back to front)\n- Sit on their own\n- Support whole weight on legs\n- Control upper body and arms";
  } else if (input == "between 12 and 14 months") {
    result =
        "Between 12 to 14 months babies can:\n- Reach sitting position without help\n- Crawl on hands and knees, or scoot around on bum\n- Pull up to standing position\n- Cruise, holding onto furniture\n- Stand briefly without support\n- Walk holding adult’s hand\n- Maybe take 2 or 3 steps on their own\n-start to climb stairs with help";
  } else if (input == "at the end of 1.5 years") {
    result =
        "At 18 months babies can:\n- Climb into chairs\n- Walk without help\n- Climb stairs one at a time with help";
  } else if (input == "at the end of 2 years") {
    result =
        "At 24 months toddlers can:\n- Pull a toy while walking\n- Carry a large toy or more than one toy while walking\n- Begin to run\n- Kick or throw a ball\n- Climb into and get down from chairs without help\n- Walk up and down stairs with help";
  } else if (input == "at the end of 3 years") {
    result =
        "At 3 years old toddlers can:\n- Walk up and down stairs, alternating feet (one foot per stair)\n- Run easily\n- Jump in place\n- Throw a ball overhead";
  } else if (input == "at the end of 4 years") {
    result =
        "At 4 years old preschoolers can:\n- Hop and stand on 1 foot for up to 4 seconds\n- Kick a ball forward\n- Catch a bouncing ball";
  } else {
    result = "";
  }

  return result;
}

String? fineMotor(String? selectedValueDropDown) {
  String? result;

  if (selectedValueDropDown == "at the end of 3 months") {
    result =
        "At the end of 3 months babies can:\n- Bring their hands together\n- Open and shut their hands\n- Bring their hands to their mouth\n- Take swipes at a hanging object";
  } else if (selectedValueDropDown == "at the end of 8 months") {
    result =
        "At the end of 8 months babies can:\n- Hold and shake a hand toy\n- Move an object from hand to hand\n- Use their hands to explore an object";
  } else if (selectedValueDropDown == "between 12 and 14 months") {
    result =
        "Between 12 to 14 months babies can:\n- Finger-feed using thumb and forefinger (pincer grasp)\n- Put objects into a container (and take them out again)\n- Release objects voluntarily\n- Poke with an index finger\n- Scribble with a crayon\n- Begin to use a spoon";
  } else if (selectedValueDropDown == "at the end of 1.5 years") {
    result =
        "At 18 months babies can:\n- Build a 3-block tower\n- Use a spoon well\n- Turn a few board-book pages at a time\n- Turn over a container to pour out the contents\n- Drink easily from a cup";
  } else if (selectedValueDropDown == "at the end of 2 years") {
    result =
        "At 24 months toddlers can:\n- Complete a simple shape-matching puzzle\n- build a tower of 4 blocks or more\n- turn board-book pages easily, one at a time";
  } else if (selectedValueDropDown == "at the end of 3 years") {
    result =
        "At 3 years old toddlers can:\n- Make up-and-down, side-to-side, and circular lines with a pencil or crayon\n- Hold a pencil in a writing position\n- Screw and unscrew jar lids or big nuts and bolts\n- String big beads\n- Work latches and hooks\n- Snip with children's scissors";
  } else if (selectedValueDropDown == "at the end of 4 years") {
    result =
        "At 4 years old preschoolers can:\n- draw a person with 2 to 4 body parts\n- Use children's scissors\n- Draw circles and squares\n- Twiddle thumbs\n- Do a finger-to-thumb sequence (e.g., Itsy-Bitsy Spider)";
  } else {
    result = "";
  }

  return result;
}

String? socialLanguage(String? selectedValueDropDown) {
  String? result;

  if (selectedValueDropDown == "at the end of 3 months") {
    result =
        "At the end of 3 months babies can:\n- Smile when you smile and on their own\n- Be expressive and communicate with their face and body\n- Copy some body movements and facial expressions";
  } else if (selectedValueDropDown == "at the end of 8 months") {
    result =
        "At the end of 8 months babies can:\n- Reach for a person they know\n- Smile at themselves in a mirror\n- Respond when others express emotion\n- Copy speech sounds";
  } else if (selectedValueDropDown == "between 12 and 14 months") {
    result =
        "Between 12 to 14 months babies can:\n- Be shy or anxious with strangers\n- Copy during play\n- Have favorite toys and people\n- Respond to name\n- Say “mama” or “dada” with at least one other word with meaning\n- Communicate a need without crying\n- Stop an action if you say “no”";
  } else if (selectedValueDropDown == "at the end of 1.5 years") {
    result =
        "At 18 months babies can:\n- Remove some clothing on their own\n- Follow a simple instruction\n- follow a simple instruction\n- Point to a named body part\n- Point to familiar objects when asked\n- Help with simple tasks";
  } else if (selectedValueDropDown == "at the end of 2 years") {
    result =
        "At 24 months toddlers can:\n- Start to put 2 words together\n- Copy the behavior of adults and other children\n- Get excited about being with other children\n- Play alongside other children\n- Show increasing independence\n- Show defiant behavior";
  } else if (selectedValueDropDown == "at the end of 3 years") {
    result =
        "At 3 years old toddlers can:\n- Show spontaneous affection for playmates they know\n- Begin to take turns\n- Object to changes in routine\n- Anticipate daily activities\n- Speak in sentences and ask a lot of questions\n- Ask for help\n- Know their full name";
  } else if (selectedValueDropDown == "at the end of 4 years") {
    result =
        "At 4 years old preschoolers can:\n- Cooperate with other children\n- Play “Mom” or “Dad”\n- Be very inventive\n- Negotiate solutions to conflicts\n- Dress and undress\n- Imagine monsters";
  } else {
    result = "";
  }

  return result;
}

String? cognitive(String? selectedValueDropDown) {
  String? result;

  if (selectedValueDropDown == "at the end of 3 months") {
    result =
        "At the end of 3 months babies can:\n- Watch faces closely\n- Follow moving objects\n- Recognize objects and people they know";
  } else if (selectedValueDropDown == "at the end of 8 months") {
    result =
        "At the end of 8 months babies can:\n- Track a moving object and find one that is partially hidden\n- Explore with hands and mouth\n- Look from one object to another\n- Watch a falling object";
  } else if (selectedValueDropDown == "between 12 and 14 months") {
    result =
        "Between 12 to 14 months babies can:\n- Explore objects in different ways (shaking, banging, throwing, dropping)\n- Struggle to get objects that are out of reach\n- Begin to explore cause and effect";
  } else if (selectedValueDropDown == "at the end of 1.5 years") {
    result =
        "At 18 months babies can:\n- use objects as tools\n- fit related objects together (e.g., in a shape sorter)";
  } else if (selectedValueDropDown == "at the end of 2 years") {
    result = "At 24 months toddlers can:\n- begin “make-believe” play";
  } else if (selectedValueDropDown == "at the end of 3 years") {
    result =
        "At 3 years old toddlers can:\n- Match an object in their hand or the room to a picture in a book\n- Include animals, dolls and people in make-believe play\n- Sort easily by shape and colour\n- Complete a puzzle with 3 or 4 pieces\n- Understand the difference between 1 and 2\n- Name body parts and colours";
  } else if (selectedValueDropDown == "at the end of 4 years") {
    result =
        "At 4 years old preschoolers can:\n- Understand counting\n- Follow a 3-part instruction\n- Make up and tell simple stories\n- Enjoy fantasy play\n- Understand “same” and “different”";
  } else {
    result = "";
  }

  return result;
}

String? dateOfBirthToAge(DateTime? inputDate) {
  if (inputDate == null) {
    return null;
  }

  final now = DateTime.now();
  final difference = now.difference(inputDate);

  final years = (difference.inDays / 365).floor();
  final months = ((difference.inDays % 365) / 30).floor();

  if (years > 0) {
    return years == 1 ? '1 year' : '$years years';
  } else if (months > 0) {
    return months == 1 ? '1 month' : '$months months';
  } else {
    return 'less than a month';
  }
}

int? answersValueToPercentage(List<AnswerValueStruct>? dataList) {
  if (dataList == null || dataList.isEmpty) {
    return 0;
  }

  // Initialize the count for "yes" answers and a separate count for maybe answers
  int yesCount = 0;
  int maybeCount = 0;

  // Iterate through the dataList and count "yes" and "maybe" entries
  for (var item in dataList) {
    if (item.answer.toLowerCase() == 'yes') {
      yesCount++;
    } else if (item.answer.toLowerCase() == 'maybe') {
      maybeCount++;
    }
  }

  // Calculate the total count of yes answers, considering maybe as 50% yes
  int totalYesCount = yesCount * 2 + maybeCount;

  // Calculate the total possible count, considering maybe as a whole entry
  int totalPossibleCount = dataList.length * 2;

  // Calculate the percentage
  double percentage = (totalYesCount / totalPossibleCount) * 100;

  // Return the percentage as an integer
  return percentage.toInt();
}

double? divideBy100(int? input) {
  // create a simple function to divide the input integer by 100
  if (input == null) {
    return null;
  }
  return input / 100;
}
