import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChildsRecord extends FirestoreRecord {
  ChildsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "childName" field.
  String? _childName;
  String get childName => _childName ?? '';
  bool hasChildName() => _childName != null;

  // "childImage" field.
  String? _childImage;
  String get childImage => _childImage ?? '';
  bool hasChildImage() => _childImage != null;

  // "relationWithChild" field.
  String? _relationWithChild;
  String get relationWithChild => _relationWithChild ?? '';
  bool hasRelationWithChild() => _relationWithChild != null;

  // "childGender" field.
  String? _childGender;
  String get childGender => _childGender ?? '';
  bool hasChildGender() => _childGender != null;

  // "childPremature" field.
  bool? _childPremature;
  bool get childPremature => _childPremature ?? false;
  bool hasChildPremature() => _childPremature != null;

  // "childDateOfBirth" field.
  DateTime? _childDateOfBirth;
  DateTime? get childDateOfBirth => _childDateOfBirth;
  bool hasChildDateOfBirth() => _childDateOfBirth != null;

  // "childAge" field.
  String? _childAge;
  String get childAge => _childAge ?? '';
  bool hasChildAge() => _childAge != null;

  // "socialQuestion" field.
  List<AnswerValueStruct>? _socialQuestion;
  List<AnswerValueStruct> get socialQuestion => _socialQuestion ?? const [];
  bool hasSocialQuestion() => _socialQuestion != null;

  // "fineMotorQuestions" field.
  List<AnswerValueStruct>? _fineMotorQuestions;
  List<AnswerValueStruct> get fineMotorQuestions =>
      _fineMotorQuestions ?? const [];
  bool hasFineMotorQuestions() => _fineMotorQuestions != null;

  // "grossMotorQuestions" field.
  List<AnswerValueStruct>? _grossMotorQuestions;
  List<AnswerValueStruct> get grossMotorQuestions =>
      _grossMotorQuestions ?? const [];
  bool hasGrossMotorQuestions() => _grossMotorQuestions != null;

  // "cognitiveQuestions" field.
  List<AnswerValueStruct>? _cognitiveQuestions;
  List<AnswerValueStruct> get cognitiveQuestions =>
      _cognitiveQuestions ?? const [];
  bool hasCognitiveQuestions() => _cognitiveQuestions != null;

  // "actEarlyID" field.
  String? _actEarlyID;
  String get actEarlyID => _actEarlyID ?? '';
  bool hasActEarlyID() => _actEarlyID != null;

  // "parentID" field.
  List<ActEarlyidDataStruct>? _parentID;
  List<ActEarlyidDataStruct> get parentID => _parentID ?? const [];
  bool hasParentID() => _parentID != null;

  // "onlyParentID" field.
  List<String>? _onlyParentID;
  List<String> get onlyParentID => _onlyParentID ?? const [];
  bool hasOnlyParentID() => _onlyParentID != null;

  // "firsrtParentID" field.
  String? _firsrtParentID;
  String get firsrtParentID => _firsrtParentID ?? '';
  bool hasFirsrtParentID() => _firsrtParentID != null;

  // "socialLinks" field.
  List<String>? _socialLinks;
  List<String> get socialLinks => _socialLinks ?? const [];
  bool hasSocialLinks() => _socialLinks != null;

  // "fineMotorLinks" field.
  List<String>? _fineMotorLinks;
  List<String> get fineMotorLinks => _fineMotorLinks ?? const [];
  bool hasFineMotorLinks() => _fineMotorLinks != null;

  // "grossMotorLinks" field.
  List<String>? _grossMotorLinks;
  List<String> get grossMotorLinks => _grossMotorLinks ?? const [];
  bool hasGrossMotorLinks() => _grossMotorLinks != null;

  // "cognitiveLinks" field.
  List<String>? _cognitiveLinks;
  List<String> get cognitiveLinks => _cognitiveLinks ?? const [];
  bool hasCognitiveLinks() => _cognitiveLinks != null;

  void _initializeFields() {
    _childName = snapshotData['childName'] as String?;
    _childImage = snapshotData['childImage'] as String?;
    _relationWithChild = snapshotData['relationWithChild'] as String?;
    _childGender = snapshotData['childGender'] as String?;
    _childPremature = snapshotData['childPremature'] as bool?;
    _childDateOfBirth = snapshotData['childDateOfBirth'] as DateTime?;
    _childAge = snapshotData['childAge'] as String?;
    _socialQuestion = getStructList(
      snapshotData['socialQuestion'],
      AnswerValueStruct.fromMap,
    );
    _fineMotorQuestions = getStructList(
      snapshotData['fineMotorQuestions'],
      AnswerValueStruct.fromMap,
    );
    _grossMotorQuestions = getStructList(
      snapshotData['grossMotorQuestions'],
      AnswerValueStruct.fromMap,
    );
    _cognitiveQuestions = getStructList(
      snapshotData['cognitiveQuestions'],
      AnswerValueStruct.fromMap,
    );
    _actEarlyID = snapshotData['actEarlyID'] as String?;
    _parentID = getStructList(
      snapshotData['parentID'],
      ActEarlyidDataStruct.fromMap,
    );
    _onlyParentID = getDataList(snapshotData['onlyParentID']);
    _firsrtParentID = snapshotData['firsrtParentID'] as String?;
    _socialLinks = getDataList(snapshotData['socialLinks']);
    _fineMotorLinks = getDataList(snapshotData['fineMotorLinks']);
    _grossMotorLinks = getDataList(snapshotData['grossMotorLinks']);
    _cognitiveLinks = getDataList(snapshotData['cognitiveLinks']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('childs');

  static Stream<ChildsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChildsRecord.fromSnapshot(s));

  static Future<ChildsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChildsRecord.fromSnapshot(s));

  static ChildsRecord fromSnapshot(DocumentSnapshot snapshot) => ChildsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChildsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChildsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChildsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChildsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChildsRecordData({
  String? childName,
  String? childImage,
  String? relationWithChild,
  String? childGender,
  bool? childPremature,
  DateTime? childDateOfBirth,
  String? childAge,
  String? actEarlyID,
  String? firsrtParentID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'childName': childName,
      'childImage': childImage,
      'relationWithChild': relationWithChild,
      'childGender': childGender,
      'childPremature': childPremature,
      'childDateOfBirth': childDateOfBirth,
      'childAge': childAge,
      'actEarlyID': actEarlyID,
      'firsrtParentID': firsrtParentID,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChildsRecordDocumentEquality implements Equality<ChildsRecord> {
  const ChildsRecordDocumentEquality();

  @override
  bool equals(ChildsRecord? e1, ChildsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.childName == e2?.childName &&
        e1?.childImage == e2?.childImage &&
        e1?.relationWithChild == e2?.relationWithChild &&
        e1?.childGender == e2?.childGender &&
        e1?.childPremature == e2?.childPremature &&
        e1?.childDateOfBirth == e2?.childDateOfBirth &&
        e1?.childAge == e2?.childAge &&
        listEquality.equals(e1?.socialQuestion, e2?.socialQuestion) &&
        listEquality.equals(e1?.fineMotorQuestions, e2?.fineMotorQuestions) &&
        listEquality.equals(e1?.grossMotorQuestions, e2?.grossMotorQuestions) &&
        listEquality.equals(e1?.cognitiveQuestions, e2?.cognitiveQuestions) &&
        e1?.actEarlyID == e2?.actEarlyID &&
        listEquality.equals(e1?.parentID, e2?.parentID) &&
        listEquality.equals(e1?.onlyParentID, e2?.onlyParentID) &&
        e1?.firsrtParentID == e2?.firsrtParentID &&
        listEquality.equals(e1?.socialLinks, e2?.socialLinks) &&
        listEquality.equals(e1?.fineMotorLinks, e2?.fineMotorLinks) &&
        listEquality.equals(e1?.grossMotorLinks, e2?.grossMotorLinks) &&
        listEquality.equals(e1?.cognitiveLinks, e2?.cognitiveLinks);
  }

  @override
  int hash(ChildsRecord? e) => const ListEquality().hash([
        e?.childName,
        e?.childImage,
        e?.relationWithChild,
        e?.childGender,
        e?.childPremature,
        e?.childDateOfBirth,
        e?.childAge,
        e?.socialQuestion,
        e?.fineMotorQuestions,
        e?.grossMotorQuestions,
        e?.cognitiveQuestions,
        e?.actEarlyID,
        e?.parentID,
        e?.onlyParentID,
        e?.firsrtParentID,
        e?.socialLinks,
        e?.fineMotorLinks,
        e?.grossMotorLinks,
        e?.cognitiveLinks
      ]);

  @override
  bool isValidKey(Object? o) => o is ChildsRecord;
}
