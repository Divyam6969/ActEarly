// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ActEarlyidDataStruct extends FFFirebaseStruct {
  ActEarlyidDataStruct({
    String? relation,
    String? userID,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _relation = relation,
        _userID = userID,
        super(firestoreUtilData);

  // "relation" field.
  String? _relation;
  String get relation => _relation ?? '';
  set relation(String? val) => _relation = val;

  bool hasRelation() => _relation != null;

  // "userID" field.
  String? _userID;
  String get userID => _userID ?? '';
  set userID(String? val) => _userID = val;

  bool hasUserID() => _userID != null;

  static ActEarlyidDataStruct fromMap(Map<String, dynamic> data) =>
      ActEarlyidDataStruct(
        relation: data['relation'] as String?,
        userID: data['userID'] as String?,
      );

  static ActEarlyidDataStruct? maybeFromMap(dynamic data) => data is Map
      ? ActEarlyidDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'relation': _relation,
        'userID': _userID,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'relation': serializeParam(
          _relation,
          ParamType.String,
        ),
        'userID': serializeParam(
          _userID,
          ParamType.String,
        ),
      }.withoutNulls;

  static ActEarlyidDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      ActEarlyidDataStruct(
        relation: deserializeParam(
          data['relation'],
          ParamType.String,
          false,
        ),
        userID: deserializeParam(
          data['userID'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'ActEarlyidDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ActEarlyidDataStruct &&
        relation == other.relation &&
        userID == other.userID;
  }

  @override
  int get hashCode => const ListEquality().hash([relation, userID]);
}

ActEarlyidDataStruct createActEarlyidDataStruct({
  String? relation,
  String? userID,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ActEarlyidDataStruct(
      relation: relation,
      userID: userID,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ActEarlyidDataStruct? updateActEarlyidDataStruct(
  ActEarlyidDataStruct? actEarlyidData, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    actEarlyidData
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addActEarlyidDataStructData(
  Map<String, dynamic> firestoreData,
  ActEarlyidDataStruct? actEarlyidData,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (actEarlyidData == null) {
    return;
  }
  if (actEarlyidData.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && actEarlyidData.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final actEarlyidDataData =
      getActEarlyidDataFirestoreData(actEarlyidData, forFieldValue);
  final nestedData =
      actEarlyidDataData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = actEarlyidData.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getActEarlyidDataFirestoreData(
  ActEarlyidDataStruct? actEarlyidData, [
  bool forFieldValue = false,
]) {
  if (actEarlyidData == null) {
    return {};
  }
  final firestoreData = mapToFirestore(actEarlyidData.toMap());

  // Add any Firestore field values
  actEarlyidData.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getActEarlyidDataListFirestoreData(
  List<ActEarlyidDataStruct>? actEarlyidDatas,
) =>
    actEarlyidDatas
        ?.map((e) => getActEarlyidDataFirestoreData(e, true))
        .toList() ??
    [];
