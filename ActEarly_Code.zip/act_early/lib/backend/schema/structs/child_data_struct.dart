// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChildDataStruct extends FFFirebaseStruct {
  ChildDataStruct({
    String? childName,
    String? childImage,
    String? relationWithChild,
    String? childGender,
    bool? childPremature,
    DateTime? childDateOfBirth,
    String? childAge,
    List<AnswerValueStruct>? socialQuestion,
    List<AnswerValueStruct>? fineMotorQuestions,
    List<AnswerValueStruct>? grossMotorQuestions,
    List<AnswerValueStruct>? cognitiveQuestions,
    String? actEarlyID,
    List<ActEarlyidDataStruct>? parentsRelation,
    List<String>? onlyParentId,
    String? firstParentID,
    List<String>? socialLinks,
    List<String>? fineMotorLinks,
    List<String>? grossMotorLinks,
    List<String>? cognitiveLinks,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _childName = childName,
        _childImage = childImage,
        _relationWithChild = relationWithChild,
        _childGender = childGender,
        _childPremature = childPremature,
        _childDateOfBirth = childDateOfBirth,
        _childAge = childAge,
        _socialQuestion = socialQuestion,
        _fineMotorQuestions = fineMotorQuestions,
        _grossMotorQuestions = grossMotorQuestions,
        _cognitiveQuestions = cognitiveQuestions,
        _actEarlyID = actEarlyID,
        _parentsRelation = parentsRelation,
        _onlyParentId = onlyParentId,
        _firstParentID = firstParentID,
        _socialLinks = socialLinks,
        _fineMotorLinks = fineMotorLinks,
        _grossMotorLinks = grossMotorLinks,
        _cognitiveLinks = cognitiveLinks,
        super(firestoreUtilData);

  // "childName" field.
  String? _childName;
  String get childName => _childName ?? '';
  set childName(String? val) => _childName = val;

  bool hasChildName() => _childName != null;

  // "childImage" field.
  String? _childImage;
  String get childImage => _childImage ?? '';
  set childImage(String? val) => _childImage = val;

  bool hasChildImage() => _childImage != null;

  // "relationWithChild" field.
  String? _relationWithChild;
  String get relationWithChild => _relationWithChild ?? '';
  set relationWithChild(String? val) => _relationWithChild = val;

  bool hasRelationWithChild() => _relationWithChild != null;

  // "childGender" field.
  String? _childGender;
  String get childGender => _childGender ?? '';
  set childGender(String? val) => _childGender = val;

  bool hasChildGender() => _childGender != null;

  // "childPremature" field.
  bool? _childPremature;
  bool get childPremature => _childPremature ?? false;
  set childPremature(bool? val) => _childPremature = val;

  bool hasChildPremature() => _childPremature != null;

  // "childDateOfBirth" field.
  DateTime? _childDateOfBirth;
  DateTime? get childDateOfBirth => _childDateOfBirth;
  set childDateOfBirth(DateTime? val) => _childDateOfBirth = val;

  bool hasChildDateOfBirth() => _childDateOfBirth != null;

  // "childAge" field.
  String? _childAge;
  String get childAge => _childAge ?? '';
  set childAge(String? val) => _childAge = val;

  bool hasChildAge() => _childAge != null;

  // "socialQuestion" field.
  List<AnswerValueStruct>? _socialQuestion;
  List<AnswerValueStruct> get socialQuestion => _socialQuestion ?? const [];
  set socialQuestion(List<AnswerValueStruct>? val) => _socialQuestion = val;

  void updateSocialQuestion(Function(List<AnswerValueStruct>) updateFn) {
    updateFn(_socialQuestion ??= []);
  }

  bool hasSocialQuestion() => _socialQuestion != null;

  // "fineMotorQuestions" field.
  List<AnswerValueStruct>? _fineMotorQuestions;
  List<AnswerValueStruct> get fineMotorQuestions =>
      _fineMotorQuestions ?? const [];
  set fineMotorQuestions(List<AnswerValueStruct>? val) =>
      _fineMotorQuestions = val;

  void updateFineMotorQuestions(Function(List<AnswerValueStruct>) updateFn) {
    updateFn(_fineMotorQuestions ??= []);
  }

  bool hasFineMotorQuestions() => _fineMotorQuestions != null;

  // "grossMotorQuestions" field.
  List<AnswerValueStruct>? _grossMotorQuestions;
  List<AnswerValueStruct> get grossMotorQuestions =>
      _grossMotorQuestions ?? const [];
  set grossMotorQuestions(List<AnswerValueStruct>? val) =>
      _grossMotorQuestions = val;

  void updateGrossMotorQuestions(Function(List<AnswerValueStruct>) updateFn) {
    updateFn(_grossMotorQuestions ??= []);
  }

  bool hasGrossMotorQuestions() => _grossMotorQuestions != null;

  // "cognitiveQuestions" field.
  List<AnswerValueStruct>? _cognitiveQuestions;
  List<AnswerValueStruct> get cognitiveQuestions =>
      _cognitiveQuestions ?? const [];
  set cognitiveQuestions(List<AnswerValueStruct>? val) =>
      _cognitiveQuestions = val;

  void updateCognitiveQuestions(Function(List<AnswerValueStruct>) updateFn) {
    updateFn(_cognitiveQuestions ??= []);
  }

  bool hasCognitiveQuestions() => _cognitiveQuestions != null;

  // "actEarlyID" field.
  String? _actEarlyID;
  String get actEarlyID => _actEarlyID ?? '';
  set actEarlyID(String? val) => _actEarlyID = val;

  bool hasActEarlyID() => _actEarlyID != null;

  // "parentsRelation" field.
  List<ActEarlyidDataStruct>? _parentsRelation;
  List<ActEarlyidDataStruct> get parentsRelation =>
      _parentsRelation ?? const [];
  set parentsRelation(List<ActEarlyidDataStruct>? val) =>
      _parentsRelation = val;

  void updateParentsRelation(Function(List<ActEarlyidDataStruct>) updateFn) {
    updateFn(_parentsRelation ??= []);
  }

  bool hasParentsRelation() => _parentsRelation != null;

  // "onlyParentId" field.
  List<String>? _onlyParentId;
  List<String> get onlyParentId => _onlyParentId ?? const [];
  set onlyParentId(List<String>? val) => _onlyParentId = val;

  void updateOnlyParentId(Function(List<String>) updateFn) {
    updateFn(_onlyParentId ??= []);
  }

  bool hasOnlyParentId() => _onlyParentId != null;

  // "firstParentID" field.
  String? _firstParentID;
  String get firstParentID => _firstParentID ?? '';
  set firstParentID(String? val) => _firstParentID = val;

  bool hasFirstParentID() => _firstParentID != null;

  // "socialLinks" field.
  List<String>? _socialLinks;
  List<String> get socialLinks => _socialLinks ?? const [];
  set socialLinks(List<String>? val) => _socialLinks = val;

  void updateSocialLinks(Function(List<String>) updateFn) {
    updateFn(_socialLinks ??= []);
  }

  bool hasSocialLinks() => _socialLinks != null;

  // "fineMotorLinks" field.
  List<String>? _fineMotorLinks;
  List<String> get fineMotorLinks => _fineMotorLinks ?? const [];
  set fineMotorLinks(List<String>? val) => _fineMotorLinks = val;

  void updateFineMotorLinks(Function(List<String>) updateFn) {
    updateFn(_fineMotorLinks ??= []);
  }

  bool hasFineMotorLinks() => _fineMotorLinks != null;

  // "grossMotorLinks" field.
  List<String>? _grossMotorLinks;
  List<String> get grossMotorLinks => _grossMotorLinks ?? const [];
  set grossMotorLinks(List<String>? val) => _grossMotorLinks = val;

  void updateGrossMotorLinks(Function(List<String>) updateFn) {
    updateFn(_grossMotorLinks ??= []);
  }

  bool hasGrossMotorLinks() => _grossMotorLinks != null;

  // "cognitiveLinks" field.
  List<String>? _cognitiveLinks;
  List<String> get cognitiveLinks => _cognitiveLinks ?? const [];
  set cognitiveLinks(List<String>? val) => _cognitiveLinks = val;

  void updateCognitiveLinks(Function(List<String>) updateFn) {
    updateFn(_cognitiveLinks ??= []);
  }

  bool hasCognitiveLinks() => _cognitiveLinks != null;

  static ChildDataStruct fromMap(Map<String, dynamic> data) => ChildDataStruct(
        childName: data['childName'] as String?,
        childImage: data['childImage'] as String?,
        relationWithChild: data['relationWithChild'] as String?,
        childGender: data['childGender'] as String?,
        childPremature: data['childPremature'] as bool?,
        childDateOfBirth: data['childDateOfBirth'] as DateTime?,
        childAge: data['childAge'] as String?,
        socialQuestion: getStructList(
          data['socialQuestion'],
          AnswerValueStruct.fromMap,
        ),
        fineMotorQuestions: getStructList(
          data['fineMotorQuestions'],
          AnswerValueStruct.fromMap,
        ),
        grossMotorQuestions: getStructList(
          data['grossMotorQuestions'],
          AnswerValueStruct.fromMap,
        ),
        cognitiveQuestions: getStructList(
          data['cognitiveQuestions'],
          AnswerValueStruct.fromMap,
        ),
        actEarlyID: data['actEarlyID'] as String?,
        parentsRelation: getStructList(
          data['parentsRelation'],
          ActEarlyidDataStruct.fromMap,
        ),
        onlyParentId: getDataList(data['onlyParentId']),
        firstParentID: data['firstParentID'] as String?,
        socialLinks: getDataList(data['socialLinks']),
        fineMotorLinks: getDataList(data['fineMotorLinks']),
        grossMotorLinks: getDataList(data['grossMotorLinks']),
        cognitiveLinks: getDataList(data['cognitiveLinks']),
      );

  static ChildDataStruct? maybeFromMap(dynamic data) => data is Map
      ? ChildDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'childName': _childName,
        'childImage': _childImage,
        'relationWithChild': _relationWithChild,
        'childGender': _childGender,
        'childPremature': _childPremature,
        'childDateOfBirth': _childDateOfBirth,
        'childAge': _childAge,
        'socialQuestion': _socialQuestion?.map((e) => e.toMap()).toList(),
        'fineMotorQuestions':
            _fineMotorQuestions?.map((e) => e.toMap()).toList(),
        'grossMotorQuestions':
            _grossMotorQuestions?.map((e) => e.toMap()).toList(),
        'cognitiveQuestions':
            _cognitiveQuestions?.map((e) => e.toMap()).toList(),
        'actEarlyID': _actEarlyID,
        'parentsRelation': _parentsRelation?.map((e) => e.toMap()).toList(),
        'onlyParentId': _onlyParentId,
        'firstParentID': _firstParentID,
        'socialLinks': _socialLinks,
        'fineMotorLinks': _fineMotorLinks,
        'grossMotorLinks': _grossMotorLinks,
        'cognitiveLinks': _cognitiveLinks,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'childName': serializeParam(
          _childName,
          ParamType.String,
        ),
        'childImage': serializeParam(
          _childImage,
          ParamType.String,
        ),
        'relationWithChild': serializeParam(
          _relationWithChild,
          ParamType.String,
        ),
        'childGender': serializeParam(
          _childGender,
          ParamType.String,
        ),
        'childPremature': serializeParam(
          _childPremature,
          ParamType.bool,
        ),
        'childDateOfBirth': serializeParam(
          _childDateOfBirth,
          ParamType.DateTime,
        ),
        'childAge': serializeParam(
          _childAge,
          ParamType.String,
        ),
        'socialQuestion': serializeParam(
          _socialQuestion,
          ParamType.DataStruct,
          isList: true,
        ),
        'fineMotorQuestions': serializeParam(
          _fineMotorQuestions,
          ParamType.DataStruct,
          isList: true,
        ),
        'grossMotorQuestions': serializeParam(
          _grossMotorQuestions,
          ParamType.DataStruct,
          isList: true,
        ),
        'cognitiveQuestions': serializeParam(
          _cognitiveQuestions,
          ParamType.DataStruct,
          isList: true,
        ),
        'actEarlyID': serializeParam(
          _actEarlyID,
          ParamType.String,
        ),
        'parentsRelation': serializeParam(
          _parentsRelation,
          ParamType.DataStruct,
          isList: true,
        ),
        'onlyParentId': serializeParam(
          _onlyParentId,
          ParamType.String,
          isList: true,
        ),
        'firstParentID': serializeParam(
          _firstParentID,
          ParamType.String,
        ),
        'socialLinks': serializeParam(
          _socialLinks,
          ParamType.String,
          isList: true,
        ),
        'fineMotorLinks': serializeParam(
          _fineMotorLinks,
          ParamType.String,
          isList: true,
        ),
        'grossMotorLinks': serializeParam(
          _grossMotorLinks,
          ParamType.String,
          isList: true,
        ),
        'cognitiveLinks': serializeParam(
          _cognitiveLinks,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static ChildDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      ChildDataStruct(
        childName: deserializeParam(
          data['childName'],
          ParamType.String,
          false,
        ),
        childImage: deserializeParam(
          data['childImage'],
          ParamType.String,
          false,
        ),
        relationWithChild: deserializeParam(
          data['relationWithChild'],
          ParamType.String,
          false,
        ),
        childGender: deserializeParam(
          data['childGender'],
          ParamType.String,
          false,
        ),
        childPremature: deserializeParam(
          data['childPremature'],
          ParamType.bool,
          false,
        ),
        childDateOfBirth: deserializeParam(
          data['childDateOfBirth'],
          ParamType.DateTime,
          false,
        ),
        childAge: deserializeParam(
          data['childAge'],
          ParamType.String,
          false,
        ),
        socialQuestion: deserializeStructParam<AnswerValueStruct>(
          data['socialQuestion'],
          ParamType.DataStruct,
          true,
          structBuilder: AnswerValueStruct.fromSerializableMap,
        ),
        fineMotorQuestions: deserializeStructParam<AnswerValueStruct>(
          data['fineMotorQuestions'],
          ParamType.DataStruct,
          true,
          structBuilder: AnswerValueStruct.fromSerializableMap,
        ),
        grossMotorQuestions: deserializeStructParam<AnswerValueStruct>(
          data['grossMotorQuestions'],
          ParamType.DataStruct,
          true,
          structBuilder: AnswerValueStruct.fromSerializableMap,
        ),
        cognitiveQuestions: deserializeStructParam<AnswerValueStruct>(
          data['cognitiveQuestions'],
          ParamType.DataStruct,
          true,
          structBuilder: AnswerValueStruct.fromSerializableMap,
        ),
        actEarlyID: deserializeParam(
          data['actEarlyID'],
          ParamType.String,
          false,
        ),
        parentsRelation: deserializeStructParam<ActEarlyidDataStruct>(
          data['parentsRelation'],
          ParamType.DataStruct,
          true,
          structBuilder: ActEarlyidDataStruct.fromSerializableMap,
        ),
        onlyParentId: deserializeParam<String>(
          data['onlyParentId'],
          ParamType.String,
          true,
        ),
        firstParentID: deserializeParam(
          data['firstParentID'],
          ParamType.String,
          false,
        ),
        socialLinks: deserializeParam<String>(
          data['socialLinks'],
          ParamType.String,
          true,
        ),
        fineMotorLinks: deserializeParam<String>(
          data['fineMotorLinks'],
          ParamType.String,
          true,
        ),
        grossMotorLinks: deserializeParam<String>(
          data['grossMotorLinks'],
          ParamType.String,
          true,
        ),
        cognitiveLinks: deserializeParam<String>(
          data['cognitiveLinks'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'ChildDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is ChildDataStruct &&
        childName == other.childName &&
        childImage == other.childImage &&
        relationWithChild == other.relationWithChild &&
        childGender == other.childGender &&
        childPremature == other.childPremature &&
        childDateOfBirth == other.childDateOfBirth &&
        childAge == other.childAge &&
        listEquality.equals(socialQuestion, other.socialQuestion) &&
        listEquality.equals(fineMotorQuestions, other.fineMotorQuestions) &&
        listEquality.equals(grossMotorQuestions, other.grossMotorQuestions) &&
        listEquality.equals(cognitiveQuestions, other.cognitiveQuestions) &&
        actEarlyID == other.actEarlyID &&
        listEquality.equals(parentsRelation, other.parentsRelation) &&
        listEquality.equals(onlyParentId, other.onlyParentId) &&
        firstParentID == other.firstParentID &&
        listEquality.equals(socialLinks, other.socialLinks) &&
        listEquality.equals(fineMotorLinks, other.fineMotorLinks) &&
        listEquality.equals(grossMotorLinks, other.grossMotorLinks) &&
        listEquality.equals(cognitiveLinks, other.cognitiveLinks);
  }

  @override
  int get hashCode => const ListEquality().hash([
        childName,
        childImage,
        relationWithChild,
        childGender,
        childPremature,
        childDateOfBirth,
        childAge,
        socialQuestion,
        fineMotorQuestions,
        grossMotorQuestions,
        cognitiveQuestions,
        actEarlyID,
        parentsRelation,
        onlyParentId,
        firstParentID,
        socialLinks,
        fineMotorLinks,
        grossMotorLinks,
        cognitiveLinks
      ]);
}

ChildDataStruct createChildDataStruct({
  String? childName,
  String? childImage,
  String? relationWithChild,
  String? childGender,
  bool? childPremature,
  DateTime? childDateOfBirth,
  String? childAge,
  String? actEarlyID,
  String? firstParentID,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ChildDataStruct(
      childName: childName,
      childImage: childImage,
      relationWithChild: relationWithChild,
      childGender: childGender,
      childPremature: childPremature,
      childDateOfBirth: childDateOfBirth,
      childAge: childAge,
      actEarlyID: actEarlyID,
      firstParentID: firstParentID,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ChildDataStruct? updateChildDataStruct(
  ChildDataStruct? childData, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    childData
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addChildDataStructData(
  Map<String, dynamic> firestoreData,
  ChildDataStruct? childData,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (childData == null) {
    return;
  }
  if (childData.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && childData.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final childDataData = getChildDataFirestoreData(childData, forFieldValue);
  final nestedData = childDataData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = childData.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getChildDataFirestoreData(
  ChildDataStruct? childData, [
  bool forFieldValue = false,
]) {
  if (childData == null) {
    return {};
  }
  final firestoreData = mapToFirestore(childData.toMap());

  // Add any Firestore field values
  childData.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getChildDataListFirestoreData(
  List<ChildDataStruct>? childDatas,
) =>
    childDatas?.map((e) => getChildDataFirestoreData(e, true)).toList() ?? [];
