import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCdoKj3cuzcPGhYmk3szrfqx76_LB0B_Lo",
            authDomain: "actearly-mitacs.firebaseapp.com",
            projectId: "actearly-mitacs",
            storageBucket: "actearly-mitacs.appspot.com",
            messagingSenderId: "955525963795",
            appId: "1:955525963795:web:35a603cdfc8ba2fc1a1fe6",
            measurementId: "G-Z27H19T0NS"));
  } else {
    await Firebase.initializeApp();
  }
}
