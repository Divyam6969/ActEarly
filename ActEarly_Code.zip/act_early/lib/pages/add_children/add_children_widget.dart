import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'add_children_model.dart';
export 'add_children_model.dart';

class AddChildrenWidget extends StatefulWidget {
  const AddChildrenWidget({super.key});

  @override
  State<AddChildrenWidget> createState() => _AddChildrenWidgetState();
}

class _AddChildrenWidgetState extends State<AddChildrenWidget> {
  late AddChildrenModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddChildrenModel());

    _model.registeredActEarlyIDTFTextController ??= TextEditingController();
    _model.registeredActEarlyIDTFFocusNode ??= FocusNode();

    _model.registeredRelationTfTextController ??= TextEditingController();
    _model.registeredRelationTfFocusNode ??= FocusNode();

    _model.textController3 ??= TextEditingController();
    _model.textFieldFocusNode1 ??= FocusNode();

    _model.textController4 ??= TextEditingController();
    _model.textFieldFocusNode2 ??= FocusNode();

    _model.relationTextFieldTextController ??= TextEditingController();
    _model.relationTextFieldFocusNode ??= FocusNode();

    _model.idTFTextController ??= TextEditingController();
    _model.idTFFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            FFLocalizations.of(context).getText(
              'oh8qox2e' /* Add Child */,
            ),
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              SwitchListTile.adaptive(
                value: _model.switchListTileValue ??= false,
                onChanged: (newValue) async {
                  setState(() => _model.switchListTileValue = newValue!);
                  if (newValue!) {
                    FFAppState().AlreadyRegistered = true;
                    setState(() {});
                  } else {
                    FFAppState().AlreadyRegistered = false;
                    setState(() {});
                  }
                },
                title: Text(
                  FFLocalizations.of(context).getText(
                    '2nqdrpaw' /* Child Already Registered? (No/... */,
                  ),
                  style: FlutterFlowTheme.of(context).titleLarge.override(
                        fontFamily: 'Outfit',
                        letterSpacing: 0.0,
                      ),
                ),
                tileColor: FlutterFlowTheme.of(context).secondaryBackground,
                activeColor: FlutterFlowTheme.of(context).primary,
                activeTrackColor: FlutterFlowTheme.of(context).accent1,
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
              if (FFAppState().AlreadyRegistered)
                Flexible(
                  child: Container(
                    width: 452.0,
                    height: 800.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(-1.0, 0.0),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                12.0, 8.0, 0.0, 2.0),
                            child: Text(
                              FFLocalizations.of(context).getText(
                                'o9wnrnhk' /* ActEarly ID is a unique ID giv... */,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    fontSize: 15.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 12.0, 12.0, 2.0),
                          child: TextFormField(
                            controller:
                                _model.registeredActEarlyIDTFTextController,
                            focusNode: _model.registeredActEarlyIDTFFocusNode,
                            autofocus: true,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: FFLocalizations.of(context).getText(
                                '90wpc54t' /* Enter the ActEarly ID */,
                              ),
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                              hintStyle: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).primary,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              errorBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              focusedErrorBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              contentPadding: EdgeInsetsDirectional.fromSTEB(
                                  4.0, 0.0, 0.0, 0.0),
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  letterSpacing: 0.0,
                                ),
                            maxLines: null,
                            validator: _model
                                .registeredActEarlyIDTFTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              12.0, 8.0, 12.0, 12.0),
                          child: TextFormField(
                            controller:
                                _model.registeredRelationTfTextController,
                            focusNode: _model.registeredRelationTfFocusNode,
                            autofocus: true,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: FFLocalizations.of(context).getText(
                                '2fv0ftul' /* What is your relation to this ... */,
                              ),
                              labelStyle: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                              hintStyle: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).alternate,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).primary,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              errorBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              focusedErrorBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 2.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              contentPadding: EdgeInsetsDirectional.fromSTEB(
                                  4.0, 0.0, 0.0, 0.0),
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  letterSpacing: 0.0,
                                ),
                            maxLines: null,
                            validator: _model
                                .registeredRelationTfTextControllerValidator
                                .asValidator(context),
                          ),
                        ),
                        Align(
                          alignment: AlignmentDirectional(-1.0, 0.0),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                12.0, 0.0, 0.0, 0.0),
                            child: FFButtonWidget(
                              onPressed: () async {
                                if ((_model.registeredActEarlyIDTFTextController
                                                .text ==
                                            null ||
                                        _model.registeredActEarlyIDTFTextController
                                                .text ==
                                            '') ||
                                    (_model.registeredRelationTfTextController
                                                .text ==
                                            null ||
                                        _model.registeredRelationTfTextController
                                                .text ==
                                            '')) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'Please fill all details!',
                                        style: TextStyle(
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                        ),
                                      ),
                                      duration: Duration(milliseconds: 4000),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context)
                                              .secondary,
                                    ),
                                  );
                                } else {
                                  _model.aaaaa1 = await queryChildsRecordOnce(
                                    queryBuilder: (childsRecord) =>
                                        childsRecord.where(
                                      'actEarlyID',
                                      isEqualTo: _model
                                          .registeredActEarlyIDTFTextController
                                          .text,
                                    ),
                                    singleRecord: true,
                                  ).then((s) => s.firstOrNull);
                                  if (_model.aaaaa1?.actEarlyID ==
                                      _model
                                          .registeredActEarlyIDTFTextController
                                          .text) {
                                    context.pushNamed(
                                      'confirmAddChildPage',
                                      queryParameters: {
                                        'actEarlyID': serializeParam(
                                          _model
                                              .registeredActEarlyIDTFTextController
                                              .text,
                                          ParamType.String,
                                        ),
                                        'relation': serializeParam(
                                          _model
                                              .registeredRelationTfTextController
                                              .text,
                                          ParamType.String,
                                        ),
                                      }.withoutNulls,
                                    );

                                    setState(() {
                                      _model
                                          .registeredActEarlyIDTFTextController
                                          ?.clear();
                                      _model.registeredRelationTfTextController
                                          ?.clear();
                                    });
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'No children found with the entered ActEarly ID!',
                                          style: TextStyle(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryText,
                                          ),
                                        ),
                                        duration: Duration(milliseconds: 4000),
                                        backgroundColor:
                                            FlutterFlowTheme.of(context)
                                                .secondary,
                                      ),
                                    );
                                  }
                                }

                                setState(() {});
                              },
                              text: FFLocalizations.of(context).getText(
                                'wfg7qzv7' /* Submit */,
                              ),
                              options: FFButtonOptions(
                                height: 40.0,
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    24.0, 0.0, 24.0, 0.0),
                                iconPadding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                color: FlutterFlowTheme.of(context).primary,
                                textStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      color: Colors.white,
                                      letterSpacing: 0.0,
                                    ),
                                elevation: 3.0,
                                borderSide: BorderSide(
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              if (!FFAppState().AlreadyRegistered)
                Flexible(
                  child: Container(
                    width: 452.0,
                    height: 800.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(-1.0, 0.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 5.0, 12.0, 22.0),
                              child: Text(
                                FFLocalizations.of(context).getText(
                                  'kzd7uobc' /*  Please share your little one'... */,
                                ),
                                textAlign: TextAlign.justify,
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Outfit',
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      fontSize: 15.0,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.normal,
                                    ),
                              ),
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Stack(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                children: [
                                  if (FFAppState().childImageURL != null &&
                                      FFAppState().childImageURL != '')
                                    Opacity(
                                      opacity: 0.8,
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            12.0, 0.0, 12.0, 0.0),
                                        child: Container(
                                          width: 120.0,
                                          height: 120.0,
                                          clipBehavior: Clip.antiAlias,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                          ),
                                          child: Image.network(
                                            FFAppState().childImageURL,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (FFAppState().childImageURL == null ||
                                      FFAppState().childImageURL == '')
                                    Opacity(
                                      opacity: 0.7,
                                      child: Container(
                                        width: 140.0,
                                        height: 140.0,
                                        clipBehavior: Clip.antiAlias,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.asset(
                                          'assets/images/Picture.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 10.0, 0.0, 0.0),
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        final selectedMedia =
                                            await selectMediaWithSourceBottomSheet(
                                          context: context,
                                          allowPhoto: true,
                                        );
                                        if (selectedMedia != null &&
                                            selectedMedia.every((m) =>
                                                validateFileFormat(
                                                    m.storagePath, context))) {
                                          setState(() =>
                                              _model.isDataUploading = true);
                                          var selectedUploadedFiles =
                                              <FFUploadedFile>[];

                                          var downloadUrls = <String>[];
                                          try {
                                            showUploadMessage(
                                              context,
                                              'Uploading file...',
                                              showLoading: true,
                                            );
                                            selectedUploadedFiles =
                                                selectedMedia
                                                    .map((m) => FFUploadedFile(
                                                          name: m.storagePath
                                                              .split('/')
                                                              .last,
                                                          bytes: m.bytes,
                                                          height: m.dimensions
                                                              ?.height,
                                                          width: m.dimensions
                                                              ?.width,
                                                          blurHash: m.blurHash,
                                                        ))
                                                    .toList();

                                            downloadUrls = (await Future.wait(
                                              selectedMedia.map(
                                                (m) async => await uploadData(
                                                    m.storagePath, m.bytes),
                                              ),
                                            ))
                                                .where((u) => u != null)
                                                .map((u) => u!)
                                                .toList();
                                          } finally {
                                            ScaffoldMessenger.of(context)
                                                .hideCurrentSnackBar();
                                            _model.isDataUploading = false;
                                          }
                                          if (selectedUploadedFiles.length ==
                                                  selectedMedia.length &&
                                              downloadUrls.length ==
                                                  selectedMedia.length) {
                                            setState(() {
                                              _model.uploadedLocalFile =
                                                  selectedUploadedFiles.first;
                                              _model.uploadedFileUrl =
                                                  downloadUrls.first;
                                            });
                                            showUploadMessage(
                                                context, 'Success!');
                                          } else {
                                            setState(() {});
                                            showUploadMessage(context,
                                                'Failed to upload data');
                                            return;
                                          }
                                        }

                                        FFAppState().childImageURL =
                                            _model.uploadedFileUrl;
                                        setState(() {});
                                      },
                                      child: Icon(
                                        Icons.photo_camera_outlined,
                                        color: FlutterFlowTheme.of(context)
                                            .accent4,
                                        size: 32.0,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Flexible(
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 20.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(),
                                        child: TextFormField(
                                          controller: _model.textController3,
                                          focusNode: _model.textFieldFocusNode1,
                                          autofocus: true,
                                          obscureText: false,
                                          decoration: InputDecoration(
                                            labelStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .override(
                                                      fontFamily: 'Readex Pro',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText:
                                                FFLocalizations.of(context)
                                                    .getText(
                                              'a2b2nxaf' /* Enter your Child Name */,
                                            ),
                                            hintStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 13.0,
                                                      letterSpacing: 0.0,
                                                    ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .alternate,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            errorBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .error,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            focusedErrorBorder:
                                                UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .error,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            contentPadding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    4.0, 0.0, 0.0, 0.0),
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                letterSpacing: 0.0,
                                              ),
                                          maxLines: null,
                                          validator: _model
                                              .textController3Validator
                                              .asValidator(context),
                                        ),
                                      ),
                                      Container(
                                        width: 250.0,
                                        decoration: BoxDecoration(),
                                        child: Stack(
                                          alignment:
                                              AlignmentDirectional(1.0, 0.0),
                                          children: [
                                            TextFormField(
                                              controller:
                                                  _model.textController4,
                                              focusNode:
                                                  _model.textFieldFocusNode2,
                                              autofocus: false,
                                              readOnly: true,
                                              obscureText: false,
                                              decoration: InputDecoration(
                                                labelStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          letterSpacing: 0.0,
                                                        ),
                                                hintStyle: FlutterFlowTheme.of(
                                                        context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Readex Pro',
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondaryText,
                                                      fontSize: 13.0,
                                                      letterSpacing: 0.0,
                                                    ),
                                                enabledBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .alternate,
                                                    width: 2.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                                focusedBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primary,
                                                    width: 2.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                                errorBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .error,
                                                    width: 2.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                                focusedErrorBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .error,
                                                    width: 2.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                ),
                                                contentPadding:
                                                    EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            4.0, 0.0, 0.0, 0.0),
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Outfit',
                                                        letterSpacing: 0.0,
                                                      ),
                                              maxLines: null,
                                              validator: _model
                                                  .textController4Validator
                                                  .asValidator(context),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 25.0, 0.0),
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  final _datePickedDate =
                                                      await showDatePicker(
                                                    context: context,
                                                    initialDate:
                                                        getCurrentTimestamp,
                                                    firstDate: DateTime(1900),
                                                    lastDate:
                                                        getCurrentTimestamp,
                                                    builder: (context, child) {
                                                      return wrapInMaterialDatePickerTheme(
                                                        context,
                                                        child!,
                                                        headerBackgroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primary,
                                                        headerForegroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .info,
                                                        headerTextStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineLarge
                                                                .override(
                                                                  fontFamily:
                                                                      'Outfit',
                                                                  fontSize:
                                                                      32.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                ),
                                                        pickerBackgroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryBackground,
                                                        pickerForegroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        selectedDateTimeBackgroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primary,
                                                        selectedDateTimeForegroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .info,
                                                        actionButtonForegroundColor:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        iconSize: 24.0,
                                                      );
                                                    },
                                                  );

                                                  if (_datePickedDate != null) {
                                                    safeSetState(() {
                                                      _model.datePicked =
                                                          DateTime(
                                                        _datePickedDate.year,
                                                        _datePickedDate.month,
                                                        _datePickedDate.day,
                                                      );
                                                    });
                                                  }
                                                  FFAppState().birthDate =
                                                      _model.datePicked;
                                                  setState(() {});
                                                },
                                                child: Icon(
                                                  Icons.add,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryText,
                                                  size: 24.0,
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: AlignmentDirectional(
                                                  -1.0, 0.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        6.0, 0.0, 0.0, 0.0),
                                                child: Text(
                                                  valueOrDefault<String>(
                                                    dateTimeFormat(
                                                      "d/M/y",
                                                      FFAppState().birthDate,
                                                      locale:
                                                          FFLocalizations.of(
                                                                  context)
                                                              .languageCode,
                                                    ),
                                                    'Enter Birthdate',
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily:
                                                            'Readex Pro',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryText,
                                                        fontSize: 13.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(),
                                        child: TextFormField(
                                          controller: _model
                                              .relationTextFieldTextController,
                                          focusNode:
                                              _model.relationTextFieldFocusNode,
                                          autofocus: true,
                                          obscureText: false,
                                          decoration: InputDecoration(
                                            labelStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .override(
                                                      fontFamily: 'Readex Pro',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText:
                                                FFLocalizations.of(context)
                                                    .getText(
                                              'cxq7ow8a' /* Enter your relation (Eg Mom/Da... */,
                                            ),
                                            hintStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .override(
                                                      fontFamily: 'Readex Pro',
                                                      fontSize: 13.0,
                                                      letterSpacing: 0.0,
                                                    ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .alternate,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            errorBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .error,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            focusedErrorBorder:
                                                UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .error,
                                                width: 2.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                            ),
                                            contentPadding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    4.0, 0.0, 0.0, 0.0),
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                letterSpacing: 0.0,
                                              ),
                                          maxLines: null,
                                          validator: _model
                                              .relationTextFieldTextControllerValidator
                                              .asValidator(context),
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 8.0)),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 10.0, 0.0, 0.0),
                                child: Theme(
                                  data: ThemeData(
                                    checkboxTheme: CheckboxThemeData(
                                      visualDensity: VisualDensity.compact,
                                      materialTapTargetSize:
                                          MaterialTapTargetSize.shrinkWrap,
                                    ),
                                    unselectedWidgetColor:
                                        FlutterFlowTheme.of(context)
                                            .secondaryText,
                                  ),
                                  child: CheckboxListTile(
                                    value: _model.checkboxListTileValue ??=
                                        true,
                                    onChanged: (newValue) async {
                                      setState(() => _model
                                          .checkboxListTileValue = newValue!);
                                    },
                                    title: Text(
                                      FFLocalizations.of(context).getText(
                                        'xu5v8ct2' /* Was your child born prematurel... */,
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .titleLarge
                                          .override(
                                            fontFamily: 'Outfit',
                                            fontSize: 15.0,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    tileColor: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    activeColor:
                                        FlutterFlowTheme.of(context).primary,
                                    checkColor:
                                        FlutterFlowTheme.of(context).info,
                                    dense: false,
                                    controlAffinity:
                                        ListTileControlAffinity.trailing,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 10.0, 0.0, 4.0),
                                child: FlutterFlowDropDown<String>(
                                  controller: _model.dropDownValueController ??=
                                      FormFieldController<String>(null),
                                  options: [
                                    FFLocalizations.of(context).getText(
                                      'gq2tj2xm' /* Male */,
                                    ),
                                    FFLocalizations.of(context).getText(
                                      'z5onp58s' /* Female */,
                                    )
                                  ],
                                  onChanged: (val) => setState(
                                      () => _model.dropDownValue = val),
                                  width: 398.0,
                                  height: 56.0,
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleLarge
                                      .override(
                                        fontFamily: 'Outfit',
                                        fontSize: 15.0,
                                        letterSpacing: 0.0,
                                      ),
                                  hintText: FFLocalizations.of(context).getText(
                                    'i33qrulg' /* Select your child gender */,
                                  ),
                                  icon: Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    size: 24.0,
                                  ),
                                  fillColor: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  elevation: 2.0,
                                  borderColor:
                                      FlutterFlowTheme.of(context).alternate,
                                  borderWidth: 2.0,
                                  borderRadius: 8.0,
                                  margin: EdgeInsetsDirectional.fromSTEB(
                                      16.0, 4.0, 16.0, 4.0),
                                  hidesUnderline: true,
                                  isOverButton: true,
                                  isSearchable: false,
                                  isMultiSelect: false,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 10.0, 0.0, 4.0),
                                child: Theme(
                                  data: ThemeData(
                                    checkboxTheme: CheckboxThemeData(
                                      visualDensity: VisualDensity.compact,
                                      materialTapTargetSize:
                                          MaterialTapTargetSize.shrinkWrap,
                                    ),
                                    unselectedWidgetColor:
                                        FlutterFlowTheme.of(context)
                                            .secondaryText,
                                  ),
                                  child: CheckboxListTile(
                                    value: _model
                                        .storeInCloudCheckBoxTileValue ??= true,
                                    onChanged: (newValue) async {
                                      setState(() =>
                                          _model.storeInCloudCheckBoxTileValue =
                                              newValue!);
                                    },
                                    title: Text(
                                      FFLocalizations.of(context).getText(
                                        'boj8vtiv' /* Store data in the cloud? */,
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .titleLarge
                                          .override(
                                            fontFamily: 'Outfit',
                                            fontSize: 15.0,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      FFLocalizations.of(context).getText(
                                        '3lhvi4yd' /* Deselecting this option means ... */,
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .labelMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryText,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    tileColor: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    activeColor:
                                        FlutterFlowTheme.of(context).primary,
                                    checkColor:
                                        FlutterFlowTheme.of(context).info,
                                    dense: false,
                                    controlAffinity:
                                        ListTileControlAffinity.trailing,
                                  ),
                                ),
                              ),
                              Stack(
                                alignment: AlignmentDirectional(-1.0, 0.0),
                                children: [
                                  if ((FFAppState().generatedActEarlyID !=
                                              null &&
                                          FFAppState().generatedActEarlyID !=
                                              '') &&
                                      (_model.storeInCloudCheckBoxTileValue ==
                                          true))
                                    Align(
                                      alignment:
                                          AlignmentDirectional(-1.0, 0.0),
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            15.0, 6.0, 0.0, 6.0),
                                        child: Text(
                                          FFAppState().generatedActEarlyID,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 16.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              if ((FFAppState().generatedActEarlyID == null ||
                                      FFAppState().generatedActEarlyID == '') &&
                                  (_model.storeInCloudCheckBoxTileValue ==
                                      true))
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      12.0, 0.0, 12.0, 0.0),
                                  child: TextFormField(
                                    controller: _model.idTFTextController,
                                    focusNode: _model.idTFFocusNode,
                                    autofocus: true,
                                    obscureText: false,
                                    decoration: InputDecoration(
                                      labelStyle: FlutterFlowTheme.of(context)
                                          .labelMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                      hintText:
                                          FFLocalizations.of(context).getText(
                                        '3kbblag3' /* Enter Act Early ID */,
                                      ),
                                      hintStyle: FlutterFlowTheme.of(context)
                                          .labelMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                          ),
                                      enabledBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .alternate,
                                          width: 2.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                      focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          width: 2.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                      errorBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .error,
                                          width: 2.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                      focusedErrorBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .error,
                                          width: 2.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                      contentPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              4.0, 0.0, 0.0, 0.0),
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          letterSpacing: 0.0,
                                        ),
                                    maxLines: null,
                                    validator: _model
                                        .idTFTextControllerValidator
                                        .asValidator(context),
                                  ),
                                ),
                              if (_model.storeInCloudCheckBoxTileValue ?? true)
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 10.0, 12.0, 10.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Text(
                                        FFLocalizations.of(context).getText(
                                          '84oi1vfa' /* OR  */,
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                      InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          FFAppState().generatedActEarlyID =
                                              random_data.randomString(
                                            15,
                                            15,
                                            true,
                                            true,
                                            true,
                                          );
                                          setState(() {});
                                        },
                                        child: Text(
                                          FFLocalizations.of(context).getText(
                                            '8v6qtu54' /* Generate ActEarly ID */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                          Align(
                            alignment: AlignmentDirectional(-1.0, 0.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 10.0),
                              child: FFButtonWidget(
                                onPressed: () async {
                                  if (_model.storeInCloudCheckBoxTileValue!) {
                                    if ((_model.textController3.text == null ||
                                            _model.textController3.text ==
                                                '') ||
                                        (_model.relationTextFieldTextController
                                                    .text ==
                                                null ||
                                            _model.relationTextFieldTextController
                                                    .text ==
                                                '') ||
                                        (dateTimeFormat(
                                                  "d/M/y",
                                                  _model.datePicked,
                                                  locale: FFLocalizations.of(
                                                          context)
                                                      .languageCode,
                                                ) ==
                                                null ||
                                            dateTimeFormat(
                                                  "d/M/y",
                                                  _model.datePicked,
                                                  locale: FFLocalizations.of(
                                                          context)
                                                      .languageCode,
                                                ) ==
                                                '') ||
                                        (_model.dropDownValue == null ||
                                            _model.dropDownValue == '') ||
                                        (FFAppState().generatedActEarlyID ==
                                                    null ||
                                                FFAppState().generatedActEarlyID ==
                                                    ''
                                            ? (_model.idTFTextController.text ==
                                                    null ||
                                                _model.idTFTextController
                                                        .text ==
                                                    '')
                                            : (FFAppState()
                                                        .generatedActEarlyID ==
                                                    null ||
                                                FFAppState()
                                                        .generatedActEarlyID ==
                                                    ''))) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            'Please enter all fields!',
                                            style: TextStyle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryBackground,
                                            ),
                                          ),
                                          duration:
                                              Duration(milliseconds: 4000),
                                          backgroundColor:
                                              FlutterFlowTheme.of(context)
                                                  .primaryText,
                                        ),
                                      );
                                    } else {
                                      _model.query1 =
                                          await queryChildsRecordOnce(
                                        queryBuilder: (childsRecord) =>
                                            childsRecord.where(
                                          'actEarlyID',
                                          isEqualTo: FFAppState()
                                                          .generatedActEarlyID ==
                                                      null ||
                                                  FFAppState()
                                                          .generatedActEarlyID ==
                                                      ''
                                              ? _model.idTFTextController.text
                                              : FFAppState()
                                                  .generatedActEarlyID,
                                        ),
                                        singleRecord: true,
                                      ).then((s) => s.firstOrNull);
                                      if (_model.query1?.actEarlyID ==
                                          (FFAppState().generatedActEarlyID ==
                                                      null ||
                                                  FFAppState()
                                                          .generatedActEarlyID ==
                                                      ''
                                              ? _model.idTFTextController.text
                                              : FFAppState()
                                                  .generatedActEarlyID)) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              'Another child is already registered with same ActEarly ID.',
                                              style: TextStyle(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryBackground,
                                              ),
                                            ),
                                            duration:
                                                Duration(milliseconds: 4000),
                                            backgroundColor:
                                                FlutterFlowTheme.of(context)
                                                    .primaryText,
                                          ),
                                        );
                                      } else {
                                        var childsRecordReference =
                                            ChildsRecord.collection.doc();
                                        await childsRecordReference.set({
                                          ...createChildsRecordData(
                                            childName:
                                                _model.textController3.text,
                                            childImage: _model
                                                            .uploadedFileUrl ==
                                                        null ||
                                                    _model.uploadedFileUrl == ''
                                                ? 'https://firebasestorage.googleapis.com/v0/b/actearly-mitacs.appspot.com/o/defaultbabyjpg.jpg?alt=media&token=2a30d949-43ce-44f1-bb33-9690eaee199d'
                                                : _model.uploadedFileUrl,
                                            relationWithChild: _model
                                                .relationTextFieldTextController
                                                .text,
                                            childGender: _model.dropDownValue,
                                            childPremature:
                                                _model.checkboxListTileValue,
                                            childDateOfBirth: _model.datePicked,
                                            childAge:
                                                functions.dateOfBirthToAge(
                                                    _model.datePicked),
                                            actEarlyID: FFAppState()
                                                            .generatedActEarlyID ==
                                                        null ||
                                                    FFAppState()
                                                            .generatedActEarlyID ==
                                                        ''
                                                ? _model.idTFTextController.text
                                                : FFAppState()
                                                    .generatedActEarlyID,
                                            firsrtParentID: currentUserUid,
                                          ),
                                          ...mapToFirestore(
                                            {
                                              'socialQuestion':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .social6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .social1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .social2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .socia3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .social4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .social1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'fineMotorQuestions':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .fine6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .fine1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .fine2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .fine3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .fine4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .fine1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'grossMotorQuestions':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .gross6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .gross1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .gross2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .gross3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .gross4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .gross1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'cognitiveQuestions':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .cognitive6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .cognitive1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .cognitive2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .cognitive3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .cognitive4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .cognitive1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'parentID': [
                                                getActEarlyidDataFirestoreData(
                                                  updateActEarlyidDataStruct(
                                                    ActEarlyidDataStruct(
                                                      relation: _model
                                                          .relationTextFieldTextController
                                                          .text,
                                                      userID: currentUserUid,
                                                    ),
                                                    clearUnsetFields: false,
                                                    create: true,
                                                  ),
                                                  true,
                                                )
                                              ],
                                              'onlyParentID': [currentUserUid],
                                              'socialLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .social6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .social1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .social2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .social3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .social4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .social1to6monthlinks;
                                                }
                                              }(),
                                              'fineMotorLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .fine6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .fine1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .fine2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .fine3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .fine4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .fine1to6monthlinks;
                                                }
                                              }(),
                                              'grossMotorLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .gross6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .gross1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .gross2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .gross3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .gross4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .gross1to6monthlinks;
                                                }
                                              }(),
                                              'cognitiveLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .cognitive6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .cognitive1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .cognitive2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .cognitive3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .cognitive4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .cognitive1to6monthlinks;
                                                }
                                              }(),
                                            },
                                          ),
                                        });
                                        _model.output =
                                            ChildsRecord.getDocumentFromData({
                                          ...createChildsRecordData(
                                            childName:
                                                _model.textController3.text,
                                            childImage: _model
                                                            .uploadedFileUrl ==
                                                        null ||
                                                    _model.uploadedFileUrl == ''
                                                ? 'https://firebasestorage.googleapis.com/v0/b/actearly-mitacs.appspot.com/o/defaultbabyjpg.jpg?alt=media&token=2a30d949-43ce-44f1-bb33-9690eaee199d'
                                                : _model.uploadedFileUrl,
                                            relationWithChild: _model
                                                .relationTextFieldTextController
                                                .text,
                                            childGender: _model.dropDownValue,
                                            childPremature:
                                                _model.checkboxListTileValue,
                                            childDateOfBirth: _model.datePicked,
                                            childAge:
                                                functions.dateOfBirthToAge(
                                                    _model.datePicked),
                                            actEarlyID: FFAppState()
                                                            .generatedActEarlyID ==
                                                        null ||
                                                    FFAppState()
                                                            .generatedActEarlyID ==
                                                        ''
                                                ? _model.idTFTextController.text
                                                : FFAppState()
                                                    .generatedActEarlyID,
                                            firsrtParentID: currentUserUid,
                                          ),
                                          ...mapToFirestore(
                                            {
                                              'socialQuestion':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .social6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .social1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .social2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .socia3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .social4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .social1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'fineMotorQuestions':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .fine6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .fine1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .fine2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .fine3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .fine4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .fine1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'grossMotorQuestions':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .gross6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .gross1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .gross2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .gross3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .gross4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .gross1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'cognitiveQuestions':
                                                  getAnswerValueListFirestoreData(
                                                () {
                                                  if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '7 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '8 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '9 months') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '10 months') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '11 months')) {
                                                    return FFAppState()
                                                        .cognitive6to11monthQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '1 year') {
                                                    return FFAppState()
                                                        .cognitive1yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '2 years') {
                                                    return FFAppState()
                                                        .cognitive2yearQ;
                                                  } else if (functions.dateOfBirthToAge(
                                                          _model.datePicked) ==
                                                      '3 years') {
                                                    return FFAppState()
                                                        .cognitive3yearQ;
                                                  } else if ((functions.dateOfBirthToAge(
                                                              _model
                                                                  .datePicked) ==
                                                          '4 years') ||
                                                      (functions.dateOfBirthToAge(_model.datePicked) ==
                                                          '5 years') ||
                                                      (functions.dateOfBirthToAge(
                                                              _model.datePicked) ==
                                                          '6 years')) {
                                                    return FFAppState()
                                                        .cognitive4yearQ;
                                                  } else {
                                                    return FFAppState()
                                                        .cognitive1to6monthQ;
                                                  }
                                                }(),
                                              ),
                                              'parentID': [
                                                getActEarlyidDataFirestoreData(
                                                  updateActEarlyidDataStruct(
                                                    ActEarlyidDataStruct(
                                                      relation: _model
                                                          .relationTextFieldTextController
                                                          .text,
                                                      userID: currentUserUid,
                                                    ),
                                                    clearUnsetFields: false,
                                                    create: true,
                                                  ),
                                                  true,
                                                )
                                              ],
                                              'onlyParentID': [currentUserUid],
                                              'socialLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .social6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .social1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .social2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .social3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .social4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .social1to6monthlinks;
                                                }
                                              }(),
                                              'fineMotorLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .fine6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .fine1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .fine2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .fine3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .fine4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .fine1to6monthlinks;
                                                }
                                              }(),
                                              'grossMotorLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .gross6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .gross1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .gross2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .gross3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .gross4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .gross1to6monthlinks;
                                                }
                                              }(),
                                              'cognitiveLinks': () {
                                                if ((functions.dateOfBirthToAge(_model.datePicked) == '6 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '7 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '8 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '9 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '10 months') ||
                                                    (functions.dateOfBirthToAge(_model.datePicked) ==
                                                        '11 months')) {
                                                  return FFAppState()
                                                      .cognitive6to11monthlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '1 year') {
                                                  return FFAppState()
                                                      .cognitive1yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '2 years') {
                                                  return FFAppState()
                                                      .cognitive2yearlinks;
                                                } else if (functions.dateOfBirthToAge(
                                                        _model.datePicked) ==
                                                    '3 years') {
                                                  return FFAppState()
                                                      .cognitive3yearlinks;
                                                } else if ((functions
                                                            .dateOfBirthToAge(_model
                                                                .datePicked) ==
                                                        '4 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model
                                                                .datePicked) ==
                                                        '5 years') ||
                                                    (functions.dateOfBirthToAge(
                                                            _model.datePicked) ==
                                                        '6 years')) {
                                                  return FFAppState()
                                                      .cognitive4yearlinks;
                                                } else {
                                                  return FFAppState()
                                                      .cognitive1to6monthlinks;
                                                }
                                              }(),
                                            },
                                          ),
                                        }, childsRecordReference);
                                        ScaffoldMessenger.of(context)
                                            .clearSnackBars();
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              'Child Added Successfully!',
                                              style: TextStyle(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryBackground,
                                              ),
                                            ),
                                            duration:
                                                Duration(milliseconds: 4000),
                                            backgroundColor:
                                                FlutterFlowTheme.of(context)
                                                    .primaryText,
                                          ),
                                        );
                                        FFAppState().birthDate = null;
                                        FFAppState().childImageURL = '';
                                        FFAppState().generatedActEarlyID = '';
                                        setState(() {});
                                        setState(() {
                                          _model
                                              .registeredActEarlyIDTFTextController
                                              ?.clear();
                                          _model.textController3?.clear();
                                          _model.textController4?.clear();
                                          _model.relationTextFieldTextController
                                              ?.clear();
                                          _model
                                              .registeredRelationTfTextController
                                              ?.clear();
                                          _model.idTFTextController?.clear();
                                        });
                                      }
                                    }
                                  } else {
                                    if ((_model.textController3.text == null ||
                                            _model.textController3.text ==
                                                '') ||
                                        (_model.relationTextFieldTextController
                                                    .text ==
                                                null ||
                                            _model.relationTextFieldTextController
                                                    .text ==
                                                '') ||
                                        (dateTimeFormat(
                                                  "d/M/y",
                                                  _model.datePicked,
                                                  locale: FFLocalizations.of(
                                                          context)
                                                      .languageCode,
                                                ) ==
                                                null ||
                                            dateTimeFormat(
                                                  "d/M/y",
                                                  _model.datePicked,
                                                  locale: FFLocalizations.of(
                                                          context)
                                                      .languageCode,
                                                ) ==
                                                '') ||
                                        (_model.dropDownValue == null ||
                                            _model.dropDownValue == '')) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            'Please enter all fields!',
                                            style: TextStyle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryBackground,
                                            ),
                                          ),
                                          duration:
                                              Duration(milliseconds: 4000),
                                          backgroundColor:
                                              FlutterFlowTheme.of(context)
                                                  .primaryText,
                                        ),
                                      );
                                    } else {
                                      FFAppState().addToChildDataAppState(
                                          ChildDataStruct(
                                        childName: _model.textController3.text,
                                        childImage: _model.uploadedFileUrl ==
                                                    null ||
                                                _model.uploadedFileUrl == ''
                                            ? 'https://firebasestorage.googleapis.com/v0/b/actearly-mitacs.appspot.com/o/defaultbabyjpg.jpg?alt=media&token=2a30d949-43ce-44f1-bb33-9690eaee199d'
                                            : _model.uploadedFileUrl,
                                        childGender: _model.dropDownValue,
                                        childPremature:
                                            _model.checkboxListTileValue,
                                        childDateOfBirth: _model.datePicked,
                                        childAge: functions.dateOfBirthToAge(
                                            _model.datePicked),
                                        relationWithChild: _model
                                            .relationTextFieldTextController
                                            .text,
                                        socialQuestion: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .social6to11monthQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState().social1yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState().social2yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState().socia3yearQ;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState().social4yearQ;
                                          } else {
                                            return FFAppState()
                                                .social1to6monthQ;
                                          }
                                        }(),
                                        fineMotorQuestions: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState().fine6to11monthQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState().fine1yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState().fine2yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState().fine3yearQ;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState().fine4yearQ;
                                          } else {
                                            return FFAppState().fine1to6monthQ;
                                          }
                                        }(),
                                        grossMotorQuestions: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .gross6to11monthQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState().gross1yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState().gross2yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState().gross3yearQ;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState().gross4yearQ;
                                          } else {
                                            return FFAppState().gross1to6monthQ;
                                          }
                                        }(),
                                        cognitiveQuestions: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .cognitive6to11monthQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState().cognitive1yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState().cognitive2yearQ;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState().cognitive3yearQ;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState().cognitive4yearQ;
                                          } else {
                                            return FFAppState()
                                                .cognitive1to6monthQ;
                                          }
                                        }(),
                                        actEarlyID: random_data.randomString(
                                          15,
                                          15,
                                          true,
                                          true,
                                          true,
                                        ),
                                        socialLinks: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .social6to11monthlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState()
                                                .social1yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState()
                                                .social2yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState()
                                                .social3yearlinks;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState()
                                                .social4yearlinks;
                                          } else {
                                            return FFAppState()
                                                .social1to6monthlinks;
                                          }
                                        }(),
                                        fineMotorLinks: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .fine6to11monthlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState().fine1yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState().fine2yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState().fine3yearlinks;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState().fine4yearlinks;
                                          } else {
                                            return FFAppState()
                                                .fine1to6monthlinks;
                                          }
                                        }(),
                                        grossMotorLinks: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .gross6to11monthlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState().gross1yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState().gross2yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState().gross3yearlinks;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState().gross4yearlinks;
                                          } else {
                                            return FFAppState()
                                                .gross1to6monthlinks;
                                          }
                                        }(),
                                        cognitiveLinks: () {
                                          if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '6 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '7 months') ||
                                              (functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '8 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '9 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '10 months') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '11 months')) {
                                            return FFAppState()
                                                .cognitive6to11monthlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '1 year') {
                                            return FFAppState()
                                                .cognitive1yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '2 years') {
                                            return FFAppState()
                                                .cognitive2yearlinks;
                                          } else if (functions.dateOfBirthToAge(
                                                  _model.datePicked) ==
                                              '3 years') {
                                            return FFAppState()
                                                .cognitive3yearlinks;
                                          } else if ((functions.dateOfBirthToAge(
                                                      _model.datePicked) ==
                                                  '4 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) ==
                                                  '5 years') ||
                                              (functions.dateOfBirthToAge(_model.datePicked) == '6 years')) {
                                            return FFAppState()
                                                .cognitive4yearlinks;
                                          } else {
                                            return FFAppState()
                                                .cognitive1to6monthlinks;
                                          }
                                        }(),
                                      ));
                                      setState(() {});
                                      ScaffoldMessenger.of(context)
                                          .clearSnackBars();
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            'Child Added Successfully!',
                                            style: TextStyle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryBackground,
                                            ),
                                          ),
                                          duration:
                                              Duration(milliseconds: 4000),
                                          backgroundColor:
                                              FlutterFlowTheme.of(context)
                                                  .primaryText,
                                        ),
                                      );
                                      FFAppState().birthDate = null;
                                      FFAppState().childImageURL = '';
                                      setState(() {});
                                      setState(() {
                                        _model
                                            .registeredActEarlyIDTFTextController
                                            ?.clear();
                                        _model.textController3?.clear();
                                        _model.textController4?.clear();
                                        _model.relationTextFieldTextController
                                            ?.clear();
                                        _model
                                            .registeredRelationTfTextController
                                            ?.clear();
                                        _model.idTFTextController?.clear();
                                      });
                                    }
                                  }

                                  setState(() {});
                                },
                                text: FFLocalizations.of(context).getText(
                                  'kwwc8hkm' /* Submit */,
                                ),
                                options: FFButtonOptions(
                                  height: 40.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      24.0, 4.0, 24.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: FlutterFlowTheme.of(context).primary,
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        color: Colors.white,
                                        letterSpacing: 0.0,
                                      ),
                                  elevation: 3.0,
                                  borderSide: BorderSide(
                                    color: Colors.transparent,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
