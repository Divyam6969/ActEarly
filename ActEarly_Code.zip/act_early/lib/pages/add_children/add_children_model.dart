import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/random_data_util.dart' as random_data;
import 'add_children_widget.dart' show AddChildrenWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddChildrenModel extends FlutterFlowModel<AddChildrenWidget> {
  ///  Local state fields for this page.

  String? img;

  ///  State fields for stateful widgets in this page.

  // State field(s) for SwitchListTile widget.
  bool? switchListTileValue;
  // State field(s) for registeredActEarlyIDTF widget.
  FocusNode? registeredActEarlyIDTFFocusNode;
  TextEditingController? registeredActEarlyIDTFTextController;
  String? Function(BuildContext, String?)?
      registeredActEarlyIDTFTextControllerValidator;
  // State field(s) for registeredRelationTf widget.
  FocusNode? registeredRelationTfFocusNode;
  TextEditingController? registeredRelationTfTextController;
  String? Function(BuildContext, String?)?
      registeredRelationTfTextControllerValidator;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  ChildsRecord? aaaaa1;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController4;
  String? Function(BuildContext, String?)? textController4Validator;
  DateTime? datePicked;
  // State field(s) for relationTextField widget.
  FocusNode? relationTextFieldFocusNode;
  TextEditingController? relationTextFieldTextController;
  String? Function(BuildContext, String?)?
      relationTextFieldTextControllerValidator;
  // State field(s) for CheckboxListTile widget.
  bool? checkboxListTileValue;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // State field(s) for storeInCloudCheckBoxTile widget.
  bool? storeInCloudCheckBoxTileValue;
  // State field(s) for idTF widget.
  FocusNode? idTFFocusNode;
  TextEditingController? idTFTextController;
  String? Function(BuildContext, String?)? idTFTextControllerValidator;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  ChildsRecord? query1;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  ChildsRecord? output;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    registeredActEarlyIDTFFocusNode?.dispose();
    registeredActEarlyIDTFTextController?.dispose();

    registeredRelationTfFocusNode?.dispose();
    registeredRelationTfTextController?.dispose();

    textFieldFocusNode1?.dispose();
    textController3?.dispose();

    textFieldFocusNode2?.dispose();
    textController4?.dispose();

    relationTextFieldFocusNode?.dispose();
    relationTextFieldTextController?.dispose();

    idTFFocusNode?.dispose();
    idTFTextController?.dispose();
  }
}
