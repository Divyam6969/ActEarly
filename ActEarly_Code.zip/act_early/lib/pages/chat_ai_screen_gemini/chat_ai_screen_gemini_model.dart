import '/actearly_a_i/empty_list/empty_list_widget.dart';
import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'chat_ai_screen_gemini_widget.dart' show ChatAiScreenGeminiWidget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChatAiScreenGeminiModel
    extends FlutterFlowModel<ChatAiScreenGeminiWidget> {
  ///  Local state fields for this page.

  String? apiResponse = '';

  String? inputText;

  ///  State fields for stateful widgets in this page.

  // Model for emptyList component.
  late EmptyListModel emptyListModel;
  // State field(s) for TextField1 widget.
  FocusNode? textField1FocusNode;
  TextEditingController? textField1TextController;
  String? Function(BuildContext, String?)? textField1TextControllerValidator;
  // Stores action output result for [Backend Call - API (Gemini Ai Text)] action in IconButton widget.
  ApiCallResponse? apiResultait;

  @override
  void initState(BuildContext context) {
    emptyListModel = createModel(context, () => EmptyListModel());
  }

  @override
  void dispose() {
    emptyListModel.dispose();
    textField1FocusNode?.dispose();
    textField1TextController?.dispose();
  }
}
