import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'social_question_page_widget.dart' show SocialQuestionPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SocialQuestionPageModel
    extends FlutterFlowModel<SocialQuestionPageWidget> {
  ///  Local state fields for this page.

  String answerYes = 'yes';

  String answerNo = 'no';

  List<AnswerValueStruct> socialQuestions = [];
  void addToSocialQuestions(AnswerValueStruct item) =>
      socialQuestions.add(item);
  void removeFromSocialQuestions(AnswerValueStruct item) =>
      socialQuestions.remove(item);
  void removeAtIndexFromSocialQuestions(int index) =>
      socialQuestions.removeAt(index);
  void insertAtIndexInSocialQuestions(int index, AnswerValueStruct item) =>
      socialQuestions.insert(index, item);
  void updateSocialQuestionsAtIndex(
          int index, Function(AnswerValueStruct) updateFn) =>
      socialQuestions[index] = updateFn(socialQuestions[index]);

  AnswerValueStruct? socialAnswer;
  void updateSocialAnswerStruct(Function(AnswerValueStruct) updateFn) {
    updateFn(socialAnswer ??= AnswerValueStruct());
  }

  String answerMaybe = 'maybe';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
