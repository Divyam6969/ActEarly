import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'gross_motor_question_page_widget.dart'
    show GrossMotorQuestionPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GrossMotorQuestionPageModel
    extends FlutterFlowModel<GrossMotorQuestionPageWidget> {
  ///  Local state fields for this page.

  String answerYes = 'yes';

  String answerNo = 'no';

  List<AnswerValueStruct> grossQuestions = [];
  void addToGrossQuestions(AnswerValueStruct item) => grossQuestions.add(item);
  void removeFromGrossQuestions(AnswerValueStruct item) =>
      grossQuestions.remove(item);
  void removeAtIndexFromGrossQuestions(int index) =>
      grossQuestions.removeAt(index);
  void insertAtIndexInGrossQuestions(int index, AnswerValueStruct item) =>
      grossQuestions.insert(index, item);
  void updateGrossQuestionsAtIndex(
          int index, Function(AnswerValueStruct) updateFn) =>
      grossQuestions[index] = updateFn(grossQuestions[index]);

  String answerMaybe = 'maybe';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
