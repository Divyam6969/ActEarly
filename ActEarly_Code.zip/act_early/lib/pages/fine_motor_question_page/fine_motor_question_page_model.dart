import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'fine_motor_question_page_widget.dart' show FineMotorQuestionPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FineMotorQuestionPageModel
    extends FlutterFlowModel<FineMotorQuestionPageWidget> {
  ///  Local state fields for this page.

  String answerYes = 'yes';

  String answerNo = 'no';

  List<AnswerValueStruct> fineQuestions = [];
  void addToFineQuestions(AnswerValueStruct item) => fineQuestions.add(item);
  void removeFromFineQuestions(AnswerValueStruct item) =>
      fineQuestions.remove(item);
  void removeAtIndexFromFineQuestions(int index) =>
      fineQuestions.removeAt(index);
  void insertAtIndexInFineQuestions(int index, AnswerValueStruct item) =>
      fineQuestions.insert(index, item);
  void updateFineQuestionsAtIndex(
          int index, Function(AnswerValueStruct) updateFn) =>
      fineQuestions[index] = updateFn(fineQuestions[index]);

  String answerMaybe = 'maybe';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
