import '/components/for_main_page/for_main_page_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:flip_card/flip_card.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'home_page_model.dart';
export 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({super.key});

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  late HomePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomePageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFF4B39EF),
        body: SafeArea(
          top: true,
          child: Stack(
            children: [
              SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: wrapWithModel(
                        model: _model.forMainPageModel,
                        updateCallback: () => setState(() {}),
                        child: ForMainPageWidget(),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            10.0, 4.0, 10.0, 18.0),
                        child: Text(
                          FFLocalizations.of(context).getText(
                            '5bbjuaoe' /* 
Welcome to ActEarly! Children... */
                            ,
                          ),
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Outfit',
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 18.0, 0.0, 18.0),
                        child: FlutterFlowDropDown<String>(
                          controller: _model.dropDownValueController ??=
                              FormFieldController<String>(null),
                          options: [
                            FFLocalizations.of(context).getText(
                              '30jrof4l' /* at the end of 3 months */,
                            ),
                            FFLocalizations.of(context).getText(
                              '9zcr3brb' /* at the end of 8 months */,
                            ),
                            FFLocalizations.of(context).getText(
                              'lnt1g5uq' /* between 12 and 14 months */,
                            ),
                            FFLocalizations.of(context).getText(
                              'vzp7o6nf' /* at the end of 1.5 years */,
                            ),
                            FFLocalizations.of(context).getText(
                              '532e4m9c' /* at the end of 2 years */,
                            ),
                            FFLocalizations.of(context).getText(
                              'ndk7oylt' /* at the end of 3 years */,
                            ),
                            FFLocalizations.of(context).getText(
                              'gqd7vl3k' /* at the end of 4 years */,
                            )
                          ],
                          onChanged: (val) async {
                            setState(() => _model.dropDownValue = val);
                            FFAppState().selectedValueDropDown =
                                _model.dropDownValue!;
                            setState(() {});
                          },
                          width: 300.0,
                          textStyle:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Outfit',
                                    letterSpacing: 0.0,
                                  ),
                          hintText: FFLocalizations.of(context).getText(
                            'u4a3ngh0' /* Please select the child age */,
                          ),
                          icon: Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: FlutterFlowTheme.of(context).secondaryText,
                            size: 24.0,
                          ),
                          fillColor:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          elevation: 2.0,
                          borderColor: FlutterFlowTheme.of(context).alternate,
                          borderWidth: 2.0,
                          borderRadius: 8.0,
                          margin: EdgeInsetsDirectional.fromSTEB(
                              16.0, 4.0, 16.0, 4.0),
                          hidesUnderline: true,
                          isOverButton: true,
                          isSearchable: false,
                          isMultiSelect: false,
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 15.0, 0.0, 10.0),
                        child: Container(
                          width: double.infinity,
                          height: 320.0,
                          child: CarouselSlider(
                            items: [
                              FlipCard(
                                fill: Fill.fillBack,
                                direction: FlipDirection.HORIZONTAL,
                                speed: 400,
                                front: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, -1.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 10.0, 0.0, 0.0),
                                          child: Text(
                                            FFLocalizations.of(context).getText(
                                              '3t7sf38w' /* Gross Motor */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 5.0, 10.0, 0.0),
                                        child: Text(
                                          FFLocalizations.of(context).getText(
                                            'm1voq1co' /* These are movements using the ... */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .labelMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 7.0, 10.0, 5.0),
                                        child: Text(
                                          functions.grossMotor(FFAppState()
                                              .selectedValueDropDown)!,
                                          textAlign: TextAlign.start,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                fontSize: 14.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.normal,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                back: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      () {
                                        if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 months') {
                                          return 'https://th.bing.com/th/id/OIG4.H.y3JqPYAivczuuNMfSm?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 8 months') {
                                          return 'https://th.bing.com/th/id/OIG3.GckGdpmGrDNCQMFB58IV?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'between 12 and 14 months') {
                                          return 'https://th.bing.com/th/id/OIG4.RKmM6aTi2kk5MVCEsrxz?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 1.5 years') {
                                          return 'https://th.bing.com/th/id/OIG4.teIptdYhSMT0.5LsQrtk?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 2 years') {
                                          return 'https://th.bing.com/th/id/OIG1.XwqCbOOzVyFlKwlkhnj7?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 years') {
                                          return 'https://th.bing.com/th/id/OIG3.YAIud13k8KlUModnBsBv?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 4 years') {
                                          return 'https://th.bing.com/th/id/OIG1.XrsmQHuI_Eb1nZ3qIQ_q?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else {
                                          return 'https://th.bing.com/th/id/OIG1.Vi9zUDAhdndRZ1I0bOhG?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        }
                                      }(),
                                      width: 300.0,
                                      height: 200.0,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                              FlipCard(
                                fill: Fill.fillBack,
                                direction: FlipDirection.HORIZONTAL,
                                speed: 400,
                                front: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: SingleChildScrollView(
                                    primary: false,
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 10.0, 0.0, 0.0),
                                            child: Text(
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'eyi8qjnb' /* Fine Motor  */,
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyLarge
                                                      .override(
                                                        fontFamily:
                                                            'Readex Pro',
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  10.0, 5.0, 10.0, 0.0),
                                          child: Text(
                                            FFLocalizations.of(context).getText(
                                              'lo0mlbdi' /* These skills use the small mus... */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .labelMedium
                                                .override(
                                                  fontFamily: 'Outfit',
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  10.0, 7.0, 10.0, 10.0),
                                          child: Text(
                                            functions.fineMotor(FFAppState()
                                                .selectedValueDropDown)!,
                                            textAlign: TextAlign.start,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Outfit',
                                                  fontSize: 14.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.normal,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                back: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      () {
                                        if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 months') {
                                          return 'https://th.bing.com/th/id/OIG2.jKRAKBsM4I6SzX5KJG7e?w=270&h=270&c=6&r=0&o=5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 8 months') {
                                          return 'https://th.bing.com/th/id/OIG4.C3wIiyVBTlkLtmXasL59?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'between 12 and 14 months') {
                                          return 'https://th.bing.com/th/id/OIG2.rdM.NxJ5XHbO.iVFCBGO?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 1.5 years') {
                                          return 'https://th.bing.com/th/id/OIG2.4ng4hW0Qy6n5Db1tBkdV?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 2 years') {
                                          return 'https://th.bing.com/th/id/OIG1.TuDD6r1NkBsgh33fzY8.?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 years') {
                                          return 'https://th.bing.com/th/id/OIG1.SefuqsTZ0mxyqvRv8PNg?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 4 years') {
                                          return 'https://th.bing.com/th/id/OIG4._EuEg6L87dvJvmTHhLIm?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else {
                                          return 'https://th.bing.com/th/id/OIG2.aqUOfmyPQOqQIBaQlmeD?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        }
                                      }(),
                                      width: 300.0,
                                      height: 200.0,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                              FlipCard(
                                fill: Fill.fillBack,
                                direction: FlipDirection.HORIZONTAL,
                                speed: 400,
                                front: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, -1.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 10.0, 0.0, 0.0),
                                          child: Text(
                                            FFLocalizations.of(context).getText(
                                              '45b5luvc' /* Language/Social */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 5.0, 10.0, 0.0),
                                        child: Text(
                                          FFLocalizations.of(context).getText(
                                            'gif5l3r8' /* Language: Speaking, using body... */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .labelMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 7.0, 10.0, 5.0),
                                        child: Text(
                                          functions.socialLanguage(FFAppState()
                                              .selectedValueDropDown)!,
                                          textAlign: TextAlign.start,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                fontSize: 14.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.normal,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                back: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      () {
                                        if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 months') {
                                          return 'https://th.bing.com/th/id/OIG4.TFjgu9JAeERpx655b8mb?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 8 months') {
                                          return 'https://th.bing.com/th/id/OIG2.JYpwb3tZov0hJgFknLis?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'between 12 and 14 months') {
                                          return 'https://th.bing.com/th/id/OIG3.TO.SHIIFUBwCYqH38otG?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 1.5 years') {
                                          return 'https://th.bing.com/th/id/OIG4.Iu4X7zzXXL8SgDTI_fnH?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 2 years') {
                                          return 'https://th.bing.com/th/id/OIG1.I5auuvOy7V4AW66Jjh73?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 years') {
                                          return 'https://th.bing.com/th/id/OIG2.gWNpmh193PkhODZeiH8g?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 4 years') {
                                          return 'https://th.bing.com/th/id/OIG1.RRqNkXY3tW4xGB1pC.It?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else {
                                          return 'https://th.bing.com/th/id/OIG3.x714k9xPD8HEaEXV9bGW?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        }
                                      }(),
                                      width: 300.0,
                                      height: 200.0,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                              FlipCard(
                                fill: Fill.fillBack,
                                direction: FlipDirection.HORIZONTAL,
                                speed: 400,
                                front: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Align(
                                        alignment:
                                            AlignmentDirectional(0.0, -1.0),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 10.0, 0.0, 0.0),
                                          child: Text(
                                            FFLocalizations.of(context).getText(
                                              'tas1n45x' /* Cognitive */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge
                                                .override(
                                                  fontFamily: 'Readex Pro',
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 5.0, 10.0, 0.0),
                                        child: Text(
                                          FFLocalizations.of(context).getText(
                                            'probdyb1' /* These are thinking skills—lear... */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .labelMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 7.0, 10.0, 5.0),
                                        child: Text(
                                          functions.cognitive(FFAppState()
                                              .selectedValueDropDown)!,
                                          textAlign: TextAlign.start,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Outfit',
                                                fontSize: 14.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.normal,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                back: Container(
                                  width: 100.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(12.0),
                                      bottomRight: Radius.circular(12.0),
                                      topLeft: Radius.circular(12.0),
                                      topRight: Radius.circular(12.0),
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      () {
                                        if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 months') {
                                          return 'https://th.bing.com/th/id/OIG2.FU3LCXdLJrZv3S6a.3i2?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 8 months') {
                                          return 'https://th.bing.com/th/id/OIG4..u6AcB6LkH.I9n0NpFwP?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'between 12 and 14 months') {
                                          return 'https://th.bing.com/th/id/OIG4.XZgq_lgPGwV2gPr5Q.cl?pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 1.5 years') {
                                          return 'https://th.bing.com/th/id/OIG3.VilP4vcTDBYGy7sbdv3L?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 2 years') {
                                          return 'https://th.bing.com/th/id/OIG4.s3t1OgY1EPm8fA0Og6Ge?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 3 years') {
                                          return 'https://th.bing.com/th/id/OIG3.LFxRLoJJmMbCbOEBTsce?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else if (FFAppState()
                                                .selectedValueDropDown ==
                                            'at the end of 4 years') {
                                          return 'https://th.bing.com/th/id/OIG4.TS4jhs0U2X0Q9bnTtTek?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        } else {
                                          return 'https://th.bing.com/th/id/OIG2.GwHOLw6lNgjT.SpplbY0?w=270&h=270&c=6&r=0&o=5&dpr=1.5&pid=ImgGn';
                                        }
                                      }(),
                                      width: 300.0,
                                      height: 200.0,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                            carouselController: _model.carouselController ??=
                                CarouselController(),
                            options: CarouselOptions(
                              initialPage: 1,
                              viewportFraction: 0.8,
                              disableCenter: true,
                              enlargeCenterPage: true,
                              enlargeFactor: 0.25,
                              enableInfiniteScroll: true,
                              scrollDirection: Axis.horizontal,
                              autoPlay: false,
                              onPageChanged: (index, _) =>
                                  _model.carouselCurrentIndex = index,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
