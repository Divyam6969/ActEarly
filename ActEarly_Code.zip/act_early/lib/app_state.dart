import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _childDataAppState = prefs
              .getStringList('ff_childDataAppState')
              ?.map((x) {
                try {
                  return ChildDataStruct.fromSerializableMap(jsonDecode(x));
                } catch (e) {
                  print("Can't decode persisted data type. Error: $e.");
                  return null;
                }
              })
              .withoutNulls
              .toList() ??
          _childDataAppState;
    });
    _safeInit(() {
      _assistantId = prefs.getString('ff_assistantId') ?? _assistantId;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _selectedValueDropDown = '';
  String get selectedValueDropDown => _selectedValueDropDown;
  set selectedValueDropDown(String value) {
    _selectedValueDropDown = value;
  }

  bool _AlreadyRegistered = false;
  bool get AlreadyRegistered => _AlreadyRegistered;
  set AlreadyRegistered(bool value) {
    _AlreadyRegistered = value;
  }

  List<ChildDataStruct> _childDataAppState = [];
  List<ChildDataStruct> get childDataAppState => _childDataAppState;
  set childDataAppState(List<ChildDataStruct> value) {
    _childDataAppState = value;
    prefs.setStringList(
        'ff_childDataAppState', value.map((x) => x.serialize()).toList());
  }

  void addToChildDataAppState(ChildDataStruct value) {
    childDataAppState.add(value);
    prefs.setStringList('ff_childDataAppState',
        _childDataAppState.map((x) => x.serialize()).toList());
  }

  void removeFromChildDataAppState(ChildDataStruct value) {
    childDataAppState.remove(value);
    prefs.setStringList('ff_childDataAppState',
        _childDataAppState.map((x) => x.serialize()).toList());
  }

  void removeAtIndexFromChildDataAppState(int index) {
    childDataAppState.removeAt(index);
    prefs.setStringList('ff_childDataAppState',
        _childDataAppState.map((x) => x.serialize()).toList());
  }

  void updateChildDataAppStateAtIndex(
    int index,
    ChildDataStruct Function(ChildDataStruct) updateFn,
  ) {
    childDataAppState[index] = updateFn(_childDataAppState[index]);
    prefs.setStringList('ff_childDataAppState',
        _childDataAppState.map((x) => x.serialize()).toList());
  }

  void insertAtIndexInChildDataAppState(int index, ChildDataStruct value) {
    childDataAppState.insert(index, value);
    prefs.setStringList('ff_childDataAppState',
        _childDataAppState.map((x) => x.serialize()).toList());
  }

  DateTime? _birthDate;
  DateTime? get birthDate => _birthDate;
  set birthDate(DateTime? value) {
    _birthDate = value;
  }

  List<String> _gross1to6MonthsQuestions = [
    'roll from front to back',
    'control head and neck movement when sitting',
    'raise their head and chest when lying on their stomach',
    'stretch out and kick their legs when lying on their stomach or back',
    'push down with their legs when feet are on a firm surface'
  ];
  List<String> get gross1to6MonthsQuestions => _gross1to6MonthsQuestions;
  set gross1to6MonthsQuestions(List<String> value) {
    _gross1to6MonthsQuestions = value;
  }

  void addToGross1to6MonthsQuestions(String value) {
    gross1to6MonthsQuestions.add(value);
  }

  void removeFromGross1to6MonthsQuestions(String value) {
    gross1to6MonthsQuestions.remove(value);
  }

  void removeAtIndexFromGross1to6MonthsQuestions(int index) {
    gross1to6MonthsQuestions.removeAt(index);
  }

  void updateGross1to6MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross1to6MonthsQuestions[index] =
        updateFn(_gross1to6MonthsQuestions[index]);
  }

  void insertAtIndexInGross1to6MonthsQuestions(int index, String value) {
    gross1to6MonthsQuestions.insert(index, value);
  }

  List<String> _fine1to6MonthQuestions = [
    'bring their hands together',
    'open and shut their hands',
    'bring their hands to their mouth',
    'take swipes at a hanging object'
  ];
  List<String> get fine1to6MonthQuestions => _fine1to6MonthQuestions;
  set fine1to6MonthQuestions(List<String> value) {
    _fine1to6MonthQuestions = value;
  }

  void addToFine1to6MonthQuestions(String value) {
    fine1to6MonthQuestions.add(value);
  }

  void removeFromFine1to6MonthQuestions(String value) {
    fine1to6MonthQuestions.remove(value);
  }

  void removeAtIndexFromFine1to6MonthQuestions(int index) {
    fine1to6MonthQuestions.removeAt(index);
  }

  void updateFine1to6MonthQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine1to6MonthQuestions[index] = updateFn(_fine1to6MonthQuestions[index]);
  }

  void insertAtIndexInFine1to6MonthQuestions(int index, String value) {
    fine1to6MonthQuestions.insert(index, value);
  }

  List<String> _social1to6MonthsQuestions = [
    'smile when you smile and on their own',
    'be expressive and communicate with their face and body',
    'copy some body movements and facial expressions'
  ];
  List<String> get social1to6MonthsQuestions => _social1to6MonthsQuestions;
  set social1to6MonthsQuestions(List<String> value) {
    _social1to6MonthsQuestions = value;
  }

  void addToSocial1to6MonthsQuestions(String value) {
    social1to6MonthsQuestions.add(value);
  }

  void removeFromSocial1to6MonthsQuestions(String value) {
    social1to6MonthsQuestions.remove(value);
  }

  void removeAtIndexFromSocial1to6MonthsQuestions(int index) {
    social1to6MonthsQuestions.removeAt(index);
  }

  void updateSocial1to6MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social1to6MonthsQuestions[index] =
        updateFn(_social1to6MonthsQuestions[index]);
  }

  void insertAtIndexInSocial1to6MonthsQuestions(int index, String value) {
    social1to6MonthsQuestions.insert(index, value);
  }

  List<String> _cognitive1to6MonthsQuestions = [
    'watch faces closely',
    'follow moving objects',
    'recognize objects and people they know'
  ];
  List<String> get cognitive1to6MonthsQuestions =>
      _cognitive1to6MonthsQuestions;
  set cognitive1to6MonthsQuestions(List<String> value) {
    _cognitive1to6MonthsQuestions = value;
  }

  void addToCognitive1to6MonthsQuestions(String value) {
    cognitive1to6MonthsQuestions.add(value);
  }

  void removeFromCognitive1to6MonthsQuestions(String value) {
    cognitive1to6MonthsQuestions.remove(value);
  }

  void removeAtIndexFromCognitive1to6MonthsQuestions(int index) {
    cognitive1to6MonthsQuestions.removeAt(index);
  }

  void updateCognitive1to6MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive1to6MonthsQuestions[index] =
        updateFn(_cognitive1to6MonthsQuestions[index]);
  }

  void insertAtIndexInCognitive1to6MonthsQuestions(int index, String value) {
    cognitive1to6MonthsQuestions.insert(index, value);
  }

  List<String> _gross6to11MonthsQuestions = [
    'roll both ways (front to back, back to front)',
    'sit on their own',
    'support their whole weight on their legs',
    'control their upper body and arms'
  ];
  List<String> get gross6to11MonthsQuestions => _gross6to11MonthsQuestions;
  set gross6to11MonthsQuestions(List<String> value) {
    _gross6to11MonthsQuestions = value;
  }

  void addToGross6to11MonthsQuestions(String value) {
    gross6to11MonthsQuestions.add(value);
  }

  void removeFromGross6to11MonthsQuestions(String value) {
    gross6to11MonthsQuestions.remove(value);
  }

  void removeAtIndexFromGross6to11MonthsQuestions(int index) {
    gross6to11MonthsQuestions.removeAt(index);
  }

  void updateGross6to11MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross6to11MonthsQuestions[index] =
        updateFn(_gross6to11MonthsQuestions[index]);
  }

  void insertAtIndexInGross6to11MonthsQuestions(int index, String value) {
    gross6to11MonthsQuestions.insert(index, value);
  }

  List<String> _fine6to11MonthsQuestions = [
    'hold and shake a hand toy',
    'move an object from hand to hand',
    'use their hands to explore an object'
  ];
  List<String> get fine6to11MonthsQuestions => _fine6to11MonthsQuestions;
  set fine6to11MonthsQuestions(List<String> value) {
    _fine6to11MonthsQuestions = value;
  }

  void addToFine6to11MonthsQuestions(String value) {
    fine6to11MonthsQuestions.add(value);
  }

  void removeFromFine6to11MonthsQuestions(String value) {
    fine6to11MonthsQuestions.remove(value);
  }

  void removeAtIndexFromFine6to11MonthsQuestions(int index) {
    fine6to11MonthsQuestions.removeAt(index);
  }

  void updateFine6to11MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine6to11MonthsQuestions[index] =
        updateFn(_fine6to11MonthsQuestions[index]);
  }

  void insertAtIndexInFine6to11MonthsQuestions(int index, String value) {
    fine6to11MonthsQuestions.insert(index, value);
  }

  List<String> _social6to11MonthsQuestions = [
    'reach for a person they know',
    'smile at themselves in a mirror',
    'respond when others express emotion',
    'copy speech sounds'
  ];
  List<String> get social6to11MonthsQuestions => _social6to11MonthsQuestions;
  set social6to11MonthsQuestions(List<String> value) {
    _social6to11MonthsQuestions = value;
  }

  void addToSocial6to11MonthsQuestions(String value) {
    social6to11MonthsQuestions.add(value);
  }

  void removeFromSocial6to11MonthsQuestions(String value) {
    social6to11MonthsQuestions.remove(value);
  }

  void removeAtIndexFromSocial6to11MonthsQuestions(int index) {
    social6to11MonthsQuestions.removeAt(index);
  }

  void updateSocial6to11MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social6to11MonthsQuestions[index] =
        updateFn(_social6to11MonthsQuestions[index]);
  }

  void insertAtIndexInSocial6to11MonthsQuestions(int index, String value) {
    social6to11MonthsQuestions.insert(index, value);
  }

  List<String> _cognitive6to11MonthsQuestions = [
    'track a moving object, and find one that is partially hidden',
    'explore with hands and mouth',
    'struggle to get objects that are out of reach',
    'look from one object to another',
    'watch a falling object'
  ];
  List<String> get cognitive6to11MonthsQuestions =>
      _cognitive6to11MonthsQuestions;
  set cognitive6to11MonthsQuestions(List<String> value) {
    _cognitive6to11MonthsQuestions = value;
  }

  void addToCognitive6to11MonthsQuestions(String value) {
    cognitive6to11MonthsQuestions.add(value);
  }

  void removeFromCognitive6to11MonthsQuestions(String value) {
    cognitive6to11MonthsQuestions.remove(value);
  }

  void removeAtIndexFromCognitive6to11MonthsQuestions(int index) {
    cognitive6to11MonthsQuestions.removeAt(index);
  }

  void updateCognitive6to11MonthsQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive6to11MonthsQuestions[index] =
        updateFn(_cognitive6to11MonthsQuestions[index]);
  }

  void insertAtIndexInCognitive6to11MonthsQuestions(int index, String value) {
    cognitive6to11MonthsQuestions.insert(index, value);
  }

  List<String> _gross1yearQuestions = [
    'reach a sitting position without help',
    'crawl on hands and knees, or scoot around on their bum',
    'get from a sitting to a crawling or prone (on their stomach) position',
    'pull up to a standing position',
    'cruise, holding onto furniture',
    'stand briefly without support',
    'walk holding an adult’s hand, and maybe take 2 or 3 steps on their own',
    'start to climb stairs with help'
  ];
  List<String> get gross1yearQuestions => _gross1yearQuestions;
  set gross1yearQuestions(List<String> value) {
    _gross1yearQuestions = value;
  }

  void addToGross1yearQuestions(String value) {
    gross1yearQuestions.add(value);
  }

  void removeFromGross1yearQuestions(String value) {
    gross1yearQuestions.remove(value);
  }

  void removeAtIndexFromGross1yearQuestions(int index) {
    gross1yearQuestions.removeAt(index);
  }

  void updateGross1yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross1yearQuestions[index] = updateFn(_gross1yearQuestions[index]);
  }

  void insertAtIndexInGross1yearQuestions(int index, String value) {
    gross1yearQuestions.insert(index, value);
  }

  List<String> _fine1yearQuestions = [
    'finger-feed using thumb and fore-finger (pincer grasp)',
    'put objects into a container (and take them out again)',
    'release objects voluntarily',
    'poke with an index finger',
    'push a toy',
    'begin to drink from a cup',
    'scribble with a crayon',
    'begin to use a spoon'
  ];
  List<String> get fine1yearQuestions => _fine1yearQuestions;
  set fine1yearQuestions(List<String> value) {
    _fine1yearQuestions = value;
  }

  void addToFine1yearQuestions(String value) {
    fine1yearQuestions.add(value);
  }

  void removeFromFine1yearQuestions(String value) {
    fine1yearQuestions.remove(value);
  }

  void removeAtIndexFromFine1yearQuestions(int index) {
    fine1yearQuestions.removeAt(index);
  }

  void updateFine1yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine1yearQuestions[index] = updateFn(_fine1yearQuestions[index]);
  }

  void insertAtIndexInFine1yearQuestions(int index, String value) {
    fine1yearQuestions.insert(index, value);
  }

  List<String> _social1yearQuestions = [
    'not be shy or anxious with strangers',
    'copy during play',
    'have favourite toys and people',
    'test limits to actions and behaviours',
    'put out an arm or leg to help when being dressed',
    'take off socks',
    'come when called (respond to name)',
    'say “mama” or “dada” with at least one other word with meaning',
    'communicate a need without crying',
    'stop an action if you say “no”'
  ];
  List<String> get social1yearQuestions => _social1yearQuestions;
  set social1yearQuestions(List<String> value) {
    _social1yearQuestions = value;
  }

  void addToSocial1yearQuestions(String value) {
    social1yearQuestions.add(value);
  }

  void removeFromSocial1yearQuestions(String value) {
    social1yearQuestions.remove(value);
  }

  void removeAtIndexFromSocial1yearQuestions(int index) {
    social1yearQuestions.removeAt(index);
  }

  void updateSocial1yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social1yearQuestions[index] = updateFn(_social1yearQuestions[index]);
  }

  void insertAtIndexInSocial1yearQuestions(int index, String value) {
    social1yearQuestions.insert(index, value);
  }

  List<String> _cognitive1yearQuestions = [
    'explore objects in different ways (shaking, banging, throwing, dropping)',
    'know the names of familiar objects',
    'respond to music',
    'begin to explore cause and effect'
  ];
  List<String> get cognitive1yearQuestions => _cognitive1yearQuestions;
  set cognitive1yearQuestions(List<String> value) {
    _cognitive1yearQuestions = value;
  }

  void addToCognitive1yearQuestions(String value) {
    cognitive1yearQuestions.add(value);
  }

  void removeFromCognitive1yearQuestions(String value) {
    cognitive1yearQuestions.remove(value);
  }

  void removeAtIndexFromCognitive1yearQuestions(int index) {
    cognitive1yearQuestions.removeAt(index);
  }

  void updateCognitive1yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive1yearQuestions[index] = updateFn(_cognitive1yearQuestions[index]);
  }

  void insertAtIndexInCognitive1yearQuestions(int index, String value) {
    cognitive1yearQuestions.insert(index, value);
  }

  List<String> _gross2yearQuestions = [
    'pull a toy while walking',
    'carry a large toy or more than one toy while walking',
    'begin to run',
    'kick or throw a ball',
    'climb into and get down from chairs without help',
    'walk up and down stairs with help'
  ];
  List<String> get gross2yearQuestions => _gross2yearQuestions;
  set gross2yearQuestions(List<String> value) {
    _gross2yearQuestions = value;
  }

  void addToGross2yearQuestions(String value) {
    gross2yearQuestions.add(value);
  }

  void removeFromGross2yearQuestions(String value) {
    gross2yearQuestions.remove(value);
  }

  void removeAtIndexFromGross2yearQuestions(int index) {
    gross2yearQuestions.removeAt(index);
  }

  void updateGross2yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross2yearQuestions[index] = updateFn(_gross2yearQuestions[index]);
  }

  void insertAtIndexInGross2yearQuestions(int index, String value) {
    gross2yearQuestions.insert(index, value);
  }

  List<String> _fine2yearQuestions = [
    'build a tower of 4 blocks or more',
    'complete a simple shape-matching puzzle',
    'turn board-book pages easily, one at a time'
  ];
  List<String> get fine2yearQuestions => _fine2yearQuestions;
  set fine2yearQuestions(List<String> value) {
    _fine2yearQuestions = value;
  }

  void addToFine2yearQuestions(String value) {
    fine2yearQuestions.add(value);
  }

  void removeFromFine2yearQuestions(String value) {
    fine2yearQuestions.remove(value);
  }

  void removeAtIndexFromFine2yearQuestions(int index) {
    fine2yearQuestions.removeAt(index);
  }

  void updateFine2yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine2yearQuestions[index] = updateFn(_fine2yearQuestions[index]);
  }

  void insertAtIndexInFine2yearQuestions(int index, String value) {
    fine2yearQuestions.insert(index, value);
  }

  List<String> _social2yearQuestions = [
    'start to put 2 words together',
    'copy the behaviour of adults and other children',
    'get excited about being with other children',
    'play alongside other children',
    'show increasing independence',
    'show defiant behaviour'
  ];
  List<String> get social2yearQuestions => _social2yearQuestions;
  set social2yearQuestions(List<String> value) {
    _social2yearQuestions = value;
  }

  void addToSocial2yearQuestions(String value) {
    social2yearQuestions.add(value);
  }

  void removeFromSocial2yearQuestions(String value) {
    social2yearQuestions.remove(value);
  }

  void removeAtIndexFromSocial2yearQuestions(int index) {
    social2yearQuestions.removeAt(index);
  }

  void updateSocial2yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social2yearQuestions[index] = updateFn(_social2yearQuestions[index]);
  }

  void insertAtIndexInSocial2yearQuestions(int index, String value) {
    social2yearQuestions.insert(index, value);
  }

  List<String> _cognitive2yearQuestions = [
    'use objects as tools',
    'fit related objects together (e.g., in a shape sorter)',
    'begin “make-believe” play'
  ];
  List<String> get cognitive2yearQuestions => _cognitive2yearQuestions;
  set cognitive2yearQuestions(List<String> value) {
    _cognitive2yearQuestions = value;
  }

  void addToCognitive2yearQuestions(String value) {
    cognitive2yearQuestions.add(value);
  }

  void removeFromCognitive2yearQuestions(String value) {
    cognitive2yearQuestions.remove(value);
  }

  void removeAtIndexFromCognitive2yearQuestions(int index) {
    cognitive2yearQuestions.removeAt(index);
  }

  void updateCognitive2yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive2yearQuestions[index] = updateFn(_cognitive2yearQuestions[index]);
  }

  void insertAtIndexInCognitive2yearQuestions(int index, String value) {
    cognitive2yearQuestions.insert(index, value);
  }

  List<String> _gross3yearQuestions = [
    'walk up and down stairs, alternating feet (one foot per stair)',
    'run easily',
    'jump in place',
    'throw a ball overhead'
  ];
  List<String> get gross3yearQuestions => _gross3yearQuestions;
  set gross3yearQuestions(List<String> value) {
    _gross3yearQuestions = value;
  }

  void addToGross3yearQuestions(String value) {
    gross3yearQuestions.add(value);
  }

  void removeFromGross3yearQuestions(String value) {
    gross3yearQuestions.remove(value);
  }

  void removeAtIndexFromGross3yearQuestions(int index) {
    gross3yearQuestions.removeAt(index);
  }

  void updateGross3yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross3yearQuestions[index] = updateFn(_gross3yearQuestions[index]);
  }

  void insertAtIndexInGross3yearQuestions(int index, String value) {
    gross3yearQuestions.insert(index, value);
  }

  List<String> _fine3yearQuestions = [
    'make up-and-down, side-to-side and circular lines with a pencil or crayon',
    'build a tower of more than 6 blocks',
    'hold a pencil in a writing position',
    'screw and unscrew jar lids or big nuts and bolts',
    'string big beads',
    'work latches and hooks',
    'snip with children’s scissors'
  ];
  List<String> get fine3yearQuestions => _fine3yearQuestions;
  set fine3yearQuestions(List<String> value) {
    _fine3yearQuestions = value;
  }

  void addToFine3yearQuestions(String value) {
    fine3yearQuestions.add(value);
  }

  void removeFromFine3yearQuestions(String value) {
    fine3yearQuestions.remove(value);
  }

  void removeAtIndexFromFine3yearQuestions(int index) {
    fine3yearQuestions.removeAt(index);
  }

  void updateFine3yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine3yearQuestions[index] = updateFn(_fine3yearQuestions[index]);
  }

  void insertAtIndexInFine3yearQuestions(int index, String value) {
    fine3yearQuestions.insert(index, value);
  }

  List<String> _social3yearQuestions = [
    'show spontaneous affection for playmates they know',
    'begin to take turns',
    'understand the concept of “mine” vs. “someone else’s”',
    'object to changes in routine',
    'anticipate daily activities',
    'speak in sentences and ask a lot of questions',
    'put toys away',
    'ask for help',
    'know their full name'
  ];
  List<String> get social3yearQuestions => _social3yearQuestions;
  set social3yearQuestions(List<String> value) {
    _social3yearQuestions = value;
  }

  void addToSocial3yearQuestions(String value) {
    social3yearQuestions.add(value);
  }

  void removeFromSocial3yearQuestions(String value) {
    social3yearQuestions.remove(value);
  }

  void removeAtIndexFromSocial3yearQuestions(int index) {
    social3yearQuestions.removeAt(index);
  }

  void updateSocial3yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social3yearQuestions[index] = updateFn(_social3yearQuestions[index]);
  }

  void insertAtIndexInSocial3yearQuestions(int index, String value) {
    social3yearQuestions.insert(index, value);
  }

  List<String> _cognitive3yearQuestions = [
    'match an object in their hand or the room to a picture in a book',
    'include animals, dolls and people in make-believe play',
    'sort easily by shape and colour',
    'complete a puzzle with 3 or 4 pieces',
    'understand the difference between 1 and 2',
    'name body parts and colours'
  ];
  List<String> get cognitive3yearQuestions => _cognitive3yearQuestions;
  set cognitive3yearQuestions(List<String> value) {
    _cognitive3yearQuestions = value;
  }

  void addToCognitive3yearQuestions(String value) {
    cognitive3yearQuestions.add(value);
  }

  void removeFromCognitive3yearQuestions(String value) {
    cognitive3yearQuestions.remove(value);
  }

  void removeAtIndexFromCognitive3yearQuestions(int index) {
    cognitive3yearQuestions.removeAt(index);
  }

  void updateCognitive3yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive3yearQuestions[index] = updateFn(_cognitive3yearQuestions[index]);
  }

  void insertAtIndexInCognitive3yearQuestions(int index, String value) {
    cognitive3yearQuestions.insert(index, value);
  }

  List<String> _gross4yearQuestions = [
    'hop and stand on 1 foot for up to 4 seconds',
    'kick a ball forward',
    'catch a bouncing ball'
  ];
  List<String> get gross4yearQuestions => _gross4yearQuestions;
  set gross4yearQuestions(List<String> value) {
    _gross4yearQuestions = value;
  }

  void addToGross4yearQuestions(String value) {
    gross4yearQuestions.add(value);
  }

  void removeFromGross4yearQuestions(String value) {
    gross4yearQuestions.remove(value);
  }

  void removeAtIndexFromGross4yearQuestions(int index) {
    gross4yearQuestions.removeAt(index);
  }

  void updateGross4yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross4yearQuestions[index] = updateFn(_gross4yearQuestions[index]);
  }

  void insertAtIndexInGross4yearQuestions(int index, String value) {
    gross4yearQuestions.insert(index, value);
  }

  List<String> _fine4yearQuestions = [
    'draw a person with 2 to 4 body parts',
    'use children’s scissors',
    'draw circles and squares',
    'twiddle thumbs',
    'do a finger-to-thumb sequence (e.g., Itsy-Bitsy Spider)'
  ];
  List<String> get fine4yearQuestions => _fine4yearQuestions;
  set fine4yearQuestions(List<String> value) {
    _fine4yearQuestions = value;
  }

  void addToFine4yearQuestions(String value) {
    fine4yearQuestions.add(value);
  }

  void removeFromFine4yearQuestions(String value) {
    fine4yearQuestions.remove(value);
  }

  void removeAtIndexFromFine4yearQuestions(int index) {
    fine4yearQuestions.removeAt(index);
  }

  void updateFine4yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine4yearQuestions[index] = updateFn(_fine4yearQuestions[index]);
  }

  void insertAtIndexInFine4yearQuestions(int index, String value) {
    fine4yearQuestions.insert(index, value);
  }

  List<String> _social4yearQuestions = [
    'look forward to new experiences',
    'cooperate with other children',
    'play “Mom” or “Dad”',
    'be very inventive',
    'dress and undress',
    'imagine monsters',
    'negotiate solutions to conflicts'
  ];
  List<String> get social4yearQuestions => _social4yearQuestions;
  set social4yearQuestions(List<String> value) {
    _social4yearQuestions = value;
  }

  void addToSocial4yearQuestions(String value) {
    social4yearQuestions.add(value);
  }

  void removeFromSocial4yearQuestions(String value) {
    social4yearQuestions.remove(value);
  }

  void removeAtIndexFromSocial4yearQuestions(int index) {
    social4yearQuestions.removeAt(index);
  }

  void updateSocial4yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social4yearQuestions[index] = updateFn(_social4yearQuestions[index]);
  }

  void insertAtIndexInSocial4yearQuestions(int index, String value) {
    social4yearQuestions.insert(index, value);
  }

  List<String> _cognitive4yearQuestions = [
    'understand counting',
    'follow a 3-part instruction',
    'recall parts of a story',
    'make up and tell simple stories',
    'understand “same” and “different”',
    'enjoy fantasy play',
    'know their address'
  ];
  List<String> get cognitive4yearQuestions => _cognitive4yearQuestions;
  set cognitive4yearQuestions(List<String> value) {
    _cognitive4yearQuestions = value;
  }

  void addToCognitive4yearQuestions(String value) {
    cognitive4yearQuestions.add(value);
  }

  void removeFromCognitive4yearQuestions(String value) {
    cognitive4yearQuestions.remove(value);
  }

  void removeAtIndexFromCognitive4yearQuestions(int index) {
    cognitive4yearQuestions.removeAt(index);
  }

  void updateCognitive4yearQuestionsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive4yearQuestions[index] = updateFn(_cognitive4yearQuestions[index]);
  }

  void insertAtIndexInCognitive4yearQuestions(int index, String value) {
    cognitive4yearQuestions.insert(index, value);
  }

  List<AnswerValueStruct> _gross1to6monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"roll from front to back\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"control head and neck movement when sitting\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"raise their head and chest when lying on their stomach\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"stretch out and kick their legs when lying on their stomach or back\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"push down with their legs when feet are on a firm surface\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get gross1to6monthQ => _gross1to6monthQ;
  set gross1to6monthQ(List<AnswerValueStruct> value) {
    _gross1to6monthQ = value;
  }

  void addToGross1to6monthQ(AnswerValueStruct value) {
    gross1to6monthQ.add(value);
  }

  void removeFromGross1to6monthQ(AnswerValueStruct value) {
    gross1to6monthQ.remove(value);
  }

  void removeAtIndexFromGross1to6monthQ(int index) {
    gross1to6monthQ.removeAt(index);
  }

  void updateGross1to6monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    gross1to6monthQ[index] = updateFn(_gross1to6monthQ[index]);
  }

  void insertAtIndexInGross1to6monthQ(int index, AnswerValueStruct value) {
    gross1to6monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _fine1to6monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"bring their hands together\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"open and shut their hands\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"bring their hands to their mouth\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"take swipes at a hanging object\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get fine1to6monthQ => _fine1to6monthQ;
  set fine1to6monthQ(List<AnswerValueStruct> value) {
    _fine1to6monthQ = value;
  }

  void addToFine1to6monthQ(AnswerValueStruct value) {
    fine1to6monthQ.add(value);
  }

  void removeFromFine1to6monthQ(AnswerValueStruct value) {
    fine1to6monthQ.remove(value);
  }

  void removeAtIndexFromFine1to6monthQ(int index) {
    fine1to6monthQ.removeAt(index);
  }

  void updateFine1to6monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    fine1to6monthQ[index] = updateFn(_fine1to6monthQ[index]);
  }

  void insertAtIndexInFine1to6monthQ(int index, AnswerValueStruct value) {
    fine1to6monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _social1to6monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"smile when you smile and on their own\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"be expressive and communicate with their face and body\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"copy some body movements and facial expressions\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get social1to6monthQ => _social1to6monthQ;
  set social1to6monthQ(List<AnswerValueStruct> value) {
    _social1to6monthQ = value;
  }

  void addToSocial1to6monthQ(AnswerValueStruct value) {
    social1to6monthQ.add(value);
  }

  void removeFromSocial1to6monthQ(AnswerValueStruct value) {
    social1to6monthQ.remove(value);
  }

  void removeAtIndexFromSocial1to6monthQ(int index) {
    social1to6monthQ.removeAt(index);
  }

  void updateSocial1to6monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    social1to6monthQ[index] = updateFn(_social1to6monthQ[index]);
  }

  void insertAtIndexInSocial1to6monthQ(int index, AnswerValueStruct value) {
    social1to6monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _cognitive1to6monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"watch faces closely\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"follow moving objects\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"recognize objects and people they know\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get cognitive1to6monthQ => _cognitive1to6monthQ;
  set cognitive1to6monthQ(List<AnswerValueStruct> value) {
    _cognitive1to6monthQ = value;
  }

  void addToCognitive1to6monthQ(AnswerValueStruct value) {
    cognitive1to6monthQ.add(value);
  }

  void removeFromCognitive1to6monthQ(AnswerValueStruct value) {
    cognitive1to6monthQ.remove(value);
  }

  void removeAtIndexFromCognitive1to6monthQ(int index) {
    cognitive1to6monthQ.removeAt(index);
  }

  void updateCognitive1to6monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    cognitive1to6monthQ[index] = updateFn(_cognitive1to6monthQ[index]);
  }

  void insertAtIndexInCognitive1to6monthQ(int index, AnswerValueStruct value) {
    cognitive1to6monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _gross6to11monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"roll both ways (front to back, back to front)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"sit on their own\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"support their whole weight on their legs\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"control their upper body and arms\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get gross6to11monthQ => _gross6to11monthQ;
  set gross6to11monthQ(List<AnswerValueStruct> value) {
    _gross6to11monthQ = value;
  }

  void addToGross6to11monthQ(AnswerValueStruct value) {
    gross6to11monthQ.add(value);
  }

  void removeFromGross6to11monthQ(AnswerValueStruct value) {
    gross6to11monthQ.remove(value);
  }

  void removeAtIndexFromGross6to11monthQ(int index) {
    gross6to11monthQ.removeAt(index);
  }

  void updateGross6to11monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    gross6to11monthQ[index] = updateFn(_gross6to11monthQ[index]);
  }

  void insertAtIndexInGross6to11monthQ(int index, AnswerValueStruct value) {
    gross6to11monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _fine6to11monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"hold and shake a hand toy\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"move an object from hand to hand\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"use their hands to explore an object\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get fine6to11monthQ => _fine6to11monthQ;
  set fine6to11monthQ(List<AnswerValueStruct> value) {
    _fine6to11monthQ = value;
  }

  void addToFine6to11monthQ(AnswerValueStruct value) {
    fine6to11monthQ.add(value);
  }

  void removeFromFine6to11monthQ(AnswerValueStruct value) {
    fine6to11monthQ.remove(value);
  }

  void removeAtIndexFromFine6to11monthQ(int index) {
    fine6to11monthQ.removeAt(index);
  }

  void updateFine6to11monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    fine6to11monthQ[index] = updateFn(_fine6to11monthQ[index]);
  }

  void insertAtIndexInFine6to11monthQ(int index, AnswerValueStruct value) {
    fine6to11monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _social6to11monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"reach for a person they know\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"smile at themselves in a mirror\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"respond when others express emotion\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"copy speech sounds\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get social6to11monthQ => _social6to11monthQ;
  set social6to11monthQ(List<AnswerValueStruct> value) {
    _social6to11monthQ = value;
  }

  void addToSocial6to11monthQ(AnswerValueStruct value) {
    social6to11monthQ.add(value);
  }

  void removeFromSocial6to11monthQ(AnswerValueStruct value) {
    social6to11monthQ.remove(value);
  }

  void removeAtIndexFromSocial6to11monthQ(int index) {
    social6to11monthQ.removeAt(index);
  }

  void updateSocial6to11monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    social6to11monthQ[index] = updateFn(_social6to11monthQ[index]);
  }

  void insertAtIndexInSocial6to11monthQ(int index, AnswerValueStruct value) {
    social6to11monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _cognitive6to11monthQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"track a moving object, and find one that is partially hidden\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"explore with hands and mouth\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"struggle to get objects that are out of reach\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"look from one object to another\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"watch a falling object\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get cognitive6to11monthQ => _cognitive6to11monthQ;
  set cognitive6to11monthQ(List<AnswerValueStruct> value) {
    _cognitive6to11monthQ = value;
  }

  void addToCognitive6to11monthQ(AnswerValueStruct value) {
    cognitive6to11monthQ.add(value);
  }

  void removeFromCognitive6to11monthQ(AnswerValueStruct value) {
    cognitive6to11monthQ.remove(value);
  }

  void removeAtIndexFromCognitive6to11monthQ(int index) {
    cognitive6to11monthQ.removeAt(index);
  }

  void updateCognitive6to11monthQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    cognitive6to11monthQ[index] = updateFn(_cognitive6to11monthQ[index]);
  }

  void insertAtIndexInCognitive6to11monthQ(int index, AnswerValueStruct value) {
    cognitive6to11monthQ.insert(index, value);
  }

  List<AnswerValueStruct> _gross1yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"reach a sitting position without help\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"crawl on hands and knees, or scoot around on their bum\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"get from a sitting to a crawling or prone (on their stomach) position\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"pull up to a standing position\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"cruise, holding onto furniture\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"stand briefly without support\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"walk holding an adult’s hand, and maybe take 2 or 3 steps on their own\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"start to climb stairs with help\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get gross1yearQ => _gross1yearQ;
  set gross1yearQ(List<AnswerValueStruct> value) {
    _gross1yearQ = value;
  }

  void addToGross1yearQ(AnswerValueStruct value) {
    gross1yearQ.add(value);
  }

  void removeFromGross1yearQ(AnswerValueStruct value) {
    gross1yearQ.remove(value);
  }

  void removeAtIndexFromGross1yearQ(int index) {
    gross1yearQ.removeAt(index);
  }

  void updateGross1yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    gross1yearQ[index] = updateFn(_gross1yearQ[index]);
  }

  void insertAtIndexInGross1yearQ(int index, AnswerValueStruct value) {
    gross1yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _fine1yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"finger-feed using thumb and fore-finger (pincer grasp)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"put objects into a container (and take them out again)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"release objects voluntarily\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"poke with an index finger\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(
        jsonDecode('{\"question\":\"push a toy\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"begin to drink from a cup\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"scribble with a crayon\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"begin to use a spoon\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get fine1yearQ => _fine1yearQ;
  set fine1yearQ(List<AnswerValueStruct> value) {
    _fine1yearQ = value;
  }

  void addToFine1yearQ(AnswerValueStruct value) {
    fine1yearQ.add(value);
  }

  void removeFromFine1yearQ(AnswerValueStruct value) {
    fine1yearQ.remove(value);
  }

  void removeAtIndexFromFine1yearQ(int index) {
    fine1yearQ.removeAt(index);
  }

  void updateFine1yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    fine1yearQ[index] = updateFn(_fine1yearQ[index]);
  }

  void insertAtIndexInFine1yearQ(int index, AnswerValueStruct value) {
    fine1yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _social1yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"be shy or anxious with strangers\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"copy during play\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"have favourite toys and people\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"test limits to actions and behaviours\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"put out an arm or leg to help when being dressed\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"take off socks\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"come when called (respond to name)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"say “mama” or “dada” with at least one other word with meaning\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"communicate a need without crying\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"stop an action if you say “no”\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get social1yearQ => _social1yearQ;
  set social1yearQ(List<AnswerValueStruct> value) {
    _social1yearQ = value;
  }

  void addToSocial1yearQ(AnswerValueStruct value) {
    social1yearQ.add(value);
  }

  void removeFromSocial1yearQ(AnswerValueStruct value) {
    social1yearQ.remove(value);
  }

  void removeAtIndexFromSocial1yearQ(int index) {
    social1yearQ.removeAt(index);
  }

  void updateSocial1yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    social1yearQ[index] = updateFn(_social1yearQ[index]);
  }

  void insertAtIndexInSocial1yearQ(int index, AnswerValueStruct value) {
    social1yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _cognitive1yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"explore objects in different ways (shaking, banging, throwing, dropping)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"know the names of familiar objects\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"respond to music\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"begin to explore cause and effect\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get cognitive1yearQ => _cognitive1yearQ;
  set cognitive1yearQ(List<AnswerValueStruct> value) {
    _cognitive1yearQ = value;
  }

  void addToCognitive1yearQ(AnswerValueStruct value) {
    cognitive1yearQ.add(value);
  }

  void removeFromCognitive1yearQ(AnswerValueStruct value) {
    cognitive1yearQ.remove(value);
  }

  void removeAtIndexFromCognitive1yearQ(int index) {
    cognitive1yearQ.removeAt(index);
  }

  void updateCognitive1yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    cognitive1yearQ[index] = updateFn(_cognitive1yearQ[index]);
  }

  void insertAtIndexInCognitive1yearQ(int index, AnswerValueStruct value) {
    cognitive1yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _gross2yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"pull a toy while walking\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"carry a large toy or more than one toy while walking\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"begin to run\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"kick or throw a ball\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"climb into and get down from chairs without help\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"walk up and down stairs with help\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get gross2yearQ => _gross2yearQ;
  set gross2yearQ(List<AnswerValueStruct> value) {
    _gross2yearQ = value;
  }

  void addToGross2yearQ(AnswerValueStruct value) {
    gross2yearQ.add(value);
  }

  void removeFromGross2yearQ(AnswerValueStruct value) {
    gross2yearQ.remove(value);
  }

  void removeAtIndexFromGross2yearQ(int index) {
    gross2yearQ.removeAt(index);
  }

  void updateGross2yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    gross2yearQ[index] = updateFn(_gross2yearQ[index]);
  }

  void insertAtIndexInGross2yearQ(int index, AnswerValueStruct value) {
    gross2yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _fine2yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"build a tower of 4 blocks or more\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"complete a simple shape-matching puzzle\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"turn board-book pages easily, one at a time\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get fine2yearQ => _fine2yearQ;
  set fine2yearQ(List<AnswerValueStruct> value) {
    _fine2yearQ = value;
  }

  void addToFine2yearQ(AnswerValueStruct value) {
    fine2yearQ.add(value);
  }

  void removeFromFine2yearQ(AnswerValueStruct value) {
    fine2yearQ.remove(value);
  }

  void removeAtIndexFromFine2yearQ(int index) {
    fine2yearQ.removeAt(index);
  }

  void updateFine2yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    fine2yearQ[index] = updateFn(_fine2yearQ[index]);
  }

  void insertAtIndexInFine2yearQ(int index, AnswerValueStruct value) {
    fine2yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _social2yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"start to put 2 words together\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"copy the behaviour of adults and other children\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"get excited about being with other children\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"play alongside other children\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"show increasing independence\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"show defiant behaviour\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get social2yearQ => _social2yearQ;
  set social2yearQ(List<AnswerValueStruct> value) {
    _social2yearQ = value;
  }

  void addToSocial2yearQ(AnswerValueStruct value) {
    social2yearQ.add(value);
  }

  void removeFromSocial2yearQ(AnswerValueStruct value) {
    social2yearQ.remove(value);
  }

  void removeAtIndexFromSocial2yearQ(int index) {
    social2yearQ.removeAt(index);
  }

  void updateSocial2yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    social2yearQ[index] = updateFn(_social2yearQ[index]);
  }

  void insertAtIndexInSocial2yearQ(int index, AnswerValueStruct value) {
    social2yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _cognitive2yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"use objects as tools\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"fit related objects together (e.g., in a shape sorter)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"begin “make-believe” play\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get cognitive2yearQ => _cognitive2yearQ;
  set cognitive2yearQ(List<AnswerValueStruct> value) {
    _cognitive2yearQ = value;
  }

  void addToCognitive2yearQ(AnswerValueStruct value) {
    cognitive2yearQ.add(value);
  }

  void removeFromCognitive2yearQ(AnswerValueStruct value) {
    cognitive2yearQ.remove(value);
  }

  void removeAtIndexFromCognitive2yearQ(int index) {
    cognitive2yearQ.removeAt(index);
  }

  void updateCognitive2yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    cognitive2yearQ[index] = updateFn(_cognitive2yearQ[index]);
  }

  void insertAtIndexInCognitive2yearQ(int index, AnswerValueStruct value) {
    cognitive2yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _gross3yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"walk up and down stairs, alternating feet (one foot per stair)\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(
        jsonDecode('{\"question\":\"run easily\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"jump in place\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"throw a ball overhead\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get gross3yearQ => _gross3yearQ;
  set gross3yearQ(List<AnswerValueStruct> value) {
    _gross3yearQ = value;
  }

  void addToGross3yearQ(AnswerValueStruct value) {
    gross3yearQ.add(value);
  }

  void removeFromGross3yearQ(AnswerValueStruct value) {
    gross3yearQ.remove(value);
  }

  void removeAtIndexFromGross3yearQ(int index) {
    gross3yearQ.removeAt(index);
  }

  void updateGross3yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    gross3yearQ[index] = updateFn(_gross3yearQ[index]);
  }

  void insertAtIndexInGross3yearQ(int index, AnswerValueStruct value) {
    gross3yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _fine3yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"make up-and-down, side-to-side and circular lines with a pencil or crayon\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"build a tower of more than 6 blocks\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"hold a pencil in a writing position\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"screw and unscrew jar lids or big nuts and bolts\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"string big beads\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"work latches and hooks\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"snip with children’s scissors\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get fine3yearQ => _fine3yearQ;
  set fine3yearQ(List<AnswerValueStruct> value) {
    _fine3yearQ = value;
  }

  void addToFine3yearQ(AnswerValueStruct value) {
    fine3yearQ.add(value);
  }

  void removeFromFine3yearQ(AnswerValueStruct value) {
    fine3yearQ.remove(value);
  }

  void removeAtIndexFromFine3yearQ(int index) {
    fine3yearQ.removeAt(index);
  }

  void updateFine3yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    fine3yearQ[index] = updateFn(_fine3yearQ[index]);
  }

  void insertAtIndexInFine3yearQ(int index, AnswerValueStruct value) {
    fine3yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _socia3yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"show spontaneous affection for playmates they know\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"begin to take turns\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"understand the concept of “mine” vs. “someone else’s”\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"object to changes in routine\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"anticipate daily activities\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"speak in sentences and ask a lot of questions\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"put toys away\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ask for help\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"know their full name\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get socia3yearQ => _socia3yearQ;
  set socia3yearQ(List<AnswerValueStruct> value) {
    _socia3yearQ = value;
  }

  void addToSocia3yearQ(AnswerValueStruct value) {
    socia3yearQ.add(value);
  }

  void removeFromSocia3yearQ(AnswerValueStruct value) {
    socia3yearQ.remove(value);
  }

  void removeAtIndexFromSocia3yearQ(int index) {
    socia3yearQ.removeAt(index);
  }

  void updateSocia3yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    socia3yearQ[index] = updateFn(_socia3yearQ[index]);
  }

  void insertAtIndexInSocia3yearQ(int index, AnswerValueStruct value) {
    socia3yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _cognitive3yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"match an object in their hand or the room to a picture in a book\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"include animals, dolls and people in make-believe play\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"sort easily by shape and colour\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"complete a puzzle with 3 or 4 pieces\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"understand the difference between 1 and 2\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"name body parts and colours\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get cognitive3yearQ => _cognitive3yearQ;
  set cognitive3yearQ(List<AnswerValueStruct> value) {
    _cognitive3yearQ = value;
  }

  void addToCognitive3yearQ(AnswerValueStruct value) {
    cognitive3yearQ.add(value);
  }

  void removeFromCognitive3yearQ(AnswerValueStruct value) {
    cognitive3yearQ.remove(value);
  }

  void removeAtIndexFromCognitive3yearQ(int index) {
    cognitive3yearQ.removeAt(index);
  }

  void updateCognitive3yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    cognitive3yearQ[index] = updateFn(_cognitive3yearQ[index]);
  }

  void insertAtIndexInCognitive3yearQ(int index, AnswerValueStruct value) {
    cognitive3yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _gross4yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"hop and stand on 1 foot for up to 4 seconds\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"kick a ball forward\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"catch a bouncing ball\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get gross4yearQ => _gross4yearQ;
  set gross4yearQ(List<AnswerValueStruct> value) {
    _gross4yearQ = value;
  }

  void addToGross4yearQ(AnswerValueStruct value) {
    gross4yearQ.add(value);
  }

  void removeFromGross4yearQ(AnswerValueStruct value) {
    gross4yearQ.remove(value);
  }

  void removeAtIndexFromGross4yearQ(int index) {
    gross4yearQ.removeAt(index);
  }

  void updateGross4yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    gross4yearQ[index] = updateFn(_gross4yearQ[index]);
  }

  void insertAtIndexInGross4yearQ(int index, AnswerValueStruct value) {
    gross4yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _fine4yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"draw a person with 2 to 4 body parts\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"use children’s scissors\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"draw circles and squares\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"twiddle thumbs\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"do a finger-to-thumb sequence (e.g., Itsy-Bitsy Spider)\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get fine4yearQ => _fine4yearQ;
  set fine4yearQ(List<AnswerValueStruct> value) {
    _fine4yearQ = value;
  }

  void addToFine4yearQ(AnswerValueStruct value) {
    fine4yearQ.add(value);
  }

  void removeFromFine4yearQ(AnswerValueStruct value) {
    fine4yearQ.remove(value);
  }

  void removeAtIndexFromFine4yearQ(int index) {
    fine4yearQ.removeAt(index);
  }

  void updateFine4yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    fine4yearQ[index] = updateFn(_fine4yearQ[index]);
  }

  void insertAtIndexInFine4yearQ(int index, AnswerValueStruct value) {
    fine4yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _social4yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"look forward to new experiences\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"cooperate with other children\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"play “Mom” or “Dad”\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"be very inventive\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"dress and undress\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"imagine monsters\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"negotiate solutions to conflicts\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get social4yearQ => _social4yearQ;
  set social4yearQ(List<AnswerValueStruct> value) {
    _social4yearQ = value;
  }

  void addToSocial4yearQ(AnswerValueStruct value) {
    social4yearQ.add(value);
  }

  void removeFromSocial4yearQ(AnswerValueStruct value) {
    social4yearQ.remove(value);
  }

  void removeAtIndexFromSocial4yearQ(int index) {
    social4yearQ.removeAt(index);
  }

  void updateSocial4yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    social4yearQ[index] = updateFn(_social4yearQ[index]);
  }

  void insertAtIndexInSocial4yearQ(int index, AnswerValueStruct value) {
    social4yearQ.insert(index, value);
  }

  List<AnswerValueStruct> _cognitive4yearQ = [
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"understand counting\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"follow a 3-part instruction\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"recall parts of a story\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"make up and tell simple stories\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"understand “same” and “different”\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"enjoy fantasy play\",\"answer\":\"Hello World\"}')),
    AnswerValueStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"know their address\",\"answer\":\"Hello World\"}'))
  ];
  List<AnswerValueStruct> get cognitive4yearQ => _cognitive4yearQ;
  set cognitive4yearQ(List<AnswerValueStruct> value) {
    _cognitive4yearQ = value;
  }

  void addToCognitive4yearQ(AnswerValueStruct value) {
    cognitive4yearQ.add(value);
  }

  void removeFromCognitive4yearQ(AnswerValueStruct value) {
    cognitive4yearQ.remove(value);
  }

  void removeAtIndexFromCognitive4yearQ(int index) {
    cognitive4yearQ.removeAt(index);
  }

  void updateCognitive4yearQAtIndex(
    int index,
    AnswerValueStruct Function(AnswerValueStruct) updateFn,
  ) {
    cognitive4yearQ[index] = updateFn(_cognitive4yearQ[index]);
  }

  void insertAtIndexInCognitive4yearQ(int index, AnswerValueStruct value) {
    cognitive4yearQ.insert(index, value);
  }

  String _generatedActEarlyID = '';
  String get generatedActEarlyID => _generatedActEarlyID;
  set generatedActEarlyID(String value) {
    _generatedActEarlyID = value;
  }

  List<ChildDataStruct> _cloudChildData = [];
  List<ChildDataStruct> get cloudChildData => _cloudChildData;
  set cloudChildData(List<ChildDataStruct> value) {
    _cloudChildData = value;
  }

  void addToCloudChildData(ChildDataStruct value) {
    cloudChildData.add(value);
  }

  void removeFromCloudChildData(ChildDataStruct value) {
    cloudChildData.remove(value);
  }

  void removeAtIndexFromCloudChildData(int index) {
    cloudChildData.removeAt(index);
  }

  void updateCloudChildDataAtIndex(
    int index,
    ChildDataStruct Function(ChildDataStruct) updateFn,
  ) {
    cloudChildData[index] = updateFn(_cloudChildData[index]);
  }

  void insertAtIndexInCloudChildData(int index, ChildDataStruct value) {
    cloudChildData.insert(index, value);
  }

  List<ActEarlyidDataStruct> _parentRelationAppState = [];
  List<ActEarlyidDataStruct> get parentRelationAppState =>
      _parentRelationAppState;
  set parentRelationAppState(List<ActEarlyidDataStruct> value) {
    _parentRelationAppState = value;
  }

  void addToParentRelationAppState(ActEarlyidDataStruct value) {
    parentRelationAppState.add(value);
  }

  void removeFromParentRelationAppState(ActEarlyidDataStruct value) {
    parentRelationAppState.remove(value);
  }

  void removeAtIndexFromParentRelationAppState(int index) {
    parentRelationAppState.removeAt(index);
  }

  void updateParentRelationAppStateAtIndex(
    int index,
    ActEarlyidDataStruct Function(ActEarlyidDataStruct) updateFn,
  ) {
    parentRelationAppState[index] = updateFn(_parentRelationAppState[index]);
  }

  void insertAtIndexInParentRelationAppState(
      int index, ActEarlyidDataStruct value) {
    parentRelationAppState.insert(index, value);
  }

  String _childImageURL = '';
  String get childImageURL => _childImageURL;
  set childImageURL(String value) {
    _childImageURL = value;
  }

  String _apiKey = 'sk-proj-1rJqep4I6dVF8rjORxDGT3BlbkFJuxkrRP7ABCZu6sRCAIS8';
  String get apiKey => _apiKey;
  set apiKey(String value) {
    _apiKey = value;
  }

  String _assistantId = 'asst_OiTX8s15VttP0M725G8XKe7N';
  String get assistantId => _assistantId;
  set assistantId(String value) {
    _assistantId = value;
    prefs.setString('ff_assistantId', value);
  }

  List<String> _gross1to6monthlinks = [
    'https://youtu.be/LdoDWzCBc5g?feature=shared',
    'https://youtu.be/xnYvI-B48Pw?feature=shared',
    'https://kidshealth.org/en/parents/tummy-time.html',
    'https://www.youtube.com/watch?v=sii3IGitzoc',
    'https://www.youtube.com/watch?v=uVg9Nztme8k'
  ];
  List<String> get gross1to6monthlinks => _gross1to6monthlinks;
  set gross1to6monthlinks(List<String> value) {
    _gross1to6monthlinks = value;
  }

  void addToGross1to6monthlinks(String value) {
    gross1to6monthlinks.add(value);
  }

  void removeFromGross1to6monthlinks(String value) {
    gross1to6monthlinks.remove(value);
  }

  void removeAtIndexFromGross1to6monthlinks(int index) {
    gross1to6monthlinks.removeAt(index);
  }

  void updateGross1to6monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross1to6monthlinks[index] = updateFn(_gross1to6monthlinks[index]);
  }

  void insertAtIndexInGross1to6monthlinks(int index, String value) {
    gross1to6monthlinks.insert(index, value);
  }

  List<String> _gross6to11monthlinks = [
    'https://www.pampers.ca/en-ca/newborn-baby/development/article/baby-firsts-rolling-over',
    'https://youtu.be/1xjCYZ8zFNw?feature=shared',
    'https://www.youtube.com/watch?v=zIBoEKDbe00',
    'https://www.youtube.com/watch?v=E6w7Nlvfm1U'
  ];
  List<String> get gross6to11monthlinks => _gross6to11monthlinks;
  set gross6to11monthlinks(List<String> value) {
    _gross6to11monthlinks = value;
  }

  void addToGross6to11monthlinks(String value) {
    gross6to11monthlinks.add(value);
  }

  void removeFromGross6to11monthlinks(String value) {
    gross6to11monthlinks.remove(value);
  }

  void removeAtIndexFromGross6to11monthlinks(int index) {
    gross6to11monthlinks.removeAt(index);
  }

  void updateGross6to11monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross6to11monthlinks[index] = updateFn(_gross6to11monthlinks[index]);
  }

  void insertAtIndexInGross6to11monthlinks(int index, String value) {
    gross6to11monthlinks.insert(index, value);
  }

  List<String> _gross1yearlinks = [
    'https://www.babycenter.com/baby/baby-development/baby-milestones-sitting_6505',
    'https://youtu.be/iwmyFh67Snw?feature=shared',
    'https://lovevery.com/community/blog/skills-stages/sitting/#:~:text=Babies%20get%20themselves%20out%20of,slow%20descent%20to%20the%20floor.',
    'https://lovevery.com/community/blog/skills-stages/standing/#:~:text=and%20core%20muscles.-,Standing%20with%20support%20(9%20to%2013%20months),a%20support%20to%20steady%20themselves.',
    'https://community.whattoexpect.com/forums/october-2021-babies/topic/how-to-encourage-furniture-cruising-and-walking-138091117.html',
    'https://www.youtube.com/watch?v=6TCEgE9ViBM',
    'https://www.quora.com/What-can-we-do-to-help-our-18-month-old-baby-to-walk-by-herself-She-is-able-to-stand-by-herself-dance-and-clap-while-holding-on-to-chairs-and-hands-but-is-very-scared-of-walking-by-herself',
    'https://youtu.be/_2gqPHpRUes?feature=shared'
  ];
  List<String> get gross1yearlinks => _gross1yearlinks;
  set gross1yearlinks(List<String> value) {
    _gross1yearlinks = value;
  }

  void addToGross1yearlinks(String value) {
    gross1yearlinks.add(value);
  }

  void removeFromGross1yearlinks(String value) {
    gross1yearlinks.remove(value);
  }

  void removeAtIndexFromGross1yearlinks(int index) {
    gross1yearlinks.removeAt(index);
  }

  void updateGross1yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross1yearlinks[index] = updateFn(_gross1yearlinks[index]);
  }

  void insertAtIndexInGross1yearlinks(int index, String value) {
    gross1yearlinks.insert(index, value);
  }

  List<String> _gross2yearlinks = [
    'https://lovevery.com/community/blog/child-development/pull-toys-classic-for-a-reason/#:~:text=Sometime%20between%2015%20and%2018,development%20that%20is%20also%20occurring.',
    'https://www.thekavanaughreport.com/2015/08/montessori-toddlers-and-maximum-effort.html',
    'https://www.youtube.com/watch?v=Nl78kmypSXc',
    'https://lovevery.com/community/blog/skills-stages/throwing/#:~:text=Around%2015%20to%2016%20months,feet%20of%20their%20intended%20target.',
    'https://youtu.be/DJaJrhXlZFA?feature=shared',
    'ttps://www.milestonesandmotherhood.com/blog/going-down-the-stairs'
  ];
  List<String> get gross2yearlinks => _gross2yearlinks;
  set gross2yearlinks(List<String> value) {
    _gross2yearlinks = value;
  }

  void addToGross2yearlinks(String value) {
    gross2yearlinks.add(value);
  }

  void removeFromGross2yearlinks(String value) {
    gross2yearlinks.remove(value);
  }

  void removeAtIndexFromGross2yearlinks(int index) {
    gross2yearlinks.removeAt(index);
  }

  void updateGross2yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross2yearlinks[index] = updateFn(_gross2yearlinks[index]);
  }

  void insertAtIndexInGross2yearlinks(int index, String value) {
    gross2yearlinks.insert(index, value);
  }

  List<String> _gross3yearlinks = [
    'https://www.whattoexpect.com/toddler/growth-and-development/up-stairs-down-stairs.aspx#:~:text=By%202%20years%3A%20By%20his,alternating%20feet%20for%20each%20step.',
    'https://www.youtube.com/watch?v=LDHPlMpVUvE',
    'https://babysparks.com/2018/02/28/jumping-a-significant-gross-motor-skill/',
    'https://www.whattoexpect.com/toddler/play-ball/#:~:text=See%20All%20Sources-,When%20will%20my%20baby%20or%20toddler%20be%20able%20to%20throw,around%20age%202%20to%203.'
  ];
  List<String> get gross3yearlinks => _gross3yearlinks;
  set gross3yearlinks(List<String> value) {
    _gross3yearlinks = value;
  }

  void addToGross3yearlinks(String value) {
    gross3yearlinks.add(value);
  }

  void removeFromGross3yearlinks(String value) {
    gross3yearlinks.remove(value);
  }

  void removeAtIndexFromGross3yearlinks(int index) {
    gross3yearlinks.removeAt(index);
  }

  void updateGross3yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross3yearlinks[index] = updateFn(_gross3yearlinks[index]);
  }

  void insertAtIndexInGross3yearlinks(int index, String value) {
    gross3yearlinks.insert(index, value);
  }

  List<String> _gross4yearlinks = [
    'https://www.chicagopediatrictherapyandwellness.com/blog/learning-how-to-hop-on-one-foot/#:~:text=In%20typical%20development%2C%20a%20child,by%205%20years%20of%20age.',
    'https://www.youtube.com/watch?v=tQnRXYfYgVg',
    'https://youtu.be/uogIRwyNFpI?feature=shared'
  ];
  List<String> get gross4yearlinks => _gross4yearlinks;
  set gross4yearlinks(List<String> value) {
    _gross4yearlinks = value;
  }

  void addToGross4yearlinks(String value) {
    gross4yearlinks.add(value);
  }

  void removeFromGross4yearlinks(String value) {
    gross4yearlinks.remove(value);
  }

  void removeAtIndexFromGross4yearlinks(int index) {
    gross4yearlinks.removeAt(index);
  }

  void updateGross4yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    gross4yearlinks[index] = updateFn(_gross4yearlinks[index]);
  }

  void insertAtIndexInGross4yearlinks(int index, String value) {
    gross4yearlinks.insert(index, value);
  }

  List<String> _fine1to6monthlinks = [];
  List<String> get fine1to6monthlinks => _fine1to6monthlinks;
  set fine1to6monthlinks(List<String> value) {
    _fine1to6monthlinks = value;
  }

  void addToFine1to6monthlinks(String value) {
    fine1to6monthlinks.add(value);
  }

  void removeFromFine1to6monthlinks(String value) {
    fine1to6monthlinks.remove(value);
  }

  void removeAtIndexFromFine1to6monthlinks(int index) {
    fine1to6monthlinks.removeAt(index);
  }

  void updateFine1to6monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine1to6monthlinks[index] = updateFn(_fine1to6monthlinks[index]);
  }

  void insertAtIndexInFine1to6monthlinks(int index, String value) {
    fine1to6monthlinks.insert(index, value);
  }

  List<String> _fine6to11monthlinks = [
    'https://www.whattoexpect.com/first-year/grabbing/',
    'https://lovevery.com/community/blog/child-development/watch-this-baby-master-hand-to-hand-transfer/#:~:text=Passing%20an%20object%20between%20two,between%20months%205%20and%207.',
    'https://pubmed.ncbi.nlm.nih.gov/37286193/'
  ];
  List<String> get fine6to11monthlinks => _fine6to11monthlinks;
  set fine6to11monthlinks(List<String> value) {
    _fine6to11monthlinks = value;
  }

  void addToFine6to11monthlinks(String value) {
    fine6to11monthlinks.add(value);
  }

  void removeFromFine6to11monthlinks(String value) {
    fine6to11monthlinks.remove(value);
  }

  void removeAtIndexFromFine6to11monthlinks(int index) {
    fine6to11monthlinks.removeAt(index);
  }

  void updateFine6to11monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine6to11monthlinks[index] = updateFn(_fine6to11monthlinks[index]);
  }

  void insertAtIndexInFine6to11monthlinks(int index, String value) {
    fine6to11monthlinks.insert(index, value);
  }

  List<String> _fine1yearlinks = [
    'https://solidstarts.com/6-ways-help-baby-practice-pincer-grasp/',
    'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10242726/',
    'https://lovevery.com/community/blog/child-development/the-fine-motor-skill-babies-love-and-parents-sometimes-hate/',
    'https://www.parentingcounts.org/capable-of-poking-with-index-finger-8-13-months/#:~:text=Most%20babies%20around%2012%20months,one%20hand%20to%20the%20other.',
    'https://mylittlegoodybox.co.uk/blogs/news/developmental-benefits-of-push-along-toys',
    'https://www.youtube.com/watch?v=7S7ozOzXmfE',
    'https://aaspeech.com/developmental-milestones-for-ages-1-2-years-of-age/',
    'https://www.youtube.com/watch?v=dESE4txcTtg'
  ];
  List<String> get fine1yearlinks => _fine1yearlinks;
  set fine1yearlinks(List<String> value) {
    _fine1yearlinks = value;
  }

  void addToFine1yearlinks(String value) {
    fine1yearlinks.add(value);
  }

  void removeFromFine1yearlinks(String value) {
    fine1yearlinks.remove(value);
  }

  void removeAtIndexFromFine1yearlinks(int index) {
    fine1yearlinks.removeAt(index);
  }

  void updateFine1yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine1yearlinks[index] = updateFn(_fine1yearlinks[index]);
  }

  void insertAtIndexInFine1yearlinks(int index, String value) {
    fine1yearlinks.insert(index, value);
  }

  List<String> _fine2yearlinks = [
    'https://lovevery.com/community/blog/skills-stages/stacking/#:~:text=Your%20baby%20may%20be%20able,around%2018%20to%2024%20months.',
    'https://babysparks.com/2020/04/16/puzzle-milestones-from-infancy-through-toddlerhood/',
    'https://teachingmama.org/baby-book-hack/#:~:text=Simply%20glue%20pom%20poms%20onto,can%20easily%20turn%20the%20pages!'
  ];
  List<String> get fine2yearlinks => _fine2yearlinks;
  set fine2yearlinks(List<String> value) {
    _fine2yearlinks = value;
  }

  void addToFine2yearlinks(String value) {
    fine2yearlinks.add(value);
  }

  void removeFromFine2yearlinks(String value) {
    fine2yearlinks.remove(value);
  }

  void removeAtIndexFromFine2yearlinks(int index) {
    fine2yearlinks.removeAt(index);
  }

  void updateFine2yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine2yearlinks[index] = updateFn(_fine2yearlinks[index]);
  }

  void insertAtIndexInFine2yearlinks(int index, String value) {
    fine2yearlinks.insert(index, value);
  }

  List<String> _fine3yearlinks = [
    'https://aaspeech.com/7-developmental-handwriting-milestones/#:~:text=At%202%2D3%20years%2C%20average,to%20imitate%20drawing%20a%20circle.',
    'https://lovevery.com/community/blog/child-development/when-should-my-child-be-able-to-stack-6-building-blocks/',
    'https://www.babycentre.co.uk/a6506/developmental-milestones-writing',
    'https://www.parentingcounts.org/can-screw-and-unscrew-jars-and-lids-29-36-months/',
    'https://www.thekavanaughreport.com/2018/10/toddler-bead-threading.html',
    'https://www.beststart.org/OnTrack_English/3-preschooler.html',
    'https://otholly.com/preschool-scissor-skills/'
  ];
  List<String> get fine3yearlinks => _fine3yearlinks;
  set fine3yearlinks(List<String> value) {
    _fine3yearlinks = value;
  }

  void addToFine3yearlinks(String value) {
    fine3yearlinks.add(value);
  }

  void removeFromFine3yearlinks(String value) {
    fine3yearlinks.remove(value);
  }

  void removeAtIndexFromFine3yearlinks(int index) {
    fine3yearlinks.removeAt(index);
  }

  void updateFine3yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine3yearlinks[index] = updateFn(_fine3yearlinks[index]);
  }

  void insertAtIndexInFine3yearlinks(int index, String value) {
    fine3yearlinks.insert(index, value);
  }

  List<String> _fine4yearlinks = [
    'https://www.parentingcounts.org/draws-a-person-with-two-to-four-body-parts-41-50-months/#:~:text=Children%20develop%20muscular%20control%20and,their%20fourth%20year%20of%20life.',
    'https://www.nhsggc.org.uk/kids/resources/ot-activityinformation-sheets/scissor-skills/#:~:text=Children%20may%20have%20the%20skills,until%206%20years%20of%20age.',
    'https://www.continued.com/early-childhood-education/ask-the-experts/what-shapes-do-children-need-22714#:~:text=At%20three%20years%2C%20they%20start,really%20draw%20an%20accurate%20square.',
    'https://www.parentous.com/twiddling-thumbs-spending-time-with-children-memories/',
    'https://pathways.org/watch/fine-motor-skill-pincer-grasp/'
  ];
  List<String> get fine4yearlinks => _fine4yearlinks;
  set fine4yearlinks(List<String> value) {
    _fine4yearlinks = value;
  }

  void addToFine4yearlinks(String value) {
    fine4yearlinks.add(value);
  }

  void removeFromFine4yearlinks(String value) {
    fine4yearlinks.remove(value);
  }

  void removeAtIndexFromFine4yearlinks(int index) {
    fine4yearlinks.removeAt(index);
  }

  void updateFine4yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fine4yearlinks[index] = updateFn(_fine4yearlinks[index]);
  }

  void insertAtIndexInFine4yearlinks(int index, String value) {
    fine4yearlinks.insert(index, value);
  }

  List<String> _social1to6monthlinks = [
    'https://www.youtube.com/watch?v=QbGU45nPkBw',
    'https://www.healthychildren.org/English/ages-stages/baby/Pages/Emotional-and-Social-Development-Birth-to-3-Months.aspx',
    'https://www.unicef.org/parenting/child-development/your-babys-developmental-milestones-4-months#:~:text=Social%20and%20emotional%20milestones%20at%204%20months&text=Will%20try%20copying%20your%20movements,get%20upset%20when%20playtime%20stops'
  ];
  List<String> get social1to6monthlinks => _social1to6monthlinks;
  set social1to6monthlinks(List<String> value) {
    _social1to6monthlinks = value;
  }

  void addToSocial1to6monthlinks(String value) {
    social1to6monthlinks.add(value);
  }

  void removeFromSocial1to6monthlinks(String value) {
    social1to6monthlinks.remove(value);
  }

  void removeAtIndexFromSocial1to6monthlinks(int index) {
    social1to6monthlinks.removeAt(index);
  }

  void updateSocial1to6monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social1to6monthlinks[index] = updateFn(_social1to6monthlinks[index]);
  }

  void insertAtIndexInSocial1to6monthlinks(int index, String value) {
    social1to6monthlinks.insert(index, value);
  }

  List<String> _social6to11monthlinks = [
    'https://www.reddit.com/r/NewParents/comments/rkzvgh/when_did_your_baby_first_reach_for_youwant_to/',
    'https://www.firstthingsfirst.org/first-things/reflecting-on-babies-and-mirror-play/',
    'https://www.michigan.gov/mikidsmatter/parents/infant/social#:~:text=4%20to%206%20Months,a%20part%20of%20the%20action.',
    'https://www.youtube.com/watch?v=jxqCYzbi_kE'
  ];
  List<String> get social6to11monthlinks => _social6to11monthlinks;
  set social6to11monthlinks(List<String> value) {
    _social6to11monthlinks = value;
  }

  void addToSocial6to11monthlinks(String value) {
    social6to11monthlinks.add(value);
  }

  void removeFromSocial6to11monthlinks(String value) {
    social6to11monthlinks.remove(value);
  }

  void removeAtIndexFromSocial6to11monthlinks(int index) {
    social6to11monthlinks.removeAt(index);
  }

  void updateSocial6to11monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social6to11monthlinks[index] = updateFn(_social6to11monthlinks[index]);
  }

  void insertAtIndexInSocial6to11monthlinks(int index, String value) {
    social6to11monthlinks.insert(index, value);
  }

  List<String> _social1yearlinks = [
    'https://www.healthline.com/health/baby/stranger-anxiety#what-is-it',
    'https://lovevery.com/community/blog/child-development/copy-your-baby-to-help-them-learn/',
    'https://www.youtube.com/watch?v=e23JxolOwTA',
    'https://www.unicef.org/parenting/child-development/your-toddlers-developmental-milestones-1-year#:~:text=Social%20and%20emotional%20milestones%20at%201%20year&text=Hands%20you%20a%20book%20when,to%20help%20with%20getting%20dressed',
    'https://choc.org/wp-content/uploads/2014/11/Rehab-Developmental-dressing-skills.pdf',
    'https://foundationtherapyservices.com/dressing-milestones/#:~:text=The%20first%20big%20dressing%20milestone,eye%20coordination%20in%20the%20future.',
    'https://www.whattoexpect.com/first-year/understand-words/',
    'https://myhealth.alberta.ca/Health/Pages/conditions.aspx?hwid=ue5419&lang=en-ca#:~:text=But%20in%20general%2C%20you%20can,members%20and%20their%20favourite%20toys.',
    'https://www.naeyc.org/our-work/families/communicating-with-baby',
    'https://www.youtube.com/watch?v=btaKA97saSo'
  ];
  List<String> get social1yearlinks => _social1yearlinks;
  set social1yearlinks(List<String> value) {
    _social1yearlinks = value;
  }

  void addToSocial1yearlinks(String value) {
    social1yearlinks.add(value);
  }

  void removeFromSocial1yearlinks(String value) {
    social1yearlinks.remove(value);
  }

  void removeAtIndexFromSocial1yearlinks(int index) {
    social1yearlinks.removeAt(index);
  }

  void updateSocial1yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social1yearlinks[index] = updateFn(_social1yearlinks[index]);
  }

  void insertAtIndexInSocial1yearlinks(int index, String value) {
    social1yearlinks.insert(index, value);
  }

  List<String> _social2yearlinks = [
    'https://youtu.be/pdsFkcXTDYs',
    'https://www.youtube.com/watch?v=oatfUfJyVSU',
    'https://www.babycentre.co.uk/a6576/developmental-milestones-socialisation-in-babies',
    'https://brightestbeginning.com/stages-of-play/#:~:text=This%20type%20of%20play%20starts,in%20activities%20with%20other%20children.',
    'https://www.babycenter.com/child/development/developmental-milestone-separation-and-independence-ages-3-a_65555',
    'https://www.zerotothree.org/resource/coping-with-defiance-birth-to-three-years/#:~:text=18%20to%2036%20Months&text=They%20understand%20and%20can%20follow,toddler%20might%20respond%2C%20%E2%80%9CNo!'
  ];
  List<String> get social2yearlinks => _social2yearlinks;
  set social2yearlinks(List<String> value) {
    _social2yearlinks = value;
  }

  void addToSocial2yearlinks(String value) {
    social2yearlinks.add(value);
  }

  void removeFromSocial2yearlinks(String value) {
    social2yearlinks.remove(value);
  }

  void removeAtIndexFromSocial2yearlinks(int index) {
    social2yearlinks.removeAt(index);
  }

  void updateSocial2yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social2yearlinks[index] = updateFn(_social2yearlinks[index]);
  }

  void insertAtIndexInSocial2yearlinks(int index, String value) {
    social2yearlinks.insert(index, value);
  }

  List<String> _social3yearlinks = [
    'https://youtu.be/X3O7LI3NKq4',
    'https://lovevery.com/community/blog/child-development/is-your-toddler-ready-to-take-turns-and-share/#:~:text=Children%20may%20be%20cognitively%20ready,and%20feelings%20than%20their%20own.',
    'https://www.zerotothree.org/resource/journal/who-am-i-developing-a-sense-of-self-and-belonging/',
    'https://www.youtube.com/watch?v=lkjsrXbmXJE',
    'https://youtu.be/hlMxvZ4K6vA',
    'https://youtu.be/wcWbJJ2yKJA',
    'https://www.youtube.com/watch?v=Rfgf9EJPbI4',
    'https://youtu.be/yryiHkVtFmY',
    'https://youtu.be/6W7zt_j0Xmg'
  ];
  List<String> get social3yearlinks => _social3yearlinks;
  set social3yearlinks(List<String> value) {
    _social3yearlinks = value;
  }

  void addToSocial3yearlinks(String value) {
    social3yearlinks.add(value);
  }

  void removeFromSocial3yearlinks(String value) {
    social3yearlinks.remove(value);
  }

  void removeAtIndexFromSocial3yearlinks(int index) {
    social3yearlinks.removeAt(index);
  }

  void updateSocial3yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social3yearlinks[index] = updateFn(_social3yearlinks[index]);
  }

  void insertAtIndexInSocial3yearlinks(int index, String value) {
    social3yearlinks.insert(index, value);
  }

  List<String> _social4yearlinks = [
    'https://youtu.be/-_xsYFwin70',
    'https://youtu.be/Y42pGFywe1U',
    'https://youtu.be/sLTgWGGBAqo',
    'https://myhealth.alberta.ca/Health/Pages/conditions.aspx?hwid=ue5315',
    'https://www.oviahealth.com/guide/104000/parenting-toddler-self-dressing-timeline/#:~:text=3%20to%204%3A%20Sometime%20between,the%20fourth%20to%20fifth%20year.',
    'https://caringforkids.cps.ca/handouts/behavior-and-development/your_childs_development',
    'https://wtcs.pressbooks.pub/infanttoddlerdev/chapter/chapter-13-effectively-negotiating-and-resolving-conflict-related-to-issues-of-diversity/'
  ];
  List<String> get social4yearlinks => _social4yearlinks;
  set social4yearlinks(List<String> value) {
    _social4yearlinks = value;
  }

  void addToSocial4yearlinks(String value) {
    social4yearlinks.add(value);
  }

  void removeFromSocial4yearlinks(String value) {
    social4yearlinks.remove(value);
  }

  void removeAtIndexFromSocial4yearlinks(int index) {
    social4yearlinks.removeAt(index);
  }

  void updateSocial4yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    social4yearlinks[index] = updateFn(_social4yearlinks[index]);
  }

  void insertAtIndexInSocial4yearlinks(int index, String value) {
    social4yearlinks.insert(index, value);
  }

  List<String> _cognitive1to6monthlinks = [
    'https://www.youtube.com/watch?v=vo789qR0_hE',
    'https://youtu.be/5AKUzlW7pcw',
    'https://www.webmd.com/parenting/baby/baby-development-3-months'
  ];
  List<String> get cognitive1to6monthlinks => _cognitive1to6monthlinks;
  set cognitive1to6monthlinks(List<String> value) {
    _cognitive1to6monthlinks = value;
  }

  void addToCognitive1to6monthlinks(String value) {
    cognitive1to6monthlinks.add(value);
  }

  void removeFromCognitive1to6monthlinks(String value) {
    cognitive1to6monthlinks.remove(value);
  }

  void removeAtIndexFromCognitive1to6monthlinks(int index) {
    cognitive1to6monthlinks.removeAt(index);
  }

  void updateCognitive1to6monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive1to6monthlinks[index] = updateFn(_cognitive1to6monthlinks[index]);
  }

  void insertAtIndexInCognitive1to6monthlinks(int index, String value) {
    cognitive1to6monthlinks.insert(index, value);
  }

  List<String> _cognitive6to11monthlinks = [
    'https://youtu.be/Oi2C5I0dRMs',
    'https://youtu.be/Yjei6r9v3Ck',
    'https://www.cdc.gov/ncbddd/actearly/milestones/images/6-Months_Reaches-to-grab-a-toy-she-wants.png',
    'https://www.facebook.com/Lovevery/videos/did-you-know-that-one-way-babies-explore-objects-is-by-banging-them-together-bet/1125386678863440/',
    'https://www.facebook.com/CDC/videos/9-month-milestone-watches-the-path-of-something-as-it-falls/905585156866636/?_rdr'
  ];
  List<String> get cognitive6to11monthlinks => _cognitive6to11monthlinks;
  set cognitive6to11monthlinks(List<String> value) {
    _cognitive6to11monthlinks = value;
  }

  void addToCognitive6to11monthlinks(String value) {
    cognitive6to11monthlinks.add(value);
  }

  void removeFromCognitive6to11monthlinks(String value) {
    cognitive6to11monthlinks.remove(value);
  }

  void removeAtIndexFromCognitive6to11monthlinks(int index) {
    cognitive6to11monthlinks.removeAt(index);
  }

  void updateCognitive6to11monthlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive6to11monthlinks[index] =
        updateFn(_cognitive6to11monthlinks[index]);
  }

  void insertAtIndexInCognitive6to11monthlinks(int index, String value) {
    cognitive6to11monthlinks.insert(index, value);
  }

  List<String> _cognitive1yearlinks = [
    'https://www.parentingcounts.org/explores-objects-in-many-different-ways-shaking-banging-throwing-dropping-8-16-months/',
    'https://youtu.be/n0vS5gg9t48',
    'https://www.primroseschools.com/stories-resources/for-families/musical-milestones-for-babies-toddlers-and-preschoolers',
    'https://www.cde.ca.gov/sp/cd/re/itf09cogdevfdcae.asp#:~:text=At%20around%20eight%20months%20of,others%20on%20the%20immediate%20environment.'
  ];
  List<String> get cognitive1yearlinks => _cognitive1yearlinks;
  set cognitive1yearlinks(List<String> value) {
    _cognitive1yearlinks = value;
  }

  void addToCognitive1yearlinks(String value) {
    cognitive1yearlinks.add(value);
  }

  void removeFromCognitive1yearlinks(String value) {
    cognitive1yearlinks.remove(value);
  }

  void removeAtIndexFromCognitive1yearlinks(int index) {
    cognitive1yearlinks.removeAt(index);
  }

  void updateCognitive1yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive1yearlinks[index] = updateFn(_cognitive1yearlinks[index]);
  }

  void insertAtIndexInCognitive1yearlinks(int index, String value) {
    cognitive1yearlinks.insert(index, value);
  }

  List<String> _cognitive2yearlinks = [
    'https://lovevery.com/community/blog/skills-stages/object-permanence/',
    'https://www.cdc.gov/ncbddd/actearly/milestones/images/2-years_Plays-with-more-than-one-toy-at-the-same-time-like-putting-toy-food-on-a-toy-plate.png',
    'https://www.youtube.com/watch?v=R0LDGfwf_7c'
  ];
  List<String> get cognitive2yearlinks => _cognitive2yearlinks;
  set cognitive2yearlinks(List<String> value) {
    _cognitive2yearlinks = value;
  }

  void addToCognitive2yearlinks(String value) {
    cognitive2yearlinks.add(value);
  }

  void removeFromCognitive2yearlinks(String value) {
    cognitive2yearlinks.remove(value);
  }

  void removeAtIndexFromCognitive2yearlinks(int index) {
    cognitive2yearlinks.removeAt(index);
  }

  void updateCognitive2yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive2yearlinks[index] = updateFn(_cognitive2yearlinks[index]);
  }

  void insertAtIndexInCognitive2yearlinks(int index, String value) {
    cognitive2yearlinks.insert(index, value);
  }

  List<String> _cognitive3yearlinks = [
    'https://www.tiktok.com/@roxybondoc/video/7152893155715599662',
    'https://www.zerotothree.org/resource/stages-of-play-from-24-36-months-the-world-of-imagination/',
    'https://lovevery.com/community/blog/child-development/how-matching-and-sorting-lay-the-foundation-for-math-skills/#:~:text=Between%2019%20and%2024%20months,to%20sort%20basic%20geometric%20shapes.',
    'https://babysparks.com/2020/04/16/puzzle-milestones-from-infancy-through-toddlerhood/',
    'https://babysparks.com/2020/03/04/the-evolution-of-counting-counting-milestones-through-age-3/',
    'https://youtu.be/2S6KHEA7Y_A'
  ];
  List<String> get cognitive3yearlinks => _cognitive3yearlinks;
  set cognitive3yearlinks(List<String> value) {
    _cognitive3yearlinks = value;
  }

  void addToCognitive3yearlinks(String value) {
    cognitive3yearlinks.add(value);
  }

  void removeFromCognitive3yearlinks(String value) {
    cognitive3yearlinks.remove(value);
  }

  void removeAtIndexFromCognitive3yearlinks(int index) {
    cognitive3yearlinks.removeAt(index);
  }

  void updateCognitive3yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive3yearlinks[index] = updateFn(_cognitive3yearlinks[index]);
  }

  void insertAtIndexInCognitive3yearlinks(int index, String value) {
    cognitive3yearlinks.insert(index, value);
  }

  List<String> _cognitive4yearlinks = [
    'https://www.leapfrog.com/en-us/learning-path/discussions/when-do-children-learn-count#:~:text=Between%20the%20ages%20of%20two,not%20uncommon%20even%20through%20kindergarten.',
    'https://childdevelopment.com.au/areas-of-concern/understanding-language/following-instructions/#:~:text=1%20%E2%80%93%202%20years%20of%20age,%2C%20dog%20and%20monkey%E2%80%9D).',
    'https://youtu.be/2eKJmiQkbPw',
    'https://youtu.be/2eKJmiQkbPw',
    'https://www.smalltalkpeds.com/developmental-norms#:~:text=BY%204%20YEARS%20OLD%20A%20CHILD%20SHOULD%20BE%20ABLE%20TO%3A&text=Understand%20the%20difference%20between%20things,do%20not%20associate%20with%20regularly.',
    'https://lovevery.com/community/blog/skills-stages/pretend-play/#:~:text=Fantasy%20play%20(starts%20around%204,they%20have%20not%20yet%20experienced.',
    'https://myhealth.alberta.ca/Health/pages/conditions.aspx?hwid=ue5316&lang=en-ca#:~:text=Thinking%20and%20reasoning%20(cognitive%20development,their%20address%20and%20phone%20number.'
  ];
  List<String> get cognitive4yearlinks => _cognitive4yearlinks;
  set cognitive4yearlinks(List<String> value) {
    _cognitive4yearlinks = value;
  }

  void addToCognitive4yearlinks(String value) {
    cognitive4yearlinks.add(value);
  }

  void removeFromCognitive4yearlinks(String value) {
    cognitive4yearlinks.remove(value);
  }

  void removeAtIndexFromCognitive4yearlinks(int index) {
    cognitive4yearlinks.removeAt(index);
  }

  void updateCognitive4yearlinksAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    cognitive4yearlinks[index] = updateFn(_cognitive4yearlinks[index]);
  }

  void insertAtIndexInCognitive4yearlinks(int index, String value) {
    cognitive4yearlinks.insert(index, value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
