import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/components/empty_children_component_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'manage_children_model.dart';
export 'manage_children_model.dart';

class ManageChildrenWidget extends StatefulWidget {
  const ManageChildrenWidget({super.key});

  @override
  State<ManageChildrenWidget> createState() => _ManageChildrenWidgetState();
}

class _ManageChildrenWidgetState extends State<ManageChildrenWidget> {
  late ManageChildrenModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ManageChildrenModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            FFLocalizations.of(context).getText(
              'ghw0s0b0' /* Manage Children */,
            ),
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              25.0, 30.0, 0.0, 0.0),
                          child: Text(
                            FFLocalizations.of(context).getText(
                              'uz73pytw' /* Cloud Storage : */,
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Outfit',
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                        child: StreamBuilder<List<ChildsRecord>>(
                          stream: queryChildsRecord(
                            queryBuilder: (childsRecord) => childsRecord.where(
                              'onlyParentID',
                              arrayContains: currentUserUid,
                            ),
                          ),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<ChildsRecord> cloudDataWrapChildsRecordList =
                                snapshot.data!;
                            if (cloudDataWrapChildsRecordList.isEmpty) {
                              return EmptyChildrenComponentWidget();
                            }

                            return Wrap(
                              spacing: 0.0,
                              runSpacing: 0.0,
                              alignment: WrapAlignment.start,
                              crossAxisAlignment: WrapCrossAlignment.start,
                              direction: Axis.horizontal,
                              runAlignment: WrapAlignment.start,
                              verticalDirection: VerticalDirection.down,
                              clipBehavior: Clip.none,
                              children: List.generate(
                                  cloudDataWrapChildsRecordList.length,
                                  (cloudDataWrapIndex) {
                                final cloudDataWrapChildsRecord =
                                    cloudDataWrapChildsRecordList[
                                        cloudDataWrapIndex];
                                return Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 10.0, 10.0, 10.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.43,
                                    child: Stack(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 30.0, 0.0, 0.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            elevation: 20.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(10.0, 70.0,
                                                          10.0, 10.0),
                                                  child: Text(
                                                    cloudDataWrapChildsRecord
                                                        .childName,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Archivo',
                                                          color:
                                                              Color(0xFF5D5FEF),
                                                          fontSize: 18.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 0.0, 10.0),
                                                  child: Text(
                                                    cloudDataWrapChildsRecord
                                                        .childAge,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          letterSpacing: 0.0,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          5.0, 10.0, 5.0, 20.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: [
                                                      FlutterFlowIconButton(
                                                        borderColor:
                                                            Colors.transparent,
                                                        borderRadius: 20.0,
                                                        borderWidth: 0.0,
                                                        buttonSize: 32.0,
                                                        fillColor:
                                                            Color(0xFF4865FB),
                                                        icon: Icon(
                                                          Icons.edit,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBackground,
                                                          size: 15.0,
                                                        ),
                                                        onPressed: () async {
                                                          context.pushNamed(
                                                            'EditChildren',
                                                            queryParameters: {
                                                              'childName':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childName,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childDateOfBirth':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childDateOfBirth,
                                                                ParamType
                                                                    .DateTime,
                                                              ),
                                                              'childRelation':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .relationWithChild,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childPremature':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childPremature,
                                                                ParamType.bool,
                                                              ),
                                                              'childGender':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childGender,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childImage':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childImage,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childIndex':
                                                                  serializeParam(
                                                                cloudDataWrapIndex,
                                                                ParamType.int,
                                                              ),
                                                              'childStorageType':
                                                                  serializeParam(
                                                                'cloud',
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childRef':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .reference,
                                                                ParamType
                                                                    .DocumentReference,
                                                              ),
                                                            }.withoutNulls,
                                                          );
                                                        },
                                                      ),
                                                      FlutterFlowIconButton(
                                                        borderColor:
                                                            Colors.transparent,
                                                        borderRadius: 20.0,
                                                        borderWidth: 0.0,
                                                        buttonSize: 32.0,
                                                        fillColor:
                                                            Color(0xFF4865FB),
                                                        icon: Icon(
                                                          Icons.visibility,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBackground,
                                                          size: 15.0,
                                                        ),
                                                        onPressed: () async {
                                                          context.pushNamed(
                                                            'ChildViewPage',
                                                            queryParameters: {
                                                              'childName':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childName,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childAge':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childAge,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childImage':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .childImage,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childIndex':
                                                                  serializeParam(
                                                                cloudDataWrapIndex,
                                                                ParamType.int,
                                                              ),
                                                              'socialQ':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .socialQuestion,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'grossQ':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .grossMotorQuestions,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'fineQ':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .fineMotorQuestions,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'cognitiveQ':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .cognitiveQuestions,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'storageType':
                                                                  serializeParam(
                                                                'cloud',
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'actEarlyID':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .actEarlyID,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'cognitiveLinks':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .cognitiveLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                              'socialLinks':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .socialLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                              'grossLinks':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .grossMotorLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                              'fineLinks':
                                                                  serializeParam(
                                                                cloudDataWrapChildsRecord
                                                                    .fineMotorLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                            }.withoutNulls,
                                                          );
                                                        },
                                                      ),
                                                      FlutterFlowIconButton(
                                                        borderColor:
                                                            Colors.transparent,
                                                        borderRadius: 20.0,
                                                        borderWidth: 0.0,
                                                        buttonSize: 32.0,
                                                        fillColor:
                                                            Color(0xFF4865FB),
                                                        icon: Icon(
                                                          Icons.delete,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBackground,
                                                          size: 15.0,
                                                        ),
                                                        onPressed: () async {
                                                          var confirmDialogResponse =
                                                              await showDialog<
                                                                      bool>(
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (alertDialogContext) {
                                                                      return AlertDialog(
                                                                        title: Text(
                                                                            'Delete Children Data'),
                                                                        content:
                                                                            Text('All data of your children will be delete.'),
                                                                        actions: [
                                                                          TextButton(
                                                                            onPressed: () =>
                                                                                Navigator.pop(alertDialogContext, false),
                                                                            child:
                                                                                Text('Cancel'),
                                                                          ),
                                                                          TextButton(
                                                                            onPressed: () =>
                                                                                Navigator.pop(alertDialogContext, true),
                                                                            child:
                                                                                Text('Confirm'),
                                                                          ),
                                                                        ],
                                                                      );
                                                                    },
                                                                  ) ??
                                                                  false;
                                                          if (confirmDialogResponse) {
                                                            await cloudDataWrapChildsRecord
                                                                .reference
                                                                .delete();
                                                            ScaffoldMessenger
                                                                    .of(context)
                                                                .showSnackBar(
                                                              SnackBar(
                                                                content: Text(
                                                                  'Child Removed Successfully!',
                                                                  style:
                                                                      TextStyle(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primaryBackground,
                                                                  ),
                                                                ),
                                                                duration: Duration(
                                                                    milliseconds:
                                                                        4000),
                                                                backgroundColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .primaryText,
                                                              ),
                                                            );
                                                          } else {
                                                            return;
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              _model.test =
                                                  cloudDataWrapChildsRecord
                                                          .parentID[
                                                      cloudDataWrapIndex];
                                              setState(() {});
                                            },
                                            child: Container(
                                              width: 90.0,
                                              height: 90.0,
                                              clipBehavior: Clip.antiAlias,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                              ),
                                              child: Image.network(
                                                cloudDataWrapChildsRecord
                                                    .childImage,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }),
                            );
                          },
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              25.0, 30.0, 0.0, 0.0),
                          child: Text(
                            FFLocalizations.of(context).getText(
                              'dozw65u6' /* Local Storage : */,
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Outfit',
                                  fontSize: 16.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                        child: Builder(
                          builder: (context) {
                            final childrensData =
                                FFAppState().childDataAppState.toList();
                            if (childrensData.isEmpty) {
                              return EmptyChildrenComponentWidget();
                            }

                            return Wrap(
                              spacing: 0.0,
                              runSpacing: 0.0,
                              alignment: WrapAlignment.start,
                              crossAxisAlignment: WrapCrossAlignment.start,
                              direction: Axis.horizontal,
                              runAlignment: WrapAlignment.start,
                              verticalDirection: VerticalDirection.down,
                              clipBehavior: Clip.none,
                              children: List.generate(childrensData.length,
                                  (childrensDataIndex) {
                                final childrensDataItem =
                                    childrensData[childrensDataIndex];
                                return Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      10.0, 10.0, 10.0, 10.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.43,
                                    child: Stack(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 30.0, 0.0, 0.0),
                                          child: Card(
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            elevation: 20.0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(10.0, 70.0,
                                                          10.0, 10.0),
                                                  child: Text(
                                                    valueOrDefault<String>(
                                                      childrensDataItem
                                                          .childName,
                                                      'Name',
                                                    ),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Archivo',
                                                          color:
                                                              Color(0xFF5D5FEF),
                                                          fontSize: 18.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 0.0, 10.0),
                                                  child: Text(
                                                    valueOrDefault<String>(
                                                      childrensDataItem
                                                          .childAge,
                                                      'age',
                                                    ),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          letterSpacing: 0.0,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 0.0, 10.0),
                                                  child: Text(
                                                    FFLocalizations.of(context)
                                                        .getText(
                                                      '83qmovi5' /* 9 months */,
                                                    ),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Readex Pro',
                                                          letterSpacing: 0.0,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          5.0, 10.0, 5.0, 20.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: [
                                                      FlutterFlowIconButton(
                                                        borderRadius: 20.0,
                                                        borderWidth: 0.0,
                                                        buttonSize: 32.0,
                                                        fillColor:
                                                            Color(0xFF4865FB),
                                                        icon: Icon(
                                                          Icons.edit,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBackground,
                                                          size: 15.0,
                                                        ),
                                                        onPressed: () async {
                                                          context.pushNamed(
                                                            'EditChildren',
                                                            queryParameters: {
                                                              'childName':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childName,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childDateOfBirth':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childDateOfBirth,
                                                                ParamType
                                                                    .DateTime,
                                                              ),
                                                              'childRelation':
                                                                  serializeParam(
                                                                valueOrDefault<
                                                                    String>(
                                                                  childrensDataItem
                                                                      .relationWithChild,
                                                                  'Dad',
                                                                ),
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childPremature':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childPremature,
                                                                ParamType.bool,
                                                              ),
                                                              'childGender':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childGender,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childImage':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childImage,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childIndex':
                                                                  serializeParam(
                                                                childrensDataIndex,
                                                                ParamType.int,
                                                              ),
                                                              'childStorageType':
                                                                  serializeParam(
                                                                'local',
                                                                ParamType
                                                                    .String,
                                                              ),
                                                            }.withoutNulls,
                                                          );
                                                        },
                                                      ),
                                                      FlutterFlowIconButton(
                                                        borderColor:
                                                            Colors.transparent,
                                                        borderRadius: 20.0,
                                                        borderWidth: 0.0,
                                                        buttonSize: 32.0,
                                                        fillColor:
                                                            Color(0xFF4865FB),
                                                        icon: Icon(
                                                          Icons.visibility,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBackground,
                                                          size: 15.0,
                                                        ),
                                                        onPressed: () async {
                                                          context.pushNamed(
                                                            'ChildViewPage',
                                                            queryParameters: {
                                                              'childName':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childName,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childAge':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childAge,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childImage':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .childImage,
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'childIndex':
                                                                  serializeParam(
                                                                childrensDataIndex,
                                                                ParamType.int,
                                                              ),
                                                              'socialQ':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .socialQuestion,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'grossQ':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .grossMotorQuestions,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'fineQ':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .fineMotorQuestions,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'cognitiveQ':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .cognitiveQuestions,
                                                                ParamType
                                                                    .DataStruct,
                                                                isList: true,
                                                              ),
                                                              'storageType':
                                                                  serializeParam(
                                                                'local',
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'actEarlyID':
                                                                  serializeParam(
                                                                'null',
                                                                ParamType
                                                                    .String,
                                                              ),
                                                              'cognitiveLinks':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .cognitiveLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                              'socialLinks':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .socialLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                              'grossLinks':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .grossMotorLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                              'fineLinks':
                                                                  serializeParam(
                                                                childrensDataItem
                                                                    .fineMotorLinks,
                                                                ParamType
                                                                    .String,
                                                                isList: true,
                                                              ),
                                                            }.withoutNulls,
                                                          );
                                                        },
                                                      ),
                                                      FlutterFlowIconButton(
                                                        borderColor:
                                                            Colors.transparent,
                                                        borderRadius: 20.0,
                                                        borderWidth: 0.0,
                                                        buttonSize: 32.0,
                                                        fillColor:
                                                            Color(0xFF4865FB),
                                                        icon: Icon(
                                                          Icons.delete,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryBackground,
                                                          size: 15.0,
                                                        ),
                                                        onPressed: () async {
                                                          var confirmDialogResponse =
                                                              await showDialog<
                                                                      bool>(
                                                                    context:
                                                                        context,
                                                                    builder:
                                                                        (alertDialogContext) {
                                                                      return AlertDialog(
                                                                        title: Text(
                                                                            'Delete Children Data'),
                                                                        content:
                                                                            Text('All data of your children will be delete.'),
                                                                        actions: [
                                                                          TextButton(
                                                                            onPressed: () =>
                                                                                Navigator.pop(alertDialogContext, false),
                                                                            child:
                                                                                Text('Cancel'),
                                                                          ),
                                                                          TextButton(
                                                                            onPressed: () =>
                                                                                Navigator.pop(alertDialogContext, true),
                                                                            child:
                                                                                Text('Confirm'),
                                                                          ),
                                                                        ],
                                                                      );
                                                                    },
                                                                  ) ??
                                                                  false;
                                                          if (confirmDialogResponse) {
                                                            FFAppState()
                                                                .removeFromChildDataAppState(
                                                                    childrensDataItem);
                                                            setState(() {});
                                                            ScaffoldMessenger
                                                                    .of(context)
                                                                .showSnackBar(
                                                              SnackBar(
                                                                content: Text(
                                                                  'Child Removed Successfully!',
                                                                  style:
                                                                      TextStyle(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primaryBackground,
                                                                  ),
                                                                ),
                                                                duration: Duration(
                                                                    milliseconds:
                                                                        4000),
                                                                backgroundColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .primaryText,
                                                              ),
                                                            );
                                                          } else {
                                                            return;
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 90.0,
                                            height: 90.0,
                                            clipBehavior: Clip.antiAlias,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                            ),
                                            child: Image.network(
                                              childrensDataItem.childImage,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }),
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            10.0, 20.0, 10.0, 20.0),
                        child: Text(
                          FFLocalizations.of(context).getText(
                            'je4g04k7' /* If you want to switch from clo... */,
                          ),
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                fontFamily: 'Readex Pro',
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                fontSize: 15.0,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w300,
                              ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
